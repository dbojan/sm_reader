#!/bin/bash

#2026-09-19-16-05-54
dt="../backup/$(date +%Y-%m-%d-%H-%M-%S)"; 7z a "${dt}.7z" * '-xr!build' '-xr!__pycache__' '-xr!not_needed_after_editing' 
read -p "done"
