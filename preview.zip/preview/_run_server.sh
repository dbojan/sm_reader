echo -ne "\033]0;server: sm reader\007"
python3 -m http.server 8000