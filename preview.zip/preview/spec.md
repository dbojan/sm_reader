<!-- SM Reader - spec.md -->
<!-- last modified (utc): 2026-09-29-09-39-04 -->
<!-- instructions: on modify, update string. -->
# SM Reader: Specification (draft 2)

A simple, book-like EPUB reader inspired by Microsoft Reader (2000-2012): one page of text, centered on a dark surround, with adjustable fonts and page geometry.

## 1. Goals

- Recreate the look and feel of MS Reader's reading page and options.
- Read the user's existing EPUB files. EPUB stays the master storage format.
- Run on desktop and Android from one codebase.
- No account and no login required for the core app (v1). Cross-device sync is added later (v2) via the user's own XMPP account — see section 10 — not a third-party login provider.
- Books and reading data stay on the user's device unless the person opts into login-based sync.

## 2. Non-goals

- No ClearType or text-rendering toggle. The OS and browser control text smoothing.
- No Kindle location converter. Percentage is the shared position instead.
- No support for MOBI/AZW (binary formats). Convert to EPUB with Calibre.
- Highlights, notes, dictionary lookup and text-to-speech are later features.

## 3. Platform

- **Installable web app (PWA)**: static HTML, CSS and JavaScript, no build step.
- Hosted on GitHub Pages at `username.github.io/sm_reader` (repo name: `sm_reader`, "SM" as a reverse of "MS"). Only the app code is in the repo, never the books.
- **Relative paths everywhere**, so it works under a subpath. The service worker scope is set accordingly.
- `manifest.json` for installing, and a service worker for offline use.
- **EPUB library: foliate-js** (newer and more actively maintained than epub.js), stored in the repo, not loaded from a CDN.
- Works in Firefox, Chrome and other modern browsers on desktop and Android.

## 4. Library

- Import EPUB files with a file picker (multiple files allowed).
- Store books, covers, settings and positions in IndexedDB.
- Library view lists books with covers, title, author and progress percentage.
- Each book gets a **fingerprint** (hash of the file) plus the EPUB's own identifier, used to match the same book across devices.
- Nothing is uploaded anywhere.
- Note: browser storage can be cleared. Keep the original EPUB files backed up elsewhere.

## 5. Reading view

- One centered page on a dark surround. Paged reading, not scrolling.
- Click or tap the page edges (or use arrow keys, swipe) to turn pages.
- Small footer showing position: percentage with two decimals (and optionally location).
- Menu: table of contents, bookmarks, go to position, settings.
- On small screens (phones) the page fills the screen, as Reader did on the Pocket PC. The centered page with surround is for larger screens.

## 6. Themes

- Cream page (classic Reader look), white page, night mode (inverted).
- The surround is dark in all themes.

## 7. Typography

Font choice has three sources, all shown with a live preview:

1. **Bundled fonts** (open-source, in the repo). Default: **Jost** (Futura-like). Others: Outfit, Questrial, League Spartan, Literata, Atkinson Hyperlegible, and an optional dyslexia-friendly font. Futura itself is commercial and cannot be bundled.
2. **Installed font by name**: the user types a name (e.g. "Futura") and it is used if the device has it, with a fallback if not.
3. **Upload a font file** (.ttf, .otf, .woff2), stored in IndexedDB and added to the list.

Also:
- **Font size: a row of sensible numbered sizes** (e.g. 12, 14, 16, 18, 20, 24, 28, 32, 40, 48), shown as tappable numbers rather than named steps ("smallest".."largest") or a slider, plus a **custom field** where the user can type any number. This replaces Reader's named-step slider and sidesteps the "how many steps" question entirely, since the numbers are self-explanatory and unlimited via the custom field.
- Line spacing and text density.
- Defaults favor sans serif fonts.

## 8. Page geometry (Advanced settings)

- **Scale** (75% to 200%): a DPI-like multiplier that grows the page and text together.
- **Page width**: presets (narrow, medium, wide) and a slider. Controls characters per line.
- **Page height**: fit to screen (default) or a fixed proportion.
- **Margins** inside the page.
- **Surround**: amount of dark space, or none.
- Sizes are stored as proportions, not fixed pixels, so they scale to any screen.
- **Profiles**: named sets of settings (for example "Desktop", "Phone").
- **"Reader classic" preset**: values measured from the reference screenshots (section 12) — page height ≈ 88% of viewport height, page width:height ≈ 0.75 (3:4), text column ≈ 78% of page width (≈11% margin each side), equal top/bottom gap outside the page. Unlike Reader, SM Reader uses the same fixed number of size steps on every screen (Reader varied: 6 steps on the 20" screen, 5 on the 17").

Common settings (font, size, theme) stay on the main settings screen. Geometry is under "Advanced" to keep it uncluttered.

## 9. Position

### Saved internally (automatic resume on each device)

1. Book fingerprint
2. CFI (exact, used first when the file matches)
3. Chapter number plus character offset within the chapter
4. Short text snippet (about 30 characters) to correct small drifts
5. Overall percentage stored with 4 decimals

On load the app tries them in order of precision and uses the first that works.

### Shown to the user

- **Percentage with two decimals** (e.g. 42.73%), based on visible text characters, not file size or chapter count.
- Two decimals is about 30-60 characters in a typical novel, so it lands within a line or two.
- "Go to position" accepts a percentage (`42.73` or `42.73%`) or an optional location number (fixed-size chunks of visible text, for example 100 characters each, counted by Unicode characters, not bytes).
- Jumping lands at the start of the sentence or paragraph containing the point.

### Counting rules (must be identical on every device)

- Count visible text only, ignoring tags and hidden elements.
- Fixed handling of whitespace, footnotes and front matter.
- Count Unicode characters consistently (emoji and combined characters).

## 10. Sync

**Version 1 (no login, no backend, works from static GitHub Pages alone):**
- Percentage typed by hand between devices.
- Link or QR code containing book fingerprint and position.
- Export/import of a small file with positions, bookmarks and settings (also works as a backup).

**Version 2: XMPP self-messaging (primary plan — no third-party backend, reuses infrastructure the user already runs and trusts).**

GitHub Pages stays static in every option below; login/sync always needs *something* live behind it. XMPP is the pick because that "something" is a server the user already operates, not a new third party.

- **How it works:** the browser can't open a raw XMPP/TCP socket, but it can speak XMPP over a WebSocket (`wss://`), which most servers support (Prosody's `mod_websocket`, ejabberd's built-in support). A JS library such as Strophe.js handles the protocol. Needs a real TLS cert on the server, not self-signed, since the page is served over HTTPS.
- **Default account shape: self-messaging.** The user's own JID (e.g. `dbojan@jabber.fr`) logs in and sends a message to itself — a book title, author, and percentage position (e.g. "Alice's Adventures in Wonderland — 42.73%"). `from` and `to` being the same bare JID is valid XMPP; the server delivers and archives it normally. One account, one login stored in Settings, nothing else to create.
- **Optional alternative: a dedicated sender account** (e.g. `sm-reader@jabber.fr`) sending only to the user's own JID, kept as a mutual contact/roster subscription. Same one-to-one shape as the user's existing reminder setup (`dbojankuca@jabber.fr → dbojan@jabber.fr`), just for people who'd rather not store their main account's password in a browser. Offered as a setting, not the default.
- **Not a fan-out risk at this scale.** Blocking/rate-limiting is a concern for one account messaging *many different people's* servers, which this isn't — it's always a single fixed sender-to-recipient pair, whether self-messaging or the dedicated-sender variant. If this were ever shared with other people, the right pattern is each person runs their own sending account pointed at their own JID, never one shared bot for everyone.
- **Retrieving position on another device needs MAM (Message Archive Management, XEP-0313)** on the server. On load, the app queries the account's own archive for the most recent position message and offers "Continue from 42.73%, sent from your PC?" To check: confirm the user's server has MAM enabled.
- **Message Carbons (XEP-0280),** if enabled server-side, may duplicate the self-sent message into other connected sessions/clients — harmless for the app (it reads from the archive, not a live chat view), only visible if the user happens to be watching a regular XMPP client at the time.
- Credentials (JID + password) are stored in the browser on each device, used only to open the `wss://` connection to the user's own server. A dedicated low-privilege sending account, per the option above, avoids exposing the main account's password this way.

**Other options considered for v2 (not the current plan, kept here for reference):**

- **Firebase (Google Auth + Firestore).** Rejected: brings in a Google-account dependency the user wants to avoid, even though it would otherwise be the least-setup option (hosted, generous free tier, "Sign in with Google" needs no custom OAuth code).
- **Supabase (GitHub OAuth + Postgres).** An open-source Firebase-alternative; "Sign in with GitHub" would fit neatly since the user already has a GitHub account for Pages hosting. Still a third-party hosted service, even though it's not Google. Worth a second look if the XMPP route runs into blockers (e.g. no MAM support).
- **PocketBase (self-hosted).** A single Go binary bundling auth, database and file storage; the only option with zero third-party servers involved, but it means running and keeping something online continuously (a VPS, home server, Raspberry Pi) — more responsibility than reusing the existing XMPP server.
- **Cloudflare Workers + D1/KV.** Hosted like Supabase/Firebase, generous free tier, but lower-level — more custom code to write for the same result.
- **UnifiedPush.** Considered and set aside: it's an open push-notification standard, mainly relevant for native Android apps distributed outside Google Play that need a "wake up" signal without Firebase Cloud Messaging. SM Reader's sync is pull-based (checked on open or on demand), so push isn't needed. Would only become relevant if the app were later wrapped as a native Android app distributed outside the Play Store.

In all cases: conflict rule is the most recent position wins, with a prompt like "Continue from 42.73% on your phone?" Book files are never synced, only small notes (position, settings, metadata) — the same EPUB must be imported on each device. The rest of the app (import, reading, themes, fonts, geometry) is unaffected by whether sync is set up; it only replaces the manual v1 steps.

## 11. Later features

Highlights, notes, freehand drawing, dictionary lookup, text-to-speech, more themes.

## 12. Reference: MS Reader screenshots (measured)

Source: MS Reader 2.1.1, screenshots supplied by the user, full screen, PNG, uncropped. Two monitors, both windowed Reader maximized.

**Measured page geometry** (measured directly from pixels, using the "row of a's" screenshots as a ruler):

| Item | 17" screen | 20" screen |
|---|---|---|
| Screen resolution | 1280x1024 (4:3) | 1680x1050 (16:10) |
| Page box (px) | 669 x 904 | 695 x 928 |
| Page width : height ratio | 0.740 | 0.749 |
| Page height as % of screen height | 88.3% | 88.4% |
| Top/bottom gap (px, equal both sides) | 60 / 60 | 61 / 61 |
| Page horizontal position | not centered on screen; sits right of the red sidebar, with a wider dark margin on the right than the sidebar's width on the left | roughly centered (492 left gap, 493 right gap) |
| Left/right text margin inside page | ~74-76 px each side (~11% of page width each) | ~74-78 px each side (~11% of page width each) |

**Key findings:**
- **The page keeps a fixed pixel size regardless of font size.** Changing font size changes how much text fits per page, never the page's own dimensions. This confirms the spec's approach: page geometry and text size are independent settings.
- **The page is sized to ~88% of the screen height** on both monitors, with equal top and bottom gaps, and a fixed aspect ratio close to 3:4 (0.74-0.75), not the screen's own aspect ratio. This is the single most useful number for the "Reader classic" preset.
- **The sidebar (red, on the left) is a fixed-width panel**, not part of the page or its surround; it holds "Go to" plus Library / Shop / Help / Settings / Return, and doesn't scale with the page.
- **Left/right text margins are ~11% of the page width per side**, i.e. the text column is about 78% of the page width. This is consistent across screens and font sizes.

**Font size steps** (from the Settings → Font Settings slider, "This window reflects your current font size selection" preview):
- **20" screen: 6 steps** — smallest, small, medium small, medium large, large, largest. Default/opened at "medium small" (position 3).
- **17" screen: 5 steps** (per your note) — Reader appears to offer one fewer step on the smaller/lower-resolution display. Default there was "medium" (position 3 of 5).
- Measured glyph pitch (20" screen, "a"-grid pages) scales roughly linearly across the 6 steps: about 10.2, 12.3, 13.2, 15.5, 17.4, up to 29.9 px per character at "largest" — i.e. largest is roughly 3x the character width of smallest, and the step sizes are not perfectly even (a bigger jump from "large" to "largest").
- Lines per page at the smallest size: ~39; at "largest": ~15. This is the range a "lines per page" slider should reproduce.

**Typography:**
- Body text: a serif ClearType font (Georgia-like), fully justified with hyphenation, first-line paragraph indents, no blank line between paragraphs.
- Chapter headings: centered, small caps for "CHAPTER I.", a serif title line below in a larger size.
- Book title in the header (top-left of page) and "by Author" / edition line on the title page: an italic serif, distinct from the body font, used only for titles/headers.
- No typeface choice was found anywhere in Settings. Reader 2.1.1 ships one body font and one display/title font; there is no font-family picker.

**"ClearType Settings" (Settings page 2) is a rendering calibration wizard**, not a font picker: it shows 5 renderings of the same paragraph and asks the user to pick the one that "looks best" (a subpixel-tuning step, like the old Windows ClearType Tuner). This confirms the earlier call: there's nothing here worth reproducing today, since browsers/OSes handle subpixel rendering themselves. A font *choice* (typeface), by contrast, is worth keeping, per section 7.

**Settings pages found** (4 total, paged via "Page 1 ▶ / ◀ Page N ▶"):
1. **Font Settings** — the font size slider and live preview described above.
2. **ClearType Settings** — rendering calibration (not reproduced; see above).
3. **Screen Settings** — "Full Screen off/on" and a "Visual Guides" checkbox (plus an activation-status note).
4. **Voice Settings** — "Verbosity" and "Highlight text as it is being read" (text-to-speech options; later-feature territory per section 11).

**"Go to" menu** (dropdown from the sidebar): Table of Contents, Most recent page, Begin reading, Begin playing, Furthest read, Annotations (greyed until any exist), About this title (greyed), Cover Image. Useful as the shape for SM Reader's own navigation menu.

**Table of Contents page**: a plain in-book page titled "Contents", chapter numbers as clickable links (teal) in a left column, chapter titles in a right column, no page numbers shown.

**Library view**: list rows, each with a small cover thumbnail, title, and an italic "Opened: <date>" or "(Not yet opened)" line. A left-hand "Sort" / "Search" panel sits where "Go to" appears on the reading page.

**Reading page footer**: centered "◂ N ▸" page-turn control with the current page number between the arrows; the whole control gets a light highlight box when focused/hovered.

**Annotation markers**: on an annotated page, small colored flag/highlight icons appear in the dark surround just outside the right edge of the page, one per marked paragraph, in various colors (presumably one per highlight color used). Confirms annotations are anchored to paragraphs and shown outside the page rather than inline in the margin.

**Not reproduced (later features / obsolete):** Shop, Buy eBooks/audiobooks, activation, text-to-speech and voice settings, ClearType calibration.

## 13. Milestones

1. **First version**: single static app with EPUB import, Reader-style page, page turning, themes, fonts (bundled, by name, upload), numbered font sizes with a custom field, saved settings and automatic position resume, percentage footer and "Go to position".
2. Advanced geometry, scale, profiles, "Reader classic" preset from screenshots.
3. Table of contents, bookmarks, export/import, link/QR position sharing.
4. XMPP self-messaging sync (see section 10 for the plan and the other options kept in reserve).
5. Highlights, notes, dictionary, text-to-speech.

## 14. Open questions

- Whether to include location numbers alongside percentage.

## 15. Recent changes (2026-09-26-12-58-00)

### 2026-09-29-09-39-04

- Applied patches **boundary-next-node**, **mark-skip-blank** and **blank-page-save** (approved with `codenow`), all in `js/app.js` (plus `sw.js` CACHE bump). Same-model check only (diff against backups, callers, `node --check` syntax pass); no browser run. Blank-page-save is on the position-save path: a Terra review is recommended.
- **Field test of window-edge / mark-at-node-end (log 09:30-09:31, PC, Firefox, Alice, size 467.45):** page-turn read-backs are correct on odd and even pages (`grid=exact`, `charL` = window start, `charT` = first row). Remaining reload bugs, all in `app.js`:
  - **Pages that start at a paragraph start ("Soon", "However") reloaded one page back.** Cause: every paragraph start is a text-node boundary. The read-back saves the count of chars strictly before the page's first char (11806 for "Soon"), which is both the end of the previous node and the start of the next one; `getRangeForCharIndex()` resolved it to the END of the previous node (`goto-target` left 4023.33, top 641 = last line of the previous page). Pages starting mid-paragraph were unaffected.
  - **Blank page before chapter II reloaded sometimes on chapter II, sometimes on the page before.** Cause: the blank page has no char, so it was never saved; the saved value stayed where the reader came from (12848 from the "*" page, 12850 when coming back from chapter II).
  - **Blue mark on the "*" page sat on the char before it.** Cause: the node reads nbsp then "*"; the word scan treats nbsp as whitespace and stopped at once, marking only the nbsp. (A reported blue "sleep" could not be matched to the log; retest.)
- **boundary-next-node** (`getRangeForCharIndex()` `makeAnchor`): `remaining === len` now moves on to the start of the next node (text offset 0, or the media element via the existing `remaining <= 0` branch); only the very last node of the section keeps the end-of-node anchor. Side effect: Go to, search hits and Contents targets that fall exactly on a node start now land on the page that holds the text instead of the page before. The rect of a collapsed range at a mid-node wrap (like the "*" page, where the resolved left is exactly the page edge) still relies on the 1e-4 dust epsilon in `#scrollToRect`; not changed (an option: use a one-char range instead).
- **mark-skip-blank** (`markSavedCharAfterRestore()`): leading whitespace (`\s`, includes nbsp) is skipped before the word scan; the range start is moved to the first non-blank char. The node-end branch from mark-at-node-end stays as a safety net.
- **blank-page-save** (`onRelocate()`): decision from the user: on a page with no text, reload goes to a page the reader has already seen (the previous text page). New `getCharBeforeBlankPage(range)` walks the counted nodes in the live doc and takes the last char of the last node whose union rect starts left of the page window (`(page-1)*size`, iframe coords); new `saveBlankPageAsPreviousText(e)` sets `lastStableCharIndex` (and furthest, footer %, debounced save) for reason `page`/`navigation`, skipped while `isResizing` or a restore is active, spacer pages still ignored earlier, cover unchanged. Works for blank pages in the middle of a section too. LTR horizontal paginated only (RTL/vertical/scrolled return null and save nothing, as before). Saved cfi/fraction/snippet keep the previous page's values (int mode reads the char).
- **Tests to run (fresh tab, CACHE `2026-09-29-09-39-04`):** reload on the "Soon", "However" and other paragraph-start pages (must stay on the same page, blue mark on the first word); reload on the "*" page (mark on "*", not before it); blank page before chapter II reached forward, then reload; reached backward from chapter II, then reload (both must land on the "*" page); chapter II first page still reloads on chapter II; cover reload; Go to 40%, search hit and Contents jump still land on the right page; F11 x20 (no `restore-start`); paste `restore-*`, `goto-target` and `saved-mark` lines if anything looks off.
- Files edited: `js/app.js`, `sw.js`, `spec.md`.

### 2026-09-29-09-18-31

- Applied patches **window-edge** and **mark-at-node-end** (both approved with `codenow`), the two patches proposed in `log.md` (4.B, 4.F). Same-model check only (diff against backups, callers, control flow, RTL sign); no browser run. Position-save path touched: an independent review (Terra) is recommended.
- **window-edge** (`js/foliate-js/paginator.js`): `getVisibleRange()` got a `tol` parameter (default 0, so scrolled mode and the off-grid case are unchanged) applied to the START edge only: text node visible if `right >= start + tol`; element accepted if `left >= start - tol && right <= end + tol`; start bisect uses `q.left > start - tol` and `p.right < start + tol`. New constant `PAGED_EDGE_TOL_PX = 0.5`. In `#getVisibleRange()` (paginated branch) the window is now built from the exact page grid, `gridStart = this.page * this.size` (window `gridStart - size .. gridStart + size - size`, RTL sign as before), instead of the rounded integer `scrollLeft`, but only when `|start - gridStart| < 1` (on-grid); off-grid scrolls keep the old window. Cause (from the read-back probe, size 467.45): integer `start` rounded DOWN on odd pages (e.g. 1402 vs 1402.35), so the node ending on the previous page passed `right >= start` and the read landed at its end (2303 instead of 2258, 4710 instead of 4695); rounded UP, a first char whose left equals the page edge was skipped (one char late). Probe event `probe-readback` now also reports `grid` (`exact`/`start`) and `tol`.
- **mark-at-node-end** (`js/app.js`): new helper `nextNonBlankTextNode(doc, node)`. In `markSavedCharAfterRestore()`, when the saved char is at the end of its text node (`offset >= length`, which made every `saved-mark` on text log `outcome=empty`), the mark now covers the first word of the next non-blank text node. `saved-mark` beacon gets `via` (`node`, `next-node`, `no-next-node`). If no next node exists it still logs `empty`.
- Also recorded here (applied 2026-09-29-08-27-26, files `js/app.js`, `js/foliate-js/paginator.js`, `sw.js`; taken from `log.md`, verified in the 08:37-08:55 field test): **settle-guard** (`lastFsEventAt` + `runPageRefSettle()` re-arms the 600 ms refit while within `FS_EVENT_QUIET_MS` = 1500 of a fullscreen/display-mode event; fixes the F11 race where the refit used the still-big height), **first-click-fix** (`dismissChrome()` collapses the sidebar only if it is displayed and not `collapsed`, so the first tap after opening turns the page), **read-back probe** (`SWITCH_PROBE_READBACK`, event `probe-readback`, no behavior change), **saved-char-mark** (`SWITCH_MARK_SAVED_CHAR_UNTIL_NEXT_PAGE_TURN`, CSS Custom Highlight `::highlight(sm-saved-char)`, cleared on page turn/navigation/book open; old first-row flash flag now false, code kept). Field result: page turns, F11 x ~30 and first click fine; drag-resize kept the stored target (2034) through all restores.
- Not applied: patch 3 (explicit-save-only) stays on hold (swipes and in-book link taps go through `paginator.js`, not `app.js`, so an app-side flag would stop them saving). Blue mark after opening a book: not planned. `log.md` is still the working file; conclusions move here when the issues are settled.
- **Tests to run (fresh tab, CACHE `2026-09-29-09-18-31`):** Alice chapter 1 at size 467.45: turn pages 1-8, `probe-readback` must show `grid=exact`, `charL` at the page edge and the first row (`charT`), char rising by about one page of chars, odd pages included; reload after page 3 and page 5 lands on the same page; Go to 40%, turn a page, reload; F11 x20 (no `restore-start`); drag-resize (one refit, restore lands on the page holding the saved char, blue mark visible on text with `saved-mark outcome=marked`, `via=next-node` where the char was at a node end); cover still marks and stays on the cover; scrolled mode unchanged. Set `SWITCH_SHOW_DEBUG_INFO` and `SWITCH_PROBE_READBACK` to false afterwards.
- Files edited: `js/foliate-js/paginator.js`, `js/app.js`, `sw.js`, `spec.md`.

### 2026-09-28-23-34-29

- Applied patch **page-size-no-vh** (approved with `codenow`), after the first field test of fixed-page-size (logs 23:18-23:24, PC 1920px, Firefox, Alice; the user warned the clipboard may have held old content, and the resize paste contained no windowed drag-resize, so the drag-resize behavior is still untested).
- **Log findings (fixed-page-size):** page size and position held across F11. But a `restore-start` still fired on every F11 press: the host width flips between 482.3833 (windowed, `h=937`) and 482.3999 (fullscreen, `h>=994`), a 1/60 px difference (one Firefox layout unit), which woke `ResizeObserver` -> `scheduleRestore()`. Cause (unconfirmed, most likely): the CSS `min(var(--page-h-px), 88vh)`; `innerHeight` is rounded, `vh` is exact, so the `vh` term won by a hair in windowed mode.
- **One-time drift after "Go to 40%" is a read-back error, not a restore error:** the jump landed on page 6 and the read-back top-left char was 63656, but `goto-target` places char 63656 on page 5 (`calcPage=5`, left 2356); the first F11 restore then went to page 5 and stayed there. The saved value was wrong from the moment of the jump (a reload would also have landed on page 5). Cause unknown; suspects: page-break handling on a short page (63449 -> 63656 is only 207 chars, likely a chapter end) or `scrollLeft` rounding (start 2894 vs a boundary of about 2894.3). Not touched; needs more logs after the F11 fix.
- **Change 1, `css/style.css`:** `#book-page` height is now `var(--page-h-px, calc(var(--page-height-vh) * 1vh))` (the calc is only the fallback before `app.js` sets the variable). New `max-height: calc(100vh - 16px)` as a hard clamp far above the reference, so it binds only when the window is really smaller.
- **Change 2, `js/app.js`:** `resizeObserver` ignores changes under `RO_MIN_CHANGE_PX = 0.5` on both axes, compared with the last accepted size (vars `roLastW`, `roLastH`), so small changes cannot accumulate unnoticed. The first callback and any real size change still call `scheduleRestore()`.
- **Timeouts (no change, listed for reference):** restore path: 500 ms burst coalescing (`SWITCH_WAIT_TILL_MOST_OF_PAGE_RESIZING_BURST_SETTLES_...`), then a size poll (3 stable checks at 100 ms, cap 4 s), then up to 700 ms waiting for the confirming `relocate`, then a 500 ms post-restore grace. Also: the 600 ms settle in the window-resize refit (fixed-page-size), the 400 ms position save debounce, the 350 ms wheel lock, the 100 ms page-turn lock. With no restore on F11 they only matter for drag-resize and settings changes; not tuned. The 600 ms refit delay can be shortened (about 200 ms) at the cost of more refits during a drag.
- **Expected result:** no `restore-start` lines on F11. Limits: the top-left word can still change on a real windowed resize (the page grid); sub-0.5 px real changes are ignored (they do not reflow text). Same-model check only (diff against backups, callers, control flow).
- **Tests to run (fresh tab, CACHE bumped):** F11 x10, terminal shows no `restore-start`/`restore-done`; Go to 40% then F11 (does the page still shift once?); drag-resize the window (one refit after about 600 ms; note the top-left word before and after); reload after each; page size and proportions in Settings; paste the terminal lines for any of these.
- Files edited: `css/style.css`, `js/app.js`, `sw.js`, `spec.md`.

### 2026-09-28-23-14-00

- Applied patch **fixed-page-size** (approved with `codenow`, stamp 2026-09-28-23-12-51). Direction agreed with the user: stop trying to keep the exact top-left word across a reflow (the page grid makes that impossible), and instead keep the page size fixed so fullscreen/F11 never reflows. Analysis first: read `app.js` and `paginator.js` (relevant parts) for Test A; no browser available, so Test A was traced in code, not run.
- **Test A hypotheses (unconfirmed, no code for them):** (1) `flashFirstRowOnRestore()` wraps the landed top row in a span, splitting the text node at the page start; `getVisibleRange` accepts text nodes with `right >= start` (inclusive), so the node before the split can read as visible and the bisect lands a char or a row early. Fits the walk 8839 -> 8838 -> 8787 -> 8786 (1 char, then one row of about 51). Console check without code: `SM_READER_FLAGS.SWITCH_MARK_TEMPORARILY_FIRST_ROW_ON_PAGE_RESIZE = false`, then repeat page turns + F11 burst. (2) A page turn during a running restore (or the 500 ms grace) is not saved or shown, because `onRelocate` skips while `restoreNavGen === restoreGeneration` / `isResizing`, and `Paginator.goTo` returns silently while `#locked`. Explains a mismatched landing, not the 1-char/51-char steps. Tests B and C (stable, short of the target by 54 / 207 chars) are consistent with normal landing on the page start containing the target.
- **Page size is now a reference pixel height, not live vh.** `css/style.css`: `#book-page` height is `min(var(--page-h-px, 9999px), calc(var(--page-height-vh) * 1vh))`; the vh term only clamps when the window is smaller than the reference. `js/app.js`: new `setPageRefHeight()` (`--page-h-px` = `pageSizeVh/100 * window.innerHeight`, returns whether it changed) called from `applyGeometry()` (startup and every user geometry change, so a change made in fullscreen takes the current height).
- **Window resize handler:** no per-event `captureAnchor()`/`scheduleRestore()`. After a 600 ms settle, and only when not in `document.fullscreenElement` or display-mode fullscreen, the reference height is recomputed; if it changed: `captureAnchor()`, `setPageRefHeight()`, `scheduleRestore()`. New module var `pageRefSettleTimer`. Windowed snapshot code in the handler unchanged.
- **Fullscreen paths no longer capture or restore:** removed `captureAnchor()`/`scheduleRestore()` from `requestFullscreen()`, `exitFullscreenIfActive()`, `toggleFullscreen()`, the `fullscreenchange` handler and the `display-mode` handler. `ResizeObserver` on `#viewer-host` still restores after any real host size change (clamp case).
- **Freeze machinery dormant:** `SWITCH_KEEP_CONTAINER_AND_PAGE_SIZE_SAME_ON_FULLSCREEN_CHANGE` default `false`; `freezeFullscreenSize`, `freezeFullscreenSizeFromSnapshot`, `unfreezeFullscreenSize`, the windowed snapshot and `rememberWindowedSizesIfAtRest()` stay in the code, unused with the flag off (candidate for removal later, needs approval).
- **Trade-offs / limits:** the page no longer grows when maximizing or going fullscreen (extra space goes to the dark surround). Starting in fullscreen gives a large page; leaving fullscreen clamps once (one reflow + restore). On Android, rotation or an address-bar change counts as a settled windowed resize and refits once. If the display-mode media query does not report fullscreen, physical F11 would be treated as a windowed resize (old behavior). Not run or tested; same-model check only (diff against backups, callers, control flow); a separate review pass is recommended (restore and UI-lifecycle change).
- **Save rule (agreed principle, not changed):** the char index is saved only on an intended move (next/prev, search, go to, Contents, Book start, Furthest read), never on resize, restore or reload; reload keeps the stored value. `onRelocate` already filters this (`reason` `page`/`navigation`, skipped while `isResizing` or a running restore). Known remaining hole: a page turn during a restore or its 500 ms grace is not saved (rare now). Proposed optional **patch 2** (not applied, awaiting `codenow`): only explicit user actions may save, via a flag set by those entry points and consumed in `onRelocate`, so a restore can never write the position.
- **Other options discussed, not built:** (2) mark the saved position (not the top row) with the CSS Custom Highlight API until the next page turn, replacing `flashFirstRowOnRestore()` (no DOM wrapping); (3) scroll view with fake page turns (only if the above disappoints); (4) spacer before the top word stays dropped.
- **Tests to run (fresh tab, CACHE bumped):** F11 in/out repeatedly (page size and top-left word unchanged, no `restore-start` in the terminal); Test A (page turns then an F11 burst); drag-resize the window (one refit, position holds); page size and proportions in Settings; start in fullscreen then leave; reload (same position); phone rotation.
- Files edited: `css/style.css`, `js/app.js`, `sw.js`, `spec.md`.

### 2026-09-28-21-55-57

- Field tests only (patches from 2026-09-28-20-12-00 in place); no code changed. Logs 21:48-21:54, PC 1920px, Firefox, Alice, physical F11.
- **restore-nav-guard holds under real use.** In every test below, repeated F11 (including presses under 1s apart, and one run of ~7 presses mixed with page turns) never changed the stored `target` across restores. This was the original bug (2303 -> 2211) and it did not recur.
- **Test A (page turns immediately before an F11 burst, ~7 presses, some <1s apart):** target stayed 8839 throughout, but the restore *landing* walked backward each cycle while `goto-target`'s own geometry (`left`/`calcPage`) stayed the same: landed 8839 -> 8838 -> 8787 -> 8786 -> (relocate 8734, no matching restore-done captured). Steps of about 1 then about 51 chars, alternating. Not the flicker below (that alternates between two fixed values); this kept moving.
- **Test B (mouse-scrolled far, then 2 F11 presses, no prior page turn):** both restores landed at the same char (20070) against the same target (20124), same `goto-target` geometry both times. Stable, ~54 chars short, no drift between the two attempts.
- **Test C ("Go to 40%", then repeated fast F11 presses with no pause, no prior page turn):** both restores landed at the same char (63449) against the same target (63656), same geometry both times (`left=2356.05`, `calcPage=5` vs `calcPage` implied 6 by target). Stable, about one page short (~207 chars), no drift between attempts.
- **Working hypothesis:** B and C are the same phenomenon as the earlier "top-line flicker" entry, generalized: a restore's read-back can consistently land some distance (a line, or here a page) before the true target, but it is *reproducible* for a given geometry, not something that changes on repeat. Test A is different in kind: only there did the landing keep changing between otherwise-identical restore attempts. The only difference in test A was real page turns happening right before/interleaved with the F11 presses, which B and C did not have. Unconfirmed: whether a page turn immediately before an F11 burst is the actual trigger, or coincidence; not yet checked against `scheduleRestore`/`goTo` for overlapping in-flight calls.
- Also noted from the 21:51 log: on load, the very first `relocate` reads `pct=NaN frac=NaN pages=2 iframeOffset=-237`, self-correcting one event later to `pct=0.22 pages=3 iframeOffset=482`. Startup-only (book measured before container reached final size); self-corrects; not yet seen to cause a stuck state. Noted so it is not mistaken later for a new bug.
- **Next test (proposed, not yet run):** page turn(s) immediately followed by an F11 burst, repeated at least twice, to try to confirm or rule out the page-turn trigger for the test A walking drift.
- Files edited: `spec.md` only.

### 2026-09-28-20-12-00

- Applied three patches (approved with `codenow`), all in `js/app.js` (plus `sw.js` CACHE bump). Read `app.js` (`onRelocate`, `scheduleRestore`, `captureAnchor`, `getCurrentCharIndex`, `countCharsUpToRange`) and `paginator.js` (`getVisibleRange`, `#afterScroll`) first; `paginator.js` unchanged. Backups moved to `not_needed_after_editing/`.
- **restore-nav-guard:** new `restoreNavGen` (declared next to `restoreGeneration`). `scheduleRestore()` sets it to its generation before the char restore `try` and clears it in a `finally` (only if still its own). `onRelocate()` computes `restoreNavActive = restoreNavGen !== 0 && restoreNavGen === restoreGeneration` and skips the footer update and the save while it is true, next to the `isResizing` checks. Fixes the confirmed leak: the freeze branch clears `isResizing` without retiring the running restore, so that restore's landing was saved as a real move (2303 -> 2211 after a quick second F11). A jump that bumps `restoreGeneration` (search, a newer restore) is still saved. Terra review recommended (position-save path).
- **retry-off:** `SWITCH_RETRY_RESTORE_ONCE_IF_LANDED_EARLY` default `false` (code kept, dormant; delete if preferred).
- **blank-page-read:** new `isNoNodeRange(range)` = a collapsed range whose start container is `doc.body`, on a non-scrolled renderer page `> 1` (the paginator's fallback when a page holds no readable node). `onRelocate()` returns early on it (after the spacer check) and `getCurrentCharIndex()` returns `null` for it, so the footer/saved position keep the previous page instead of jumping to the section start (0.0006). The `page > 1` condition is required: Alice's cover also reads as a collapsed range at body (`cfi /6/2!/4`, char 0) on page 1 and must stay a valid position (found in the post-edit logic check; the first version of the helper would have ignored the cover). Limit: an image taller than a page on page 2+ of a section would also be ignored (before: it reported the section start).
- Not changed: the unexplained one-line flicker of the first char of a page (see the previous entry, corrected).
- Tests (fresh tab, CACHE bumped): F11 x10 including twice within a second: `restore-done` may land one line off but the next `restore-start` `target` stays the same value (no 2303 -> 2211); Firefox: resize until the blank page appears, footer keeps the previous page's value, reload lands on the previous page, turning past it works; cover reload still stays on the cover, prev from the header returns to the cover and reload keeps it; search jump, Go to position, Contents jump still save (reload after each); paste `relocate`/`restore-*` lines if anything looks off.
- Files edited: `js/app.js`, `sw.js`, `spec.md`.

### 2026-09-28-20-07-00

- Analysis and test results only; **no code changed, no `codenow`**. Logs from 2026-09-28 15:02-15:12 (PC 1680x908, Firefox, Alice; phone Xiaomi Mi A3 320 px wide). `sw.js` CACHE is still `2026-09-28-12-02-23`.
- **Verified OK:**
  - **tap-vs-snap** (phone): 12 `turn src=iframe-tap` events, each followed by `relocate reason=page` in the right direction; next and prev both work on the cover, header and text pages; no `reason=snap`. The earlier tap-outer-coords worry (only `host-tap` had been seen on PC) is closed.
  - **Contents jump:** in-book link (Chapter II) and menu jumps (III, IX, XII) land on page 1 of the chapter, `navigation` then `anchor`. Chapter I not tested.
  - **Reload on the cover** stays on the cover (`restore-done target=0 landed=0`, no retry needed).
  - **Search hit landing:** behaves as specified (landing = containing page, not exact char; see 2026-09-27 search entries). The search panel status shows each hit's own percentage, while the footer shows the page position, so with several hits on one page the panel value changes per hit and the footer stays the same. This is expected, not a bug. The check to make is only: after clicking a hit, the page shown contains the word and the mark is visible.
  - **Not testable:** multi-image sections (Alice has only the cover image; no other test book). A small test epub with image-only sections and one 4-image section could be built if wanted.
- **F11 drift (PC, physical F11, Alice p.2 of chapter I, size 467.45):**
  - `goto-target` `calcPage` equals the landed page in every restore (also in the Firefox resize case), so the column-boundary rounding hypothesis (`floor(x/size)+1` one page early) is **rejected**. The error is a character, not a page.
  - **Stored target is replaced by a restore result (confirmed in code 2026-09-28-20-12-00: `scheduleRestore()` frozen branch returns before `++restoreGeneration` and sets `isResizing=false`, so a running restore is not retired and its own `navigation` relocate is saved).** The saved char was 2303; at 15:03:42 a restore (gen 8) landed while the user had already pressed F11 again (`dm=true frozen=true`), and that landing was logged as `relocate reason=navigation resizing=false`, i.e. treated as a user move and saved (2211). All later restores then have `target=2211`. Unconfirmed in code (`app.js` not yet read this session); to be checked in `onRelocate` / `scheduleRestore`.
  - **Top-line flicker (cause unknown):** with identical geometry (size 467.45, page 2, start 935) the first char of the page reads 2258 (gens 12, 16) or 2211 (gens 20, 24, 28), exactly one line (about 46 chars) apart, while `goto-target` gives the same `left=482.17` and `calcPage=2` each time. (An earlier version of this entry blamed the first row being only 2 px inside the page; that does not fit, since the read-back compares horizontal positions. Corrected 2026-09-28-20-12-00.) It shows in the footer and matches "works about 7 times, then drifts" only if it also overwrote the saved position; see the confirmed cause below.
  - **`restore-retry` is useless as implemented:** in all recorded cases `landed2 == landed` (623, 500), and a page-start landing is normal when the target is mid-page (gap 45, 110, 233 are within one page). Candidate for removal (flag `SWITCH_RETRY_RESTORE_ONCE_IF_LANDED_EARLY`).
  - Physical F11 quickly pressed twice (about 1 s apart) is the trigger for the replaced-target case; after exit there is a transient reflow at size 540.57 (pages 10) with `reason=anchor` relocates that are ignored.
- **Blank page (Firefox, reproduced by resizing the window):**
  - It is the **last text page of the Gutenberg header section**: page 5 of 7 (size 430.38) and page 6 of 8 (size 361.92); pages 0 and the last are spacers. Its read-back is `char=1`, empty snippet (no node found, falls back to the section start). At size 467.45 (pages 5) there is no blank page; the last page reads 733.
  - Section DOM (Alice `pg-header`, 4174 bytes): `div#pg-header` (boilerplate, `page-break-after: always` in `pgepub.css`), `div#pg-start-separator`, empty `div.fig`, `h1` title, `h2` "by Lewis Carroll", `hr`, `h2` Contents, `table`. `pgepub.css` also has `h2 { page-break-before: always; padding-top: 1em }`. So the section legitimately has short pages (title alone, author alone, Contents) and the log shows them (chars 851, 883, 942 at size 361.92). Which element produces the empty last page is not confirmed; suspects: forced breaks in a multi-column layout, or the table. Confirm by a console read-only check on that blank page (`getContents()[0].doc`: bounding rect right edge of `table` versus `documentElement.scrollWidth`).
  - Consequence: on that page the footer/saved position points at the section start (char 1); you cannot stay one page before/after it because the reading jumps.
- **Proposed fixes (awaiting `codenow`; order proposed to the user):** (1) a restore must never write the stored position, only a user navigation does, and a display-mode/fullscreen change during a restore must retire it; (2) remove `restore-retry` (flag off or code removed); (3) on a non-spacer page with no readable node, report the previous page's last char (or skip the update) instead of the section start. Behavior-sensitive (position save path): Terra review recommended after implementation.
- **Carried over from `handoff_part1.md` / `handoff_part2.md`** (kept here so they are not lost):
  - Still open and unchanged: under-filled last row; first-row flash reliability (wrong line vs drift vs no flash); persistent mark/highlight; pseudo-page scroll mode; dead `SWITCH_SCROLL_EXACT_CHAR` probe flag.
  - Terra review pending for: paginator changes (spacer offset 08-57-26, tap-vs-snap 12-02-23), freeze work, unified chrome.
  - Old saved positions can land up to (number of earlier media elements) chars off until re-saved by normal reading (image-chars).
  - Terminal beacon `SWITCH_SHOW_DEBUG_INFO` floods (about 50 `relocate` lines per F11 press); set `false` when not needed; console flag `SWITCH_LOG_DEBUG_TO_BROWSER_CONSOLE` is independent. `/__debug` 404 lines in the terminal are expected (`python -m http.server` has no such file).
  - Process: `sw.js` CACHE must equal the newest patch stamp; fresh tab per test; on the phone use "Load fresh app" or clear site data; deliverables go to `/mnt/user-data/outputs/`.
- Next tests: F11 x10 with pauses (not pressed twice within a second) and once pressed twice quickly; Firefox blank-page console check above; multi-image test book (needs a test epub).
- Files edited: `spec.md`.

### 2026-09-28-12-02-23

- Patch **tap-vs-snap** (`js/foliate-js/paginator.js`): `#onTouchEnd` now skips `snap()` when no `touchmove` occurred during the touch (a pure tap). Cause (phone log, Mi A3): a tap fired `pointerup` -> `next()` (animated scroll), then `touchend` -> rAF -> `snap(0,0)` re-pinned the current page and cancelled the turn (every tap on a text page was followed by `relocate reason=snap` at the same page; the cover worked only because the section jump is decided from the target page). Swipes and drags still snap. Vendored file changed; Terra review recommended.
- Patch **restore-diag-retry** (`js/app.js`): (a) new debug event `goto-target` (target char rect `left`, `top`, `left/size` ratio, `calcPage = floor(left/size)+1`, plus geometry) emitted whenever `getRangeForCharIndex`'s anchor is resolved, to test the column-boundary rounding hypothesis for the F11 one-page-early landing; (b) after a restore's char goTo, if `landed < target` and the gap is at most `SWITCH_RESTORE_RETRY_MAX_CHAR_GAP` (2000), wait 150ms and goTo the target once more (events `restore-retry`, `restore-retry-done` with `landed2`); flag `SWITCH_RETRY_RESTORE_ONCE_IF_LANDED_EARLY` (default true); skipped when superseded or fullscreen-frozen. A legitimately reflowed target (mid-page) triggers one harmless extra goTo to the same page; (c) `window-resize` beacon throttled to one per 400 ms.
- Not included: the empty-page read-back fix (blank page inside a section reads the section start), still open in `handoff_part1.md`.
- Tests: phone fresh app (CACHE bumped): taps on text pages turn pages, swipes still work, prev tap on a text page; terminal shows `turn` followed by `relocate reason=page`. F11 x10: paste `goto-target`, `restore-start`, `restore-retry*`, `restore-done` lines.
- Files edited: `js/app.js`, `js/foliate-js/paginator.js`, `sw.js`, `spec.md`.

### 2026-09-28-11-27-11

- Patch **image-chars**: images and other embedded media now count as 1 virtual char each, so image-only pages and sections have their own position (Alice: cover = char 0..1, Gutenberg header starts at 1; reload stays on the cover). One shared rule in `js/app.js` (`CHAR_MEDIA_SEL`, `charAcceptNode`, `charNodeLen`): text nodes count code points; each outermost `img, svg, canvas, video, audio, object, embed, iframe, hr` counts 1; text inside those is ignored; a section with no text and no media counts 1. Used by `countVisibleCharsInDoc` (section totals/prefixes), `countCharsUpToRange` (rewritten: counts everything strictly before the range start using boundary comparison, so element-anchored ranges are now exact and a range inside a media element does not count it), `getRangeForCharIndex` (media element targeted with `selectNode`; text-only behavior unchanged, `remaining <= len` kept except when the next node is media) and the search text builder (U+FFFC placeholder per media element keeps hit offsets aligned).
- Old saved positions load but land up to (number of earlier media elements) chars off; normal reading re-saves the corrected value. Position percentages shift negligibly.
- Patch **spacer-read-fix**: `onRelocate` ignores relocates read while `renderer.page` is 0 or the last page (blank spacer pages; `isOnSpacerPage()`), so the footer/saved position no longer jumps to the section prefix (0.815 after 7.85).
- Patch **debug-log-events**: new flag `SWITCH_LOG_DEBUG_TO_BROWSER_CONSOLE` (default true; the terminal `/__debug` beacon stays under `SWITCH_SHOW_DEBUG_INFO`). `debugBeacon` now prints extras on the console line. New events, each with `size,start,page,pages,iframeOffset,fs,dm,frozen`: `relocate` (reason, charIdx, spacer, resizing), `turn` (src, x, width, dir), `restore-start`, `restore-done` (target, landed), `fullscreenchange`, `display-mode`, `window-resize`.
- Not addressed: F11 top-left drift (untested), under-filled last row.
- Tests (fresh tab, CACHE bumped): Alice reload on cover stays on the cover, footer 0.0000000 then a small positive value on the header page; multi-image sections step page by page; prev from a section's first page no longer shows 0.815-style jumps; Go to position / Contents / search still land correctly; console and terminal show `[SM DEBUG]` lines.
- Files edited: `js/app.js`, `sw.js`, `spec.md`.

### 2026-09-28-09-29-09

- Applied patch **tap-outer-coords**: the in-iframe `pointerup` handler in `wireContentDoc` (`js/app.js`) now computes the tap in outer coordinates (`frameElement.getBoundingClientRect().left + e.clientX - #viewer-host rect left`) and calls `turnAt(x, host width)`, like the `#viewer-host` margin handler. The old `clientX - renderer.start` formula remains only as fallback when there is no frame element. Cause: the iframe sits one spacer page inside the container, so the old value was always in `[-size, 0)` and every tap on text/image meant "previous" (at the first page, nothing). Margin/black-screen taps were unaffected.
- `SWITCH_DEFAULT_HIDE_BOTTOM_POSITION` set to `false` (existing flag; the position line now shows by default on fresh installs; a stored `showPosition` still wins, so existing devices need F10 or a site-data clear).
- New flag `SWITCH_DISPLAY_PERCENTAGE_SIGN_IN_POSITION` (default `false`): `formatPct()` appends `%` only when true. Affects footer, goto status and search status text (nothing parses the displayed text back; `promptGoto` still accepts a trailing `%`).
- Not addressed: Alice "reload lands on page 2" — separate symptom, untested against the 08-57-26/08-58-34 patches. If it persists, run the handoff console check after reload and report `iframeOffset`, `start`, `page`, `pages`.
- Tests (fresh tab, `sw.js` CACHE bumped): Alice tap right/left on text, on the image, on margins, on black screen (phone and PC); swipes still work; footer shows digits without `%`; F10 toggle.
- Files edited: `js/app.js`, `sw.js`, `spec.md`.

### 2026-09-28-08-58-34

- Applied patch **windowed-snapshot-at-rest** (proposed in 2026-09-28-08-55-02): new `rememberWindowedSizesIfAtRest()` in `js/app.js` (skips while `document.fullscreenElement`, `displayModeMql.matches` or `fullscreenFrozen`, and when `#book-page` has zero size) refreshes the windowed pixel snapshot at the end of `openBook()` and at the end of every `scheduleRestore()` run (covers size/frame/proportion/font/spacing changes, resize, and the settle after leaving fullscreen). `rememberWindowedSizes()`, the freeze functions and the `resize` listener are unchanged. Expected: first physical F11 press pins a valid snapshot instead of reflowing; later presses no longer pin a stale or already-grown one.
- Tests (fresh tab, `sw.js` CACHE bumped): open book → F11 immediately (first press, no prior resize) → % and top row unchanged; F11 out and in repeatedly; change page size/frame/proportions windowed, then F11; resize window, then F11; F11 with Library/Settings open.
- Both 2026-09-28 patches are now applied.
- Files edited: `js/app.js`, `sw.js`, `spec.md`.

### 2026-09-28-08-57-26

- Applied patch **restore-page-spacer-offset** (proposed in 2026-09-28-08-55-02): `js/foliate-js/paginator.js` `#scrollToRect()` again scrolls to `floor(x/size) + 1` (`-1` RTL; `offset = size * (rtl ? -page : page)`), and `#getVisibleRange()` (paginated branch) again searches `start - size .. end - size` (sign flipped for RTL), i.e. upstream's paired page-spacer math. Snapshot-once `snapSize`, dust epsilon and the scrolled-mode branches are unchanged. The `SWITCH_SCROLL_EXACT_CHAR` probe (default off) got the same one-page shift so it stays consistent with the pair.
- Expected: reload no longer lands on the blank spacer page; section-last-page read-back no longer falls to the section prefix (Contents/Robinson Crusoe 0.00% gone). Ordinary pages are unchanged in behavior (the two offsets used to cancel).
- Tests to run in a fresh tab (`sw.js` CACHE bumped): Alice reload after opening at the first page; Contents last-page %; Robinson Crusoe same; numbers.epub 608↔408 fullscreen toggle (overshoot regression check); first-row flash lands on the true top row; Contents → chapter jump; page turns across section boundaries both directions; Go to position round trip.
- Not applied: **windowed-snapshot-at-rest** (F11 first-press drift) — still awaiting `codenow`.
- Files edited: `js/foliate-js/paginator.js`, `sw.js`, `spec.md`.

### 2026-09-28-08-55-02

- Analysis only (read `app.js`, `paginator.js`, `view.js`, `epub.js`, css in full; vendored files diffed against upstream foliate-js `78914ae`; Alice epub spine inspected). No code changed, no `codenow` given. **Not yet confirmed in a browser** (none available to the assistant); one console check below decides it.
- **Root-cause hypothesis for the open reload-blank + stuck 0.0000% (Alice, Robinson Crusoe, Mirror of Simple Souls) and the Contents-page 0.00%: the page-spacer offset was removed from only half of its consumers.** `View.expand()` makes the iframe wrapper `expandedSize + 2*size` wide with the iframe centered, so the iframe sits one page (`size`) inside the container: container page `p` shows iframe page `p-1`, and container page 0 is a blank spacer. Upstream compensates in two places: `#scrollToRect` uses `floor(x/size) + 1`, and `#getVisibleRange` searches `start - size .. end - size`. The vendored `paginator.js` removed both (2026-09-26-19-15-58 and 23-05-17; the fraction path `#scrollToAnchor` still has its `+1`). Consequences:
  - Scrolling to a char lands one page early (displays iframe page `q-1`), and the visible-range read-back is one page late (reports iframe page `d+1` for displayed page `d`). The two errors cancel for ordinary mid-section pages (restore round-trips), which is why most pages look fine.
  - They do not cancel at section edges. Target on the first page of a section → offset 0 → the blank spacer page shown (white page, no iframe, so `wireContentDoc` tap handlers never fire; black surround still turns pages; footer shows the char position, 0 for a book left on its first page). Fresh opens use the fraction path (`+1` intact) and render fine.
  - Last page of a section: read-back window is one page past the content, `getVisibleRange` falls back to `doc.body`, `countCharsUpToRange` returns 0 for an element start, so the reported char = the section prefix. Sections with prefix 0 show exactly 0.00%. Alice's cover section has zero text, so Contents (prefix 0) reads 0.00% on its last page, then the next section is correct (e.g. 1.2%). Robinson Crusoe is the same shape. Books whose Contents section has a nonzero prefix show a small nonzero value instead, hence "not some other books".
  - Cover flash on reload: `init({showTextStart})` shows section 0, then `computeBookCharPrefixes()` runs, then the char jump lands on the spacer.
  - Handoff hypotheses: (a) `bookTotalChars==0` and (b) element-anchored ranges returning 0 — (b) is the visible symptom above, (a) is not needed. Parse-fallback asymmetry and unfreeze-on-change stay ruled out.
- **Why earlier verification missed it:** the 2026-09-26-20-26-22 entry accepted `scrollToRect-verify landed=true` / `diag-anchor-verify diff: 0` as proof that dropping the `+1` fixed the overshoot. Both checks compare quantities in the same shifted coordinates, so they are blind to a one-page displacement. The +301-char overshoot (target 2226 → landed 2527) seen in 2026-09-26-16-49-35/18-27-48 with both upstream halves present was therefore probably not caused by the `+1`; likelier the column-width truncation (`Math.trunc` → `Math.round`, fixed 23-12-22). Unconfirmed — retest numbers.epub 608↔408 after any restore.
- Side effects of the displacement to re-check after a fix: first-row flash may highlight the wrong row (the "seems unreliable" thread), and saved char/percentage is one page ahead of the displayed page in ordinary pages.
- **Confirming check (console, on the white page):** `const r=document.querySelector('foliate-view').renderer; const f=r.getContents()[0].doc.defaultView.frameElement; console.log({size:r.size, iframeOffset:f.getBoundingClientRect().left-f.parentElement.getBoundingClientRect().left, start:r.start, page:r.page, pages:r.pages})`. Prediction: `iframeOffset ≈ size`, `start = 0`, `page = 0`.
- **Proposed patch "restore-page-spacer-offset"** (awaiting `codenow`): in `js/foliate-js/paginator.js` put back, as a pair, the `+1` (`-1` for RTL) in `#scrollToRect` (both `pageIndex` and the `offset` formula; keep the snapSize snapshot, dust epsilon, exact-char probe) and the `- size` window shift in `#getVisibleRange` (`this.start - size, this.end - size`, RTL sign as upstream). Files: `js/foliate-js/paginator.js`, `sw.js` (CACHE bump), `spec.md`. Behavior-sensitive (restore/save path): independent review recommended.
- **F11 first-press drift (hypothesis, `js/app.js`):** the physical-F11 path pins the `windowedPageW/H/HostW/H` snapshot, but `rememberWindowedSizes()` runs only from the window `resize` listener and the DOM-fullscreen freeze. First F11 press: no resize has happened yet, snapshot is zeros, `freezeFullscreenSizeFromSnapshot()` returns early, page reflows. Sometimes later: `resize` fires before the display-mode media query flips, so the snapshot is taken at the already-grown size; or the snapshot is stale after page-size/frame/proportions changes (no window resize). Exiting fullscreen resizes while windowed and refreshes it, hence "usually first time only".
- **Proposed patch "windowed-snapshot-at-rest"** (awaiting `codenow`): in `js/app.js` call `rememberWindowedSizes()` after `openBook` completes and after geometry/proportion changes settle, skipping it while `displayModeMql.matches` or `document.fullscreenElement`. Alternative (needs approval, changes native F11): intercept F11 keydown and use the DOM fullscreen path that pins sizes before the change.
- Files edited this session: `spec.md`.

### 2026-09-27-21-13-28

- Page proportions: Settings → Page geometry → Proportions combo — Reader classic 3:4 (default), A4 (210:297), Letter (8.5:11). Persisted `pageRatio`, applied via the normal geometry path (capture + restore).
- Files edited: `index.html`, `js/app.js`, `sw.js`, `spec.md`.
- Unfreeze-on-change: `applyGeometry()`/`applyStyles()` release the fullscreen pin first, so size/frame/proportions/margins/fonts take effect immediately in fullscreen (capture + restore holds position); next fullscreen entry re-freezes. Without it the pinned px silently overrode the vars until exit.
- Files edited: `js/app.js`, `sw.js`, `spec.md`.
- Fullscreen-entry reflow report open: entry path verified quiet on paper (freeze-then-bail, no `goTo`; proportions ratio-blind; `applyGeometry`/`applyStyles` unreachable on entry) — prime suspect is a stale mixed-version tab across six rapid patches, not logic. Awaiting fresh-tab (`19-02-57`) % pairs per path.

### 2026-09-27-18-51-02

- Tap-coords fix: page taps compared against the iframe's full-book width, so nearly every tap went prev (walk down to 0%). Taps now decide in visible coords (`clientX − renderer.start` vs `renderer.size`); page-padding handler corrected the same way (`clientX − host.left`).
- Files edited: `js/app.js`, `sw.js`.
- "Load fresh app" Settings button: worker update check, drop caches, unregister, hard reload (escapes the mobile stale-cache trap; next boot registers fresh).
- Files edited: `index.html`, `js/app.js`, `sw.js`, `spec.md`.

### 2026-09-27-18-23-13

- Position-toggle defaults: `SWITCH_CLICKING_ON_POSITION_SHOWS_GOTO_DIALOG=false` (clicking position toggles it on/off; goto dialog stays on the header — mobile needs no dialog); labels `Top menu (F9)` / `Bottom position (F10)`; `SWITCH_DEFAULT_HIDE_TOP_MENU=true` + `SWITCH_DEFAULT_HIDE_BOTTOM_POSITION=true` (fresh installs start hidden; stored choices win). Toggle-back-on path: hover zone reveals, then click.
- Files edited: `js/app.js`, `sw.js`, `spec.md`.
- Overlay chrome: uniform margins always, title/position absolutely overlaid in the margin bands (title left/top, position centered/bottom, half-margin offset); toggles are `display:none` (fully invisible, zero geometry, restores never fire for chrome); hover zones display-aware; classic mode preserved when the flag is off. Flag: `SWITCH_PUT_TOP_MENU_AND_POSITION_TO_HALF_SPACE_VERTICALLY_AND_USE_SAME_HORIZONTAL_AND_VERTICAL_MARGINS=true`.
- Files edited: `css/style.css`, `js/app.js`, `sw.js`, `spec.md`.
- Deselect-first: tap-down selection state consumes the whole tap (browser natively collapses on tap-down, so tap-up checks lied); `pointercancel` reset included.
- Files edited: `js/app.js`, `sw.js`.

### 2026-09-27-17-37-26

- Chrome round2: merged menu anchored below its trigger, left-aligned to the ▾ (transform reset kills the old centering); `✓` checkmarks before Book menu/Position labels (blank when off); F9/F10 toggles routed through `updateChromeVisibility()` (capture + restore — the pure applicator left reflows uncorrected); hover reveal reworked to top/bottom ~20% page zones (works both-hidden too by dropping the symmetric class while revealed; transient reflow accepted, next restore corrects). New: `SWITCH_BOTTOM_POSITION_ITALIC=true` (position line italic, read live).
- Files edited: `js/app.js`, `sw.js`, `spec.md`.
- First-row flash: `SWITCH_MARK_TEMPORARILY_FIRST_ROW_ON_PAGE_RESIZE=true` + `..._MS=3000` (both live) — landed top row tinted blue for MS ms after every restore, unwrapped after; skipped while a search mark is active. Reliability report open (wrong-line vs drift vs no-flash undiagnosed).
- Files edited: `js/app.js`, `sw.js`.
- Menu move-out: `#goto-menu` moved out of `#sidebar` to body level (sidebar `display:none` hid it regardless of its own display).
- Files edited: `index.html`, `sw.js`.
- Chrome fonts: `SWITCH_TOP_MENU_FONT_SIZE_IN_PERCENTAGE=90` + `SWITCH_BOTTOM_POSITION_FONT_SIZE_IN_PERCENTAGE=90` (position set inline on `#pct-display`, beating the old 12px pin; `CHROME_FONT_RATIO` retired); `SWITCH_DEFAULT_BOTTOM_POSITION_DECIMALS_DIGITS=3` (fresh installs; stored combo wins).
- Files edited: `js/app.js`, `sw.js`.

### 2026-09-27-16-35-36

- Unified chrome: sidebar nav + goto menu merged into one centered menu (Book start, Furthest read, Table of Contents — Go to position…, Search book — Full screen (F11), Book menu (F9), Position (F10) — Library, Settings; dropped Most recent, Cover Image, Toggle menu). New flags: `SWITCH_OPEN_LAST_VIEWED_BOOK_ON_START=true` (last opened book, else Library), `SHOW_LEFT_RED_MENUBAR=false` (sidebar hidden, hot-corner dead), `SWITCH_BACK_BUTTON_LOCATION_IN_APP='top'/'bottom'/'none'`, `SWITCH_SHOW_COMPONENTS_TITLE_IN_APP=true`. Back buttons (=Return) in Library/Settings/Contents; Contents hides the import row. Persisted: `showBookMenu`/`showPosition` (F9/F10, hover-reveal when off), `startFullscreen` (off default). Removed: footer arrows, old show/hide selects, linkMenuFullscreen, include-books checkbox (export never includes books); Backup renamed Export & Import. Selection: any click with selected text clears it first, never turns the page.
- Files edited: `index.html`, `css/style.css`, `js/app.js`, `sw.js`, `spec.md`.
- Spacer-pad verdict: dropped. Insert-then-remove math ends off-grid (removal pulls the anchor back a page; compensating scroll isn't page-quantized) — the rejected exact-char probe's UX at far higher risk. Space/`nbsp` fillers worse (collapsing, uncomputable push, `normalize()` counter poisoning). Page-bar (containing page) stands.
- Search-engine-on-selection verdict: dropped. Nothing blocks the native context menu (no `contextmenu` prevention; only chrome has `user-select: none`), so the browser's own engine-on-selection already works.

### 2026-09-27-15-32-22

- Freeze fullscreen size (`SWITCH_KEEP_CONTAINER_AND_PAGE_SIZE_SAME_ON_FULLSCREEN_CHANGE=true`): entering fullscreen pins `#book-page` + `#viewer-host` at pre-fullscreen pixel sizes (viewport growth goes to the dark surround), so the paginator never reflows and no position restore runs (`scheduleRestore()` bails while frozen, resetting `isResizing`). Menu/`F` path freezes before `requestFullscreen()` (unfreezes if the request fails); physical F11 (no DOM event) pins remembered windowed sizes via `display-mode: fullscreen` (best-effort, browser-dependent). Follow-up: pin fractional `getBoundingClientRect()` sizes, not integer `offsetWidth`/`clientWidth` — integer pinning caused a sub-pixel reflow (few-char footer drift, changed bottom line). Verified: top line and footer % hold across toggles.
- Files edited: `js/app.js`, `sw.js`, `spec.md`.

### 2026-09-27-14-51-15

- Diagnostic cleanup: removed read-only diagnostics (`dbg#` console logs, `getVisibleRange-verify`/`scrollToRect-verify`/`afterScroll-verify`, `bisectNode-final`/`offset-check`, `diag-*`, restore/size-poll/onRelocate beacons, `diagnoseEpubDocMismatch()`, anchor `verifyAndReturn`). Kept `debugBeacon()` infra plus `search-mark`/`search-confirm` until the mark is visually confirmed. No behavior change.
- Files edited: `js/app.js`, `js/foliate-js/paginator.js`, `sw.js`, `spec.md`.
- Numbers.epub verdict: accepted as pathological. Single-giant-text-node docs misread by `getVisibleRange`/`bisectNode` (union-rect conflation: each bisect half spans many pages, merged box steers wrong by hundreds of chars); real multi-node books stay page-accurate. Per-fragment (single-char-at-mid) fix deferred — shared behavior-sensitive path, needs Terra review; revisit only if a real-world book shows it. No code this entry.
- Section-index fix: `getCurrentCharIndex` now matches the range's own document against `getContents()` instead of blind `contents[0]?.index` (wrong prefix when several views mounted — multi-section/spread/reflow). Fallback `contents[0]` → `0`; single-section behavior identical.
- Files edited: `js/app.js`, `sw.js`, `spec.md`.

### 2026-09-27-14-09-57

- Search mark lifetime: page turns no longer clear the transient match mark (clearing on turn erased it before the found region could be examined — the mark's own evidence). Mark now lives until next search step, overlay close, or book switch; still transient, never persisted. Landing itself unchanged (page bar: footer 0.53% vs target 0.54% agree; containing page, not exact char).
- Files edited: `js/app.js`, `sw.js`, `spec.md`.

### 2026-09-27-13-39-03

- Search-stable-goto: `doSearchBook` jumps now go through the restore settle path (`stableSearchGoTo` — bumps `restoreGeneration` to retire in-flight restores, awaits `waitForPaginatorSizeStable`, clears `isResizing` so the landing saves). Root cause for fresh-open misses: fonts/images reflow shifted columns between rect measurement and scroll, stranding viewport and mark; pending restores could also override the landing. `markSearchMatch` reports per-jump outcome (`search-mark` beacon: `marked`/`collapsed`/`bad-node`/`no-live-doc`/`threw`) — the path was fully silent before. Verdict on footer unevenness (0.38→0.46→0.47→0.77 on plain prose): reads are geometrically edge-true (`offset-check inWindow=true`); erratic windows come from turns/restores during unsettled layout, same race.
- Files edited: `js/app.js`, `sw.js`, `spec.md`.

### 2026-09-27-11-23-18

- Plan (no code this entry): page-accuracy bar confirmed on numbers.epub and a multi-section real book (exact-return flip-flops `1874→1789→1874`, `1010→886→1010`; sub-page dips are toggled-layout page starts, not drift). Next: probe exact-char landing behind an internal flag (`SWITCH_SCROLL_EXACT_CHAR`, default off, `#scrollToRect` only — `offset = mappedLeft` instead of `page*size`) so the sliced-columns tradeoff can be judged empirically before any product call. Pseudo-page scroll mode (scrolled flow + viewport jumps) deferred until after the probe. Queued behind that: configurable search-engine on selection; mark/highlight stays a later feature (section 11).
- Files edited: `spec.md`.

### 2026-09-27-11-14-07

- Footer `%` unified on the char anchor in int mode (open, page-turn, restore, decimals combo all read it; CFI mode keeps fraction). Combo range widened 0-4 → 0-7. Restores now move the footer with the landed char instead of repainting the stale pre-resize fraction.
- Terra review of the int/snapshot work: `#scrollToRect` sign/bypass/epsilon accepted; open-restore `isResizing` guard had a strand-on-reject hole (`view.init()` throws → saving silently stops) — fixed with `try/finally` in `openBook`. True hangs (never-settling awaits) stay out of scope. Also corrected: `landed=true` + `match=false` is ordinary page-alignment (target later in page), not only diagnostic cross-talk.
- Files edited: `js/app.js`, `sw.js`, `spec.md`.

### 2026-09-27-10-41-54

- Integer position persistence (`FLAGS.SWITCH_SAVE_LOCATION_AS_CFI=false`, default): save/load/restore/menu (`Most recent`, `Furthest`) use the integer char index only; stored rows are a superset (`charIndex`/`furthestCharIndex` + legacy CFI/fraction) so the flag flips losslessly. Open prefers the stored int over the live text-start read and swallows init relocates (`isResizing` guard); saves flush on `pagehide`/hidden to not lose turns inside the 400ms debounce.
- Paginator `#scrollToRect()`: snapshot `size` once per call (pageIndex and offset share it — kills inter-read drift), residual one-sided dust epsilon `1e-4*size`, bypasses `#scrollToPage` (untouched, other callers unaffected). Verified on numbers.epub (`landed=true`, anchor stable) and a multi-section real book (section prefix mapping `idx=8` correct, page-accurate both toggle directions).
- Footer `%` decimals now a Settings combo (`pctDecimals`, 0-4, default 2, global persisted).
- Files edited: `js/app.js`, `js/foliate-js/paginator.js`, `index.html`, `sw.js`, `spec.md`.

### 2026-09-26-23-29-21

- Applied and tested two candidate fixes for **Problem A** against `numbers.epub`, both `codenow`-approved:
  1. **`#getVisibleRange()` (`paginator.js`, non-scrolled branch)**: was shifting the window passed to the module-level `getVisibleRange()`/`bisectNode` back by a full page width (`this.start - size`, `this.end - size`) instead of using the actual current viewport bounds. Removed the shift; now passes `this.start`, `this.end` directly, matching the scrolled branch. Verified: only caller is `#afterScroll()`, no other code depended on the old shift.
  2. **`columnize()` (`paginator.js`)**: candidate from the 2026-09-26-18-27-48 entry, now tested — `column-width: Math.trunc(columnWidth)px` → `Math.round(columnWidth)px`, to stop the CSS column grid from drifting away from the `pageIndex * this.size` grid used elsewhere.
- **Result: inconclusive/negative for Problem A.** A first test run (before `sw.js`'s cache was bumped) showed no change, as expected since stale code was still being served. A second, confirmed-fresh run (cache bumped to `sw.js:4 CACHE='sm-reader-2026-09-26-23-20-15'` after both edits) still shows the top-left char landing off by a page-scale amount on every real (`reason=navigation`) restore — roughly 1155, 776, and 594 characters off across three consecutive navigation events in one test. Both changes are verified correct in isolation (confirmed via diff against backup and checking all call sites) and are being kept, but **neither resolves the core mismatch**.
- Investigated why two `reason=navigation` events in a row sometimes target the exact same text and still land differently (e.g. target "1226…" landing at "1085…" then, moments later, the same target "1226…" landing at "1118…"): this is `app.js`'s own existing `scheduleRestore()` retry logic (not a bug, not a race) — it does the char-index-based `goTo()`, compares the landed snippet to `lastStableSnippet`, and on mismatch retries via `view.goTo(cfi)` (a different anchor-resolution path). Both paths land wrong because both ultimately go through the same still-broken part of `paginator.js`. Confirmed by reading `onRelocate()`/`captureAnchor()`/`scheduleRestore()`/`resizeObserver` in full this session (`js/app.js`, uploaded but not edited this session).
- Also checked the `View` class's iframe geometry (`paginator.js`) to sanity-check fix #1 above: `#view.document` is a separate iframe document, sized to its full multi-column width with no internal scrolling of its own, so a node's `getBoundingClientRect()` inside it is on the same absolute `pageIndex * this.size` scale as `this.start`/`this.end`, unaffected by the outer `#container`'s scroll. This confirms fix #1 is the geometrically correct direction, not backwards — the remaining page-scale error is coming from somewhere else not yet identified.
- Proposed but **not yet implemented** (awaiting `codenow`): add read-only logging to `#getVisibleRange()`/`#afterScroll()` for `this.start`, `this.end`, and the raw `rect.left`/`rect.right` of the first node the treewalker actually accepts, before `bisectNode` runs — to see the real numbers the algorithm is working with directly, instead of inferring from text snippets.
- Files edited this session: `js/foliate-js/paginator.js` (twice — the two fixes above), `spec.md`. `js/app.js` was uploaded and read in full this session but not edited.

### 2026-09-26-22-18-15

- Implemented and confirmed a fix for **Problem B** (the anchor-corruption bug from the 2026-09-26-20-26-22 entry): `onRelocate()` (`js/app.js`) now only updates `lastStableCfi`/`lastStableFraction`/`lastStableCharIndex` (and triggers the debounced position save) when `e.detail.reason` is `'page'` (an actual page turn) or `'navigation'` (TOC/"Go to position"/"Most recent page"/"Furthest read", or the restore mechanism's own goTo/goToFraction calls — already excluded separately via the existing `isResizing` guard). Every other reason (`'anchor'`, `'snap'`, `'scroll'`, `'selection'`) is now correctly treated as paginator drift only, never saved. `captureAnchor()` was also changed to stop re-deriving `lastStable*` from the live view position on every call when not resizing — that path was exactly what let post-resize drift bypass the new filter — keeping only a no-anchor-yet-at-all fallback.
- Confirmed via fresh `numbers.epub` log (two consecutive f11 toggles): the restore's requested target (`char=2802`, `cfi=.../1:2788,/1:3364`) stayed **identical** across both toggles — no more drift compounding the saved anchor between toggles. Problem B is fixed.
- **Problem A (still open, unfixed)**: each individual restore attempt still lands on the wrong page (this session's repro: requested char 2802 landed at 2527, then at 2195 on the next toggle). Log analysis this session **rules out insufficient settle time** as the cause: `this.size` (`paginator.js`) had already stopped changing across several consecutive calls (identical value logged 3+ times in a row) before `scheduleRestore-fire` ran, and the debounce had already waited past that point (1000ms quiet + 1000ms grace, per `FLAGS.SWITCH_WAIT_TILL_PAGE_RESIZE_SETTLES_BEFORE_SYNCING_TOP_LEFT_CHAR_IN_MS`). Waiting longer would not help.
- New finding: the restore's own `goTo(target)` **is verified correct at the moment it completes** (`diag-anchor-verify diff: 0`, `scrollToRect-verify landed=true`) — but immediately afterward, one more `onRelocate` fires with a *different* `cfi` at the same reported `char`, and that later event is what `getCurrentCharIndex()` reads back as the final (wrong) landed position. This points at something re-triggering a reflow/re-anchor pass *after* the verified-correct landing — candidate suspects: `paginator.js`'s `#afterScroll()`, or the trailing `#scrollToAnchor(this.#anchor, 'anchor', 'render')` call in `render()` re-running against a possibly-stale `this.#anchor`. Not yet inspected this session.
- Files edited this session: `js/app.js` (`onRelocate()`, `captureAnchor()`), `spec.md`. No `paginator.js` changes made.

### 2026-09-26-20-26-22

- Confirmed the prior session's candidate fix in `paginator.js`'s `#scrollToRect()` (dropping the `+1`/`-1` page-index adjustment) resolves the one-page overshoot: analyzed `scrollToRect-verify` logs from real restore calls (`source=public-api reason=navigation`) across two separate test rounds (numbers.epub, single-section) — the clean ~300-char/one-page overshoot is gone. One isolated `landed=false` case was diagnosed as a sub-pixel/floating-point rounding artifact in the diagnostic's own comparison (target 0.27px from a page boundary, browser-rounded `scrollLeft` vs. unrounded float target) — not a real position bug, no fix needed there.
- Found a **separate, still-open bug**: after a resize/fullscreen toggle, the top-left character can still land wrong even though the restore's own Range is verified correct pre-scroll (`diag-anchor-verify diff: 0`) and the paginator's page-window check passes (`scrollToRect-verify landed=true`). Root cause (from log analysis, not yet fixed): `this.size` (the live measured page width in `paginator.js`) is still changing across consecutive `onExpand` calls when `app.js`'s `scheduleRestore()` debounce fires, so the restore's math is self-consistent for a layout that's already stale by the time `getCurrentCharIndex()` re-reads the actual on-screen position afterward (confirmed case: target char 2226, `landedCharIdx` read back as 1647). This then compounds: once `isResizingOffTimer` fires and `isResizing` flips to `false`, the next drifted `onRelocate` (still `reason: 'anchor'` from ongoing reflow) is no longer guarded and overwrites `lastStableCfi`/`lastStableCharIndex` with the wrong position — corrupting the anchor before any further toggle.
- Likely fix directions (not yet applied, no `codenow` given): re-arm `isResizingOffTimer` on every `scheduleRestore()` call, not only on `captureAnchor()`; and/or re-verify the landed char-index after settling and retry rather than trusting a single restore pass. Flagged to the user as lifecycle/concurrency-sensitive — worth a review pass beyond same-model checking before implementing.
- Files edited this session: `spec.md`. No code files edited (`paginator.js`'s fix was applied and confirmed in a prior session; this session's `app.js` findings are diagnosis only, not yet implemented).


- Fixed scroll dead until keyboard (`js/app.js:445` listeners before `view.open`, explicit `wireContentDoc` for initial doc).
- Top-left char pinned on resize/fullscreen/page-size/frame/margins via char-index anchor (`js/app.js:191` `bookTotalChars`/`bookCharPrefixes`, `getCurrentCharIndex:271`, `getRangeForCharIndex:289` live-doc anchor), debounced `1000ms` (`FLAGS.SWITCH_WAIT_TILL_PAGE_RESIZE_SETTLES_BEFORE_SYNCING_TOP_LEFT_CHAR_IN_MS`), grace `isResizingOffTimer`.
- Added `FLAGS.SWITCH_SHOW_DEBUG_INFO: true` + `debugBeacon` (`js/app.js:120`) `fetch /__debug?char=... 404` visible in `python -m http.server` terminal alongside `Serving HTTP...`.
- Service worker cache timecoded `sw.js:4 CACHE='sm-reader-2026-09-26-12-58-00'` so `GET /js/app.js` is `200` not `304` stale.
- Headers timestamped per `rules.md:72` (files edited: `js/app.js`, `sw.js`, `css/style.css`, `index.html`, `js/foliate-js/*.js`, `spec.md`).

### 2026-09-26-15-39-58

- Root cause found for why the prior session's `reason:'navigation'` filter in `waitRelocate()` (`js/app.js`) never worked: vendored `js/foliate-js/view.js`'s `#onRelocate()` (`view.js:319`) destructured `reason` from the paginator's `relocate` event but never included it in `this.lastLocation` before re-dispatching — so every relocate event `app.js` could see had `reason: undefined`, and `waitRelocate()` always fell through to its 700ms timeout instead of genuinely confirming. Fixed by adding `reason` to the object at `view.js:324`.
- Added `reason` to the `onRelocate-drift`/`onRelocate-stable` debug beacons (`js/app.js`) to make this visible in the log.
- Confirmed via log: `reason` now correctly shows `anchor` and `navigation`, and `waitRelocate()` now genuinely catches a real `navigation` event (not the timeout fallback).
- **Bug still not resolved even with genuine confirmation**: `landedCharIdx` (from fix #5, prior session) still doesn't match the target `charIdx` after a confirmed navigation. This now points away from timing/confirmation and at a real mismatch between the "counting" document built by `computeBookCharPrefixes()` and the live document `makeAnchor()`/`getRangeForCharIndex()` (`js/app.js`) walks. Two observed mismatches both shrank the target's local offset by roughly the same ~78% ratio, suggesting a systematic (not fixed-offset) undercount — not yet root-caused.
- Service worker cache bumped: `sw.js:4 CACHE='sm-reader-2026-09-26-15-39-16'`, so edited files aren't served stale to the browser.
- Files edited this session: `js/foliate-js/view.js`, `js/app.js`, `sw.js`, `spec.md`.

### 2026-09-26-16-49-35

- Investigated user-reported top-left char flip on repeated resize/fullscreen toggles (e.g. `552`→`408`→`552`, `608`→`408`→`608`), using `numbers.epub`/similarly-structured test books (each with a single spine section, numbers 1-1000 as body text) to decode `__debug` log char offsets against known page positions.
- Ruled out: transient/unlogged mid-resize flicker (all reported flips fully match logged `after-goTo-char` `landedCharIdx` pairs); random noise (magnitude is consistently ~800-1400 chars, close to one page's worth, and each forward jump exactly reverses on the next toggle); and the `reason` fix from the prior session (confirmed working correctly, but does not resolve this).
- Found `landedCharIdx` is consistently **greater than** the requested `charIdx` in every logged case, in both directions of a toggle. A page containing char X can only start at or before X, so a `goTo(target)` that reliably overshoots past the target rules out "expected page-boundary rounding" (this session's working theory going in, based on the prior session's provisional read) as the explanation — this looks like a genuine off-by-one-page overshoot in the paginator's page selection, not benign snapping.
- Reviewed `js/app.js` in full. Confirmed one separate, real bug in `getCurrentCharIndex()` (`js/app.js:280`, `idx = contents[0]?.index` at line 288): it assumes the renderer's first mounted content view is always the one holding the current position, with no check against the range's own document. Silent for every book tested so far (all single-section), but will misattribute the char-index prefix on any multi-chapter/multi-section book once more than one content view is mounted at once (e.g. during a resize/reflow transition, or a spread layout). Not yet fixed — flagged for a future patch alongside whatever the overshoot turns out to be.
- Root cause of the overshoot itself not yet found: needs `js/foliate-js/paginator.js` (specifically `#scrollToAnchor`/`#scrollToPage`, referenced but not inspected in the prior session's log-only investigation) to confirm whether the page-index math there has a hardcoded `+1` or similar. Not yet uploaded this session.
- No code changes made this session (investigation/log analysis only, no `codenow` given).
- Files edited this session: `spec.md`.

### 2026-09-26-18-27-48

- Read `js/foliate-js/paginator.js` in full (was not yet uploaded in prior sessions). Confirmed the `+1` in `#scrollToRect`/`#scrollToAnchor` is intentional (one page-width spacer reserved at each end by `View.expand()`), not a bug.
- Added temporary, call-counter-tagged `console.log` debug logging (`[dbg#N] ... source=...`) to `#scrollToAnchor`, `#scrollToRect`, and `#scrollToPage` in `paginator.js`, tagging every call site (`onExpand`, outer `render()`, `keyboard-selection`, `focusin`, `public-api`) so browser-console output shows which call produced which page/rect values. `sw.js` cache bumped so the change wasn't served stale. No logic changed.
- Found (and then ruled out) a real double-invocation: `#scrollToAnchor(this.#anchor)` fires twice per resize tick — once from `View.expand()`'s `onExpand` callback, once again immediately after from the outer `render()`. Confirmed via console log that both calls compute identical `rect.left`/`pageIndex`/`page` values every time; the second call is redundant but not the cause of the drift.
- Reproduced 608→408→608 with the new logging. Decoded browser console output (via `[SM DEBUG]`/`after-goTo-char` beacons cross-referenced with `[dbg#N]` lines): toggle 1 target `char=2226` → `landedCharIdx=2527` (+301 chars); toggle 2 target `char=2527` → `landedCharIdx=2226` (exact reverse). Confirmed the overshoot is present after the very first, fully-settled `#scrollToPage` call — not a byproduct of the double-call above.
- New working theory (not yet confirmed): `columnize()` sets `column-width: Math.trunc(columnWidth)px` (paginator.js, truncated/integer), while `this.size` used for the page-index math (`Math.floor(rect.left / this.size) + 1`) is the unrounded fractional container width. Over several columns this truncation gap could compound, drifting the browser's real column boundaries away from the theoretical `n × this.size` grid enough to land one column off by page 3+.
- Not yet done: instrumenting a post-scroll re-measurement of the same anchor rect to confirm the column-boundary-drift theory directly, and/or trying `Math.round`/no-truncation on `column-width` as a candidate fix. Awaiting user direction on which to try first.
- Files edited this session: `js/foliate-js/paginator.js`, `sw.js`, `spec.md`.

### 2026-09-26-19-11-19

- Received `handoff.md` continuing the investigation: prior session's own log-diffing (not yet run this session) proposed two candidate hypotheses ahead of the column-width-truncation theory above — (a) `epub.js` builds two different documents for the same section (`loadDocument()`'s direct parse, used for character counting, vs. `loadReplaced()`'s parse→mutate→serialize→reparse round-trip, used for the live rendered doc), and (b) the char-index→Range anchor walker in `app.js`'s `getRangeForCharIndex()` misplaces the Range it hands to the paginator.
- Added a one-off diagnostic to `app.js` (`diagnoseEpubDocMismatch()`, gated by `FLAGS.SWITCH_RUN_EPUB_DOC_MISMATCH_DIAGNOSTIC_ON_BOOK_OPEN`): on book open, compares section 0's counting doc (`section.createDocument()`) against the live mounted doc (`view.renderer.getContents()`) via `body.textContent`. **Result: identical, `lenDiff: 0`, `firstDiff: -1`.** Hypothesis (a) is ruled out — the two documents are byte-for-byte the same for section 0.
- Added a second diagnostic to `app.js` (`getRangeForCharIndex()`'s `makeAnchor`, gated by `FLAGS.SWITCH_RUN_ANCHOR_VERIFY_DIAGNOSTIC`): re-walks the anchor's own returned Range with `countCharsUpToRange()` on the same live doc and logs whether it round-trips to the requested offset. **Result: `diff: 0` on both directions of a reproduced 2226↔2527 toggle.** Hypothesis (b) is ruled out — the anchor walker builds the Range at exactly the requested offset.
- With both `app.js`-side hypotheses ruled out, the correct Range is confirmed to be handed to `paginator.js`'s `renderer.goTo(target)` and still lands on the wrong page — refocusing suspicion on `paginator.js` itself, specifically the still-unconfirmed `column-width` truncation theory from the prior session (2026-09-26-18-27-48).
- Added a third diagnostic to `paginator.js`'s `#scrollToRect()`: after the scroll settles, checks whether the original target rect's `mappedLeft` actually falls inside the landed viewport window (`this.start <= mappedLeft < this.end`), logged as `scrollToRect-verify`. Theory-agnostic: `landed=false` would confirm the pageIndex/offset math itself is wrong; `landed=true` would point further downstream (`#afterScroll`'s visible-range computation, or the `relocate` consumer). Not yet run — awaiting the log.
- No fix applied yet this session; all three additions are read-only diagnostics behind flags/temp logging, easily removed once resolved.
- `sw.js` cache bumped by the user directly this session (not by the assistant).
- Files edited this session: `js/app.js` (twice), `js/foliate-js/paginator.js`, `spec.md`. `js/foliate-js/epub.js` and `handoff.md` were read but not edited.
