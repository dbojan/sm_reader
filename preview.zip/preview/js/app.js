// SM Reader - app.js
// last modified (utc): 2026-09-29-09-39-04
// instructions: on modify, update string.
import './foliate-js/view.js'

/* ---------------- IndexedDB ---------------- */

const DB_NAME = 'sm_reader'
const DB_VERSION = 1
let dbp = null

function openDB() {
  if (dbp) return dbp
  dbp = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION)
    req.onupgradeneeded = () => {
      const db = req.result
      if (!db.objectStoreNames.contains('books')) db.createObjectStore('books', { keyPath: 'id' })
      if (!db.objectStoreNames.contains('positions')) db.createObjectStore('positions', { keyPath: 'id' })
      if (!db.objectStoreNames.contains('fonts')) db.createObjectStore('fonts', { keyPath: 'name' })
      if (!db.objectStoreNames.contains('settings')) db.createObjectStore('settings', { keyPath: 'key' })
    }
    req.onsuccess = () => resolve(req.result)
    req.onerror = () => reject(req.error)
  })
  return dbp
}

async function idbGet(store, key) {
  const db = await openDB()
  return new Promise((resolve, reject) => {
    const tx = db.transaction(store, 'readonly')
    const req = tx.objectStore(store).get(key)
    req.onsuccess = () => resolve(req.result || null)
    req.onerror = () => reject(req.error)
  })
}
async function idbGetAll(store) {
  const db = await openDB()
  return new Promise((resolve, reject) => {
    const tx = db.transaction(store, 'readonly')
    const req = tx.objectStore(store).getAll()
    req.onsuccess = () => resolve(req.result || [])
    req.onerror = () => reject(req.error)
  })
}
async function idbPut(store, value) {
  const db = await openDB()
  return new Promise((resolve, reject) => {
    const tx = db.transaction(store, 'readwrite')
    tx.objectStore(store).put(value)
    tx.oncomplete = () => resolve()
    tx.onerror = () => reject(tx.error)
  })
}

/* simple, fast, non-cryptographic-strength fingerprint: good enough to tell books apart */
/* A plain (non-cryptographic) 64-bit-ish hash, deliberately not using
   SubtleCrypto: crypto.subtle only exists in secure contexts (https, or
   exactly "localhost"), so it throws when the app is opened over plain
   http from another device on the LAN — e.g. a phone hitting the PC's
   http://192.168.x.x:PORT during local testing. This only needs to tell
   books apart, not resist tampering, so a fast manual hash is fine. */
async function fingerprint(file) {
  const buf = await file.slice(0, 1_000_000).arrayBuffer()
  const bytes = new Uint8Array(buf)
  let h1 = 0xdeadbeef ^ bytes.length
  let h2 = 0x41c6ce57 ^ bytes.length
  for (let i = 0; i < bytes.length; i++) {
    const b = bytes[i]
    h1 = Math.imul(h1 ^ b, 2654435761)
    h2 = Math.imul(h2 ^ b, 1597334677)
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909)
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909)
  const hex = (h1 >>> 0).toString(16).padStart(8, '0') + (h2 >>> 0).toString(16).padStart(8, '0')
  return hex + '-' + file.size
}

/* ---------------- settings ---------------- */

const BUNDLED_FONTS = [
  { id: 'jost', label: 'Jost (sans, Futura-like)', family: "'Jost', system-ui, sans-serif" },
  { id: 'system-sans', label: 'System sans-serif', family: 'system-ui, sans-serif' },
  { id: 'system-serif', label: 'System serif', family: 'Georgia, "Times New Roman", serif' },
]

const SIZE_STEPS = [12, 14, 16, 18, 20, 24, 28, 32]

const THEMES = {
  white: { bg: '#ffffff', fg: '#1a1a1a' },
  cream: { bg: '#fffdf5', fg: '#1a1a1a' },
  night: { bg: '#1c1c1c', fg: '#dcdcdc' },
}

const DEFAULT_SETTINGS = {
  fontId: 'jost',
  customFontName: '',
  uploadedFontName: '',
  fontSize: 18,
  theme: 'cream',
  lineSpacing: 1.4,
  pageSizeVh: 88,
  frameSizePct: 11,
  pageRatio: 'reader',
  pctDecimals: 2,
  showBookMenu: true,
  showPosition: true,
  startFullscreen: false,
  clickPositionForGoto: false,
}

// Exposed on window so it can be flipped live from devtools while testing.
const FLAGS = {
  SWITCH_CLICK_LEFT_OR_RIGHT_ON_BLACK_SCREEN_WHEN_NO_RED_MENU_PRESENT_GOES_TO_PREV_NEXT_PAGE: true,
  SWITCH_HIDE_TOP_BOOK_MENU_AND_POSITION_AT_BOTTOM_MAKES_TOP_AND_BOTTOM_MARGINS_SAME_SIZE_AS_LEFT_AND_RIGHT_MARGINS: true,
  SWITCH_SHOW_DEBUG_INFO: true,
  // Renamed 2026-09-27 (was SWITCH_WAIT_TILL_PAGE_RESIZE_SETTLES_BEFORE_SYNCING_TOP_LEFT_CHAR_IN_MS,
  // 1000ms): this constant now only coalesces a burst of scheduleRestore()
  // triggers (resize/fullscreen/sidebar/slider calls firing in quick
  // succession) into a single pending restore. It is NOT what confirms the
  // layout has actually settled anymore - that job now belongs to the
  // SWITCH_POLL_PAGINATOR_SIZE_* poll below, added for Problem A (see
  // handoff.md / spec.md 2026-09-26 sessions: this.size kept changing for
  // 30+ calls during a fullscreen transition, well past the old fixed wait).
  SWITCH_WAIT_TILL_MOST_OF_PAGE_RESIZING_BURST_SETTLES_BEFORE_SYNCING_TOP_LEFT_CHAR_IN_MS: 500,
  // Problem A fix (2026-09-27): after the burst-coalescing wait above,
  // poll the paginator's own (already-public) `size` getter
  // (view.renderer.size) instead of trusting a fixed timer to know the
  // resize/fullscreen transition has actually finished. Proceeds once
  // `size` reads the same value STABLE_CHECKS_REQUIRED times in a row, at
  // INTERVAL_MS apart, or gives up and proceeds anyway after MAX_WAIT_MS
  // (safety cap so a genuinely-never-settling size can't hang the restore
  // forever).
  SWITCH_POLL_PAGINATOR_SIZE_BEFORE_RESTORE_INTERVAL_MS: 100,
  SWITCH_POLL_PAGINATOR_SIZE_STABLE_CHECKS_REQUIRED: 3,
  SWITCH_POLL_PAGINATOR_SIZE_MAX_WAIT_MS: 4000,
  // How long after a *confirmed* restore to keep ignoring relocate events
  // (isResizing stays true) as leftover paginator settling noise (e.g.
  // render()'s own trailing #scrollToAnchor(..., 'render') call) before
  // trusting relocates as real position changes again. Separate from the
  // burst-coalescing wait above on purpose - this guards a different,
  // narrower case (see spec.md follow-up entry for pros/cons of instead
  // waiting for trailing relocates to genuinely stop, rather than a fixed
  // grace window).
  SWITCH_POST_RESTORE_GRACE_IGNORE_TRAILING_RELOCATE_EVENTS_IN_MS: 500,
  // 2026-09-27-10-07-59 (persist-int-only): when false (default), the saved
  // location is the integer char index only (lastStableCharIndex /
  // furthestCharIndex) — CFI/fraction are never read for save, load, restore
  // or menu jumps. When true, the legacy CFI/fraction paths are used. Stored
  // rows are a superset of both so the flag can flip without data loss.
  SWITCH_SAVE_LOCATION_AS_CFI: false,
  // PROBE 2026-09-27-11-24-24 (exact-char landing test): when true,
  // #scrollToRect() scrolls to the char's own pixel instead of the page
  // start (expect sliced columns + a re-snap jump on the next page turn).
  // Default off; flip live from devtools (window.SM_READER_FLAGS), read by
  // the vendored paginator. No settings UI until the product call is made.
  // Result: forcing foliate to land on char results with scren errors. No.
  SWITCH_SCROLL_EXACT_CHAR: false,
  // 2026-09-27-15-10-46 (freeze-fullscreen-size): when true, entering
  // fullscreen pins #book-page and #viewer-host at their pre-fullscreen
  // pixel sizes (inline styles; viewport growth goes to the dark surround),
  // so the paginator never reflows and no restore is needed. Cleared on
  // exit. When false, the page scales with the viewport as before (spec §8).
  // 2026-09-28-23-12-51 (fixed-page-size): default false. The page size is now a
  // reference pixel height (--page-h-px, see applyGeometry), so nothing needs
  // pinning; the freeze/snapshot code below stays, dormant.
  SWITCH_KEEP_CONTAINER_AND_PAGE_SIZE_SAME_ON_FULLSCREEN_CHANGE: false,
  // 2026-09-27-15-41-42 (flash-first-row): when true, the landed top row is
  // tinted blue for _MS milliseconds after every restore landing, then
  // unwrapped (transient, never persisted; skipped while a search mark is
  // active). Both devtools-flippable, read live at each flash; no Settings UI.
  // 2026-09-29-08-27-26 (saved-char-mark): default false; replaced by the saved
  // char mark below (code kept, dormant).
  SWITCH_MARK_TEMPORARILY_FIRST_ROW_ON_PAGE_RESIZE: false,
  SWITCH_MARK_TEMPORARILY_FIRST_ROW_ON_PAGE_RESIZE_MS: 3000,
  // 2026-09-29-08-27-26 (saved-char-mark): after every restore, the saved char
  // (the word it starts) is tinted blue with the CSS Custom Highlight API (no
  // DOM wrapping) until the next page turn / jump. Transient, never persisted.
  // Needs a browser with the API (Firefox 140+, Chrome 105+); otherwise no mark.
  SWITCH_MARK_SAVED_CHAR_UNTIL_NEXT_PAGE_TURN: true,
  // 2026-09-29-08-27-26 (read-back probe): paginator.js logs one
  // `probe-readback` event per page turn / jump (page start, first accepted
  // node, bisect steps, char rects). Debug only, read live by paginator.js.
  SWITCH_PROBE_READBACK: true,
  // 2026-09-27-16-35-36 (unified-chrome): open the last viewed book on
  // start when true (fresh install with no opened book lands on Library).
  SWITCH_OPEN_LAST_VIEWED_BOOK_ON_START: true,
  // ...show the left red sidebar at all (false hides it with no way back;
  // the merged menu opens from the page header instead). Exact name kept.
  SHOW_LEFT_RED_MENUBAR: false,
  // ...where the Back buttons sit in Library/Settings/Contents:
  // 'top', 'bottom' or 'none'. Devtools-flippable, read live.
  SWITCH_BACK_BUTTON_LOCATION_IN_APP: 'top',
  // ...whether Library/Settings/Contents show their title headers.
  SWITCH_SHOW_COMPONENTS_TITLE_IN_APP: true,
  // 2026-09-27-16-55-53 (chrome-font-pct): header/position font sizes as a
  // percentage of the content font size. Both devtools-flippable, read live.
  SWITCH_TOP_MENU_FONT_SIZE_IN_PERCENTAGE: 90,
  SWITCH_BOTTOM_POSITION_FONT_SIZE_IN_PERCENTAGE: 90,
  // ...default footer-% decimals for installs with no stored choice yet
  // (a stored pctDecimals always wins; change the combo to override).
  SWITCH_DEFAULT_BOTTOM_POSITION_DECIMALS_DIGITS: 3,
  // 2026-09-27-17-37-26: footer position in italic when true. Read live.
  SWITCH_BOTTOM_POSITION_ITALIC: true,
  // ...fresh-install defaults (stored showBookMenu/showPosition always win).
  SWITCH_DEFAULT_HIDE_TOP_MENU: true,
  SWITCH_DEFAULT_HIDE_BOTTOM_POSITION: false,
  // 2026-09-28-09-29-09: append '%' to displayed positions (footer, goto and
  // search status) when true. Read live.
  SWITCH_DISPLAY_PERCENTAGE_SIGN_IN_POSITION: false,
  // 2026-09-28-11-27-11 (debug-log-events): print every debug event to the
  // browser console too (terminal beacon stays under SWITCH_SHOW_DEBUG_INFO).
  // Read live.
  SWITCH_LOG_DEBUG_TO_BROWSER_CONSOLE: true,
  // 2026-09-28-12-02-23 (restore-diag-retry): after a restore, if the landed
  // top-left char is earlier than the target (seen after F11: one page early),
  // wait 150ms and goTo the target once more. Gap limit in chars. Read live.
  // 2026-09-28-20-12-00 (retry-off): default false. Logs showed landed2 == landed
  // in every retry (a page-start landing is normal for a mid-page target).
  SWITCH_RETRY_RESTORE_ONCE_IF_LANDED_EARLY: false,
  SWITCH_RESTORE_RETRY_MAX_CHAR_GAP: 2000,
  // 2026-09-27-17-52-01 (overlay-chrome): uniform margins always, with the
  // title/position overlaid onto the margin bands (zero layout impact, so
  // toggles never reflow and restores never fire for chrome). Read live.
  SWITCH_PUT_TOP_MENU_AND_POSITION_TO_HALF_SPACE_VERTICALLY_AND_USE_SAME_HORIZONTAL_AND_VERTICAL_MARGINS: true,
}
window.SM_READER_FLAGS = FLAGS
// read-back probe hook: lets the vendored paginator use the same beacon
window.SM_READER_DEBUG_BEACON = (event, extra) => debugBeacon(event, extra)

function debugOn() { return FLAGS.SWITCH_SHOW_DEBUG_INFO === true || FLAGS.SWITCH_LOG_DEBUG_TO_BROWSER_CONSOLE === true }
// debug-log-events (2026-09-28-11-27-11): paginator geometry for every event.
// iframeOffset should be about `size` (one leading spacer page, View.expand()).
function debugGeom() {
  try {
    const r = view?.renderer
    let off = ''
    try { const f = r.getContents()[0].doc.defaultView.frameElement; off = Math.round(f.getBoundingClientRect().left - f.parentElement.getBoundingClientRect().left) } catch {}
    return { size: r?.size, start: r?.start, page: r?.page, pages: r?.pages, iframeOffset: off, fs: !!document.fullscreenElement, dm: !!displayModeMql?.matches, frozen: fullscreenFrozen }
  } catch { return {} }
}
// spacer pages: container page 0 (leading) and pages-1 (trailing) hold no book content
function isOnSpacerPage() {
  try { const r = view?.renderer; return !!r && !r.scrolled && r.pages > 2 && (r.page <= 0 || r.page >= r.pages - 1) } catch { return false }
}
function debugBeacon(event, extra = {}) {
  if (!debugOn()) return
  try {
    const cfi = extra.cfi ?? lastStableCfi ?? view?.lastLocation?.cfi ?? ''
    const frac = extra.frac ?? lastStableFraction ?? view?.lastLocation?.fraction ?? ''
    const charIdx = extra.charIdx ?? lastStableCharIndex ?? getCurrentCharIndex?.() ?? ''
    const pct = frac !== '' && frac != null ? (frac * 100).toFixed(2) : (charIdx !== '' && charIdx != null && bookTotalChars ? (charIdx / bookTotalChars * 100).toFixed(2) : '')
    // top-left snippet for char-level check (30 chars)
    let snippet = ''
    try {
      const r = extra.range ?? view?.lastLocation?.range
      if (r) snippet = String(r).slice(0, 30)
    } catch {}
    let q = `event=${encodeURIComponent(event)}&pct=${encodeURIComponent(pct)}&frac=${encodeURIComponent(String(frac))}&char=${encodeURIComponent(String(charIdx))}&cfi=${encodeURIComponent(String(cfi).slice(0,120))}&snippet=${encodeURIComponent(snippet)}`
    // diagnostic-only passthrough: any extra key not already handled above
    // (e.g. idx/prefix/local from encode, secIdx/secOffset from decode) is
    // appended as-is, so char-index round-trip debugging can be read
    // straight off the terminal log without touching any other behavior.
    const knownKeys = new Set(['cfi', 'frac', 'charIdx', 'range'])
    let xs = ''
    for (const [k, v] of Object.entries(extra)) {
      if (knownKeys.has(k)) continue
      q += `&${encodeURIComponent(k)}=${encodeURIComponent(String(v))}`
      xs += ` ${k}=${String(v)}`
    }
    // appears in python -m http.server terminal as GET /__debug?... 404 -
    if (FLAGS.SWITCH_SHOW_DEBUG_INFO) fetch(`/__debug?${q}`, { cache: 'no-store', method: 'GET' }).catch(() => {})
    if (FLAGS.SWITCH_LOG_DEBUG_TO_BROWSER_CONSOLE) console.log(`[SM DEBUG] ${event} pct=${pct}% frac=${frac} char=${charIdx}/${bookTotalChars} cfi=${String(cfi).slice(0,80)} snippet="${snippet}"${xs}`)
  } catch {}
}

let settings = { ...DEFAULT_SETTINGS }

async function loadSettings() {
  const row = await idbGet('settings', 'reader')
  if (row) settings = { ...DEFAULT_SETTINGS, ...row.value }
  // chrome-font-pct: fresh installs (no stored choice) take the flag default
  if (row?.value?.pctDecimals == null) {
    const d = parseInt(FLAGS.SWITCH_DEFAULT_BOTTOM_POSITION_DECIMALS_DIGITS ?? 3, 10)
    settings.pctDecimals = Math.min(7, Math.max(0, isNaN(d) ? 3 : d))
  }
  // position-toggle-defaults (2026-09-27-18-23-13): fresh installs start
  // with chrome hidden when the flags say so; stored choices always win
  if (row?.value?.showBookMenu == null) {
    settings.showBookMenu = !(FLAGS.SWITCH_DEFAULT_HIDE_TOP_MENU === true)
  }
  if (row?.value?.showPosition == null) {
    settings.showPosition = !(FLAGS.SWITCH_DEFAULT_HIDE_BOTTOM_POSITION === true)
  }
  applyGeometry()
}
async function saveSettings() {
  await idbPut('settings', { key: 'reader', value: settings })
}

// fixed-page-size (2026-09-28-23-12-51): returns true when the value changed.
function setPageRefHeight() {
  const px = Math.round((settings.pageSizeVh / 100) * window.innerHeight * 100) / 100
  const cur = document.documentElement.style.getPropertyValue('--page-h-px')
  const next = px + 'px'
  if (cur === next) return false
  document.documentElement.style.setProperty('--page-h-px', next)
  return true
}
function applyGeometry() {
  // 2026-09-27-19-02-57 (unfreeze-on-change): a user geometry change while
  // frozen releases the pin first, so it takes effect now through the normal
  // capture + restore path (next fullscreen entry re-freezes). Without this
  // the pinned px silently overrides the vars until exit.
  if (fullscreenFrozen) unfreezeFullscreenSize()
  if (view && lastStableCfi) captureAnchor()
  document.documentElement.style.setProperty('--page-height-vh', settings.pageSizeVh)
  // fixed-page-size (2026-09-28-23-12-51): reference page height in px from the
  // window as it is right now (startup / user geometry change). Fullscreen never
  // recomputes it; see the settled window-resize handler.
  setPageRefHeight()
  document.documentElement.style.setProperty('--page-margin-pct', settings.frameSizePct)
  // page-proportions (2026-09-27-18-56-31): width:height — Reader classic
  // 3:4, US Letter 8.5:11, ISO A4 210:297
  const ratios = { reader: 0.75, a4: 210 / 297, letter: 8.5 / 11 }
  document.documentElement.style.setProperty('--page-ratio', ratios[settings.pageRatio] ?? ratios.reader)
  if (view && lastStableCfi) scheduleRestore()
}

/* uploaded font: stored as a data URL, registered as a @font-face named 'UserFont' */
async function loadUploadedFont() {
  const row = await idbGet('fonts', 'user-uploaded')
  if (!row) return null
  const style = document.createElement('style')
  style.dataset.userfont = '1'
  style.textContent = `@font-face { font-family: 'UserFont'; src: url(${JSON.stringify(row.dataUrl)}); }`
  document.head.appendChild(style)
  return row.originalName
}

function currentFontFamily() {
  if (settings.uploadedFontName) return `'UserFont', system-ui, sans-serif`
  if (settings.customFontName) return `"${settings.customFontName}", system-ui, sans-serif`
  const f = BUNDLED_FONTS.find(f => f.id === settings.fontId) || BUNDLED_FONTS[0]
  return f.family
}

/* ---------------- app state ---------------- */

const $ = sel => document.querySelector(sel)
const $$ = sel => Array.from(document.querySelectorAll(sel))

// 2026-09-27-10-41-54 (pct-decimals-setting): footer % with configurable
// decimals (settings.pctDecimals, combo 0-7; default from
// SWITCH_DEFAULT_BOTTOM_POSITION_DECIMALS_DIGITS when nothing stored).
function formatPct(fraction) {
  const d = Math.min(7, Math.max(0, settings.pctDecimals ?? 2))
  return (fraction * 100).toFixed(d) + (FLAGS.SWITCH_DISPLAY_PERCENTAGE_SIGN_IN_POSITION === true ? '%' : '')
}
function refreshPctDisplay() {
  if (!view) return
  // pct-from-char (2026-09-27-10-49-44): in int mode the footer shows the
  // stored/landed char position, never the stale pre-resize fraction.
  if (FLAGS.SWITCH_SAVE_LOCATION_AS_CFI !== true && lastStableCharIndex != null && bookTotalChars) $('#pct-display').textContent = formatPct(lastStableCharIndex / bookTotalChars)
  else if (lastStableFraction != null) $('#pct-display').textContent = formatPct(lastStableFraction)
  else if (lastStableCharIndex != null && bookTotalChars) $('#pct-display').textContent = formatPct(lastStableCharIndex / bookTotalChars)
}

let view = null
let currentBookId = null
let saveTimer = null
// Immediate write of the current stable anchor (same payload as the debounced
// save below). Flushed on pagehide/hidden so the last page-turns are not lost
// when the page closes within the 400ms debounce window.
function savePositionNow() {
  if (!view || currentBookId == null) return
  if (lastStableCfi == null && lastStableCharIndex == null) return
  idbPut('positions', { id: currentBookId, cfi: lastStableCfi, fraction: lastStableFraction, furthestFraction, charIndex: lastStableCharIndex, furthestCharIndex, savedAt: Date.now() })
}
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') { clearTimeout(saveTimer); savePositionNow() } })
window.addEventListener('pagehide', () => { clearTimeout(saveTimer); savePositionNow() })
let furthestFraction = 0
let furthestCharIndex = null // int-only companion to furthestFraction (persist-int-only)
let lastStableCfi = null
let lastStableFraction = null
let lastStableSnippet = null
let lastStableCharIndex = null
let bookTotalChars = 0
let bookCharPrefixes = []
let isResizing = false
// search-book-panel (2026-09-27-12-08-27): query kept till reload (module var,
// never persisted); per-section visible-text cache cleared on every openBook;
// lastSearchLandedChar lets repeated Previous/Next step past the same match.
let lastSearchQuery = ''
let lastSearchQueryForStep = ''
let lastSearchLandedChar = null
let searchTextCache = []
// transient current-match mark (2026-09-27-12-42-49): inline-styled span in the
// live doc only (book-doc stylesheet untouched); cleared on next search step,
// book switch and overlay close — never persisted. Page turns deliberately
// keep it (2026-09-27-14-09-57): clearing on turn erased the mark before the
// found region could be examined.
let searchMark = null

// image-chars (2026-09-28-11-27-11): one shared counting rule. Text nodes count
// their code points; each outermost media element (image, svg, canvas, video,
// audio, object, embed, iframe, hr) counts as exactly 1 virtual char, so
// image-only pages/sections get positions of their own. Text inside a media
// element is ignored. Every walker (section totals, read-back, char -> range,
// search text) must use these helpers so the numbers always agree.
const CHAR_MEDIA_SEL = 'img,svg,canvas,video,audio,object,embed,iframe,hr'
const CHAR_WALK_SHOW = NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT
function charAcceptNode(n) {
  if (n.nodeType === 1) {
    if (!n.matches?.(CHAR_MEDIA_SEL)) return NodeFilter.FILTER_SKIP
    if (n.parentElement?.closest?.(CHAR_MEDIA_SEL)) return NodeFilter.FILTER_SKIP // nested: outer one counts
    return NodeFilter.FILTER_ACCEPT
  }
  const p = n.parentElement
  if (!p) return NodeFilter.FILTER_REJECT
  const tag = p.tagName?.toLowerCase()
  if (tag === 'script' || tag === 'style') return NodeFilter.FILTER_REJECT
  if (p.closest?.(CHAR_MEDIA_SEL)) return NodeFilter.FILTER_REJECT
  if (!n.nodeValue?.trim()) return NodeFilter.FILTER_SKIP
  return NodeFilter.FILTER_ACCEPT
}
function charNodeLen(n) { return n.nodeType === 1 ? 1 : [...(n.nodeValue ?? '')].length }
function countVisibleCharsInDoc(doc) {
  const walker = doc.createTreeWalker(doc.body, CHAR_WALK_SHOW, { acceptNode: charAcceptNode })
  let total = 0
  for (let n = walker.nextNode(); n; n = walker.nextNode()) total += charNodeLen(n)
  return total
}
// chars strictly before the range start. A media element that contains the
// start is the current char itself (not counted); text before it is.
function countCharsUpToRange(doc, range) {
  if (!range) return 0
  const walker = doc.createTreeWalker(doc.body, CHAR_WALK_SHOW, { acceptNode: charAcceptNode })
  const sc = range.startContainer, so = range.startOffset
  const pos = doc.createRange()
  pos.setStart(sc, so); pos.collapse(true)
  const nr = doc.createRange()
  let total = 0
  for (let n = walker.nextNode(); n; n = walker.nextNode()) {
    if (n === sc) { total += [...(n.nodeValue ?? '').slice(0, so)].length; break }
    if (n.nodeType === 1 && n.contains(sc)) break
    if (n.nodeType === 1) nr.setStartBefore(n); else nr.setStart(n, 0)
    nr.collapse(true)
    if (nr.compareBoundaryPoints(Range.START_TO_START, pos) < 0) total += charNodeLen(n)
    else break
  }
  return total
}
async function computeBookCharPrefixes() {
  if (!view?.book) return
  const sections = view.book.sections
  bookCharPrefixes = []
  bookTotalChars = 0
  for (let i = 0; i < sections.length; i++) {
    bookCharPrefixes[i] = bookTotalChars
    try {
      const doc = await sections[i].createDocument()
      // empty (no text, no media) section still counts 1 virtual char
      if (doc) bookTotalChars += Math.max(1, countVisibleCharsInDoc(doc))
    } catch {}
  }
}
// blank-page-read (2026-09-28-20-12-00): paginator's getVisibleRange returns a
// collapsed range at doc.body when a page holds no readable node (blank page
// inside a section). Real positions never look like that, EXCEPT the first
// text page of an image-only section (Alice cover reads as a collapsed range
// at body, char 0), so only pages after the first text page count.
function isNoNodeRange(range) {
  try {
    const r = view?.renderer
    if (!r || r.scrolled || !(r.page > 1)) return false
    const sc = range?.startContainer
    return !!range && range.collapsed && sc?.nodeType === 1 && sc === sc.ownerDocument?.body
  } catch { return false }
}
// blank-page-save (2026-09-29-09-39-04): a page with no readable node has no
// char of its own. Its position is the last char of the last counted node that
// starts before the page window (the last text the reader has seen), so a
// reload lands on that page whichever direction the blank page was reached
// from. LTR horizontal paginated only; null otherwise (nothing is saved).
function getCharBeforeBlankPage(range) {
  try {
    const r = view?.renderer
    const doc = range?.startContainer?.ownerDocument
    if (!r || r.scrolled || !doc?.body || !doc.defaultView || !view?.book) return null
    const cs = doc.defaultView.getComputedStyle(doc.body)
    if (cs.direction === 'rtl' || !/^horizontal/.test(cs.writingMode || 'horizontal-tb')) return null
    const winStart = (r.page - 1) * r.size // iframe coords of this page's left edge
    const walker = doc.createTreeWalker(doc.body, CHAR_WALK_SHOW, { acceptNode: charAcceptNode })
    const rg = doc.createRange()
    let total = 0
    let best = null
    for (let n = walker.nextNode(); n; n = walker.nextNode()) {
      const len = charNodeLen(n)
      let rect
      if (n.nodeType === 1) rect = n.getBoundingClientRect()
      else { rg.selectNodeContents(n); rect = rg.getBoundingClientRect() }
      if (rect.width === 0 && rect.height === 0) { total += len; continue }
      if (rect.left >= winStart) break
      best = total + len - 1
      total += len
    }
    if (best == null) return null
    const contents = r.getContents?.() ?? []
    const idx = contents.find(c => c.doc === doc)?.index ?? contents[0]?.index ?? 0
    return (bookCharPrefixes[idx] ?? 0) + best
  } catch { return null }
}
function saveBlankPageAsPreviousText(e) {
  const reason = e.detail?.reason
  const restoreNavActive = restoreNavGen !== 0 && restoreNavGen === restoreGeneration
  if (isResizing || restoreNavActive) return
  if (reason !== 'page' && reason !== 'navigation') return
  if (reason === 'page') clearSavedCharMark()
  const idx = getCharBeforeBlankPage(e.detail.range)
  if (idx == null) return
  lastStableCharIndex = idx
  if (furthestCharIndex == null || idx > furthestCharIndex) furthestCharIndex = idx
  if (FLAGS.SWITCH_SAVE_LOCATION_AS_CFI !== true && bookTotalChars) $('#pct-display').textContent = formatPct(idx / bookTotalChars)
  clearTimeout(saveTimer)
  saveTimer = setTimeout(savePositionNow, 400)
}
function getCurrentCharIndex() {
  try {
    const range = view?.lastLocation?.range
    if (!range || !view?.book) return null
    if (isNoNodeRange(range)) return null
    const doc = range.startContainer?.ownerDocument
    if (!doc) return null
    // find section index for this doc (2026-09-27-14-40-47: match the
    // range's own document; contents[0] is wrong when several views are
    // mounted at once — multi-section books, spread, reflow transitions)
    const contents = view.renderer?.getContents?.() ?? []
    let idx = contents.find(c => c.doc === doc)?.index ?? contents[0]?.index
    if (idx == null) {
      // fallback: find by comparing doc
      idx = 0
    }
    const prefix = bookCharPrefixes[idx] ?? 0
    const local = countCharsUpToRange(doc, range)
    return prefix + local
  } catch { return null }
}
async function getRangeForCharIndex(charIndex) {
  if (charIndex == null || !view?.book || !bookTotalChars) return null
  // find section
  let secIdx = 0
  for (let i = 0; i < bookCharPrefixes.length; i++) {
    const start = bookCharPrefixes[i]
    const end = i + 1 < bookCharPrefixes.length ? bookCharPrefixes[i + 1] : bookTotalChars
    if (charIndex >= start && charIndex < end) { secIdx = i; break }
    if (charIndex >= end) secIdx = i + 1
  }
  if (secIdx >= view.book.sections.length) secIdx = view.book.sections.length - 1
  const secOffset = charIndex - (bookCharPrefixes[secIdx] ?? 0)
  // return anchor that walks the *live* paginator doc (passed as arg), not the counted doc
  const makeAnchor = secOffsetVal => (liveDoc) => {
    // goto-target diag (2026-09-28-12-02-23): where the target char sits in
    // iframe coords vs the page the paginator will pick (floor(x/size)+1).
    const finish = r => {
      if (debugOn()) {
        try {
          const rc = r.getBoundingClientRect()
          const size = view?.renderer?.size
          debugBeacon('goto-target', { target: charIndex, sec: secIdx, left: Math.round(rc.left * 100) / 100, top: Math.round(rc.top), ratio: size ? Math.round(rc.left / size * 1000) / 1000 : '', calcPage: size ? Math.floor(rc.left / size) + 1 : '', ...debugGeom() })
        } catch {}
      }
      return r
    }
    const walker = liveDoc.createTreeWalker(liveDoc.body, CHAR_WALK_SHOW, { acceptNode: charAcceptNode })
    const nodes = []
    for (let n = walker.nextNode(); n; n = walker.nextNode()) nodes.push(n)
    let remaining = secOffsetVal
    for (let i = 0; i < nodes.length; i++) {
      const n = nodes[i]
      if (n.nodeType === 1) {
        // media element = 1 char: target it (selectNode gives a real rect)
        if (remaining <= 0) { const r = liveDoc.createRange(); r.selectNode(n); return finish(r) }
        remaining -= 1
        continue
      }
      const len = [...(n.nodeValue ?? '')].length
      // boundary-next-node (2026-09-29-09-39-04): a char index that equals the
      // end of this node is the FIRST char of the next node (the read-back
      // counts chars strictly before the page's first char). Only the very
      // last node keeps the end-of-node anchor. Before, a page starting at a
      // paragraph start restored to the end of the previous paragraph, i.e.
      // the previous page. A following media element is still targeted by
      // the media branch above (remaining 0).
      const isLastNode = i === nodes.length - 1
      if (remaining < len || (remaining === len && isLastNode)) {
        const str = n.nodeValue ?? ''
        let cuOffset = 0
        let cpCount = 0
        for (const ch of str) {
          if (cpCount >= remaining) break
          cuOffset += ch.length
          cpCount++
        }
        const range = liveDoc.createRange()
        range.setStart(n, Math.min(cuOffset, n.nodeValue.length))
        range.collapse(true)
        return finish(range)
      }
      remaining -= len
    }
    // fallback: start of body
    const range = liveDoc.createRange()
    range.selectNodeContents(liveDoc.body)
    range.collapse(true)
    return finish(range)
  }
  return { index: secIdx, anchor: makeAnchor(secOffset) }
}

/* ---------------- library ---------------- */

async function refreshLibrary() {
  const books = await idbGetAll('books')
  books.sort((a, b) => (b.openedAt || 0) - (a.openedAt || 0))
  const body = $('#library-body')
  body.innerHTML = ''
  if (!books.length) {
    body.innerHTML = '<p style="opacity:.7">No books yet. Import an EPUB to get started.</p>'
    return
  }
  for (const b of books) {
    const row = document.createElement('div')
    row.className = 'book-row'
    const img = document.createElement('img')
    if (b.coverDataUrl) img.src = b.coverDataUrl
    const meta = document.createElement('div')
    meta.className = 'meta'
    const opened = b.openedAt
      ? `Opened: ${new Date(b.openedAt).toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}`
      : '(Not yet opened)'
    meta.innerHTML = `<div class="title">${b.title}</div><div class="opened">${opened}</div>`
    row.append(img, meta)
    row.addEventListener('click', () => openBook(b.id))
    body.appendChild(row)
  }
}

async function importFiles(fileList) {
  let added = 0, skipped = 0, failed = 0
  let lastError = ''
  for (const file of Array.from(fileList)) {
    // Be lenient: mobile pickers (cloud providers, SAF) sometimes give odd
    // names/MIME types even though the OS-level ".epub" filter was used.
    const looksLikeEpub = /\.epub$/i.test(file.name)
      || file.type === 'application/epub+zip'
      || file.type === 'application/zip'
      || file.type === ''
    if (!looksLikeEpub) { skipped++; continue }
    try {
      const id = await fingerprint(file)
      const existing = await idbGet('books', id)
      if (existing) { skipped++; continue }
      const title = file.name.replace(/\.epub$/i, '') || 'Untitled'
      await idbPut('books', { id, file, title, openedAt: null, coverDataUrl: null })
      added++
    } catch (err) {
      console.error('Import failed for', file.name, err)
      lastError = err?.message || String(err)
      failed++
    }
  }
  await refreshLibrary()
  if (added === 0 && (skipped > 0 || failed > 0)) {
    const detail = failed > 0 ? ` Last error: ${lastError}` : ''
    alert(`Couldn't import: ${failed} failed, ${skipped} skipped (already in your library, or not recognized as EPUB).${detail}`)
  }
}

/* ---------------- reading ---------------- */

function getCSS() {
  const { bg, fg } = THEMES[settings.theme] || THEMES.cream
  return `
    @namespace epub "http://www.idpf.org/2007/ops";
    html, body {
      background: ${bg};
      color: ${fg};
      color-scheme: ${settings.theme === 'night' ? 'dark' : 'light'};
    }
    body {
      font-family: ${currentFontFamily()};
      font-size: ${settings.fontSize}px;
    }
    ::highlight(sm-saved-char) {
      background-color: rgba(33, 150, 243, .35);
      color: inherit;
    }
    p, li, blockquote, dd {
      line-height: ${settings.lineSpacing};
      text-align: justify;
      hyphens: auto;
    }
  `
}

function applyTheme() {
  const page = $('#book-page')
  page.classList.remove('theme-white', 'theme-cream', 'theme-night')
  page.classList.add('theme-' + settings.theme)
  applyStyles()
}

function applyStyles() {
  // unfreeze-on-change (2026-09-27-19-02-57): same as applyGeometry — font/
  // theme/spacing edits while frozen must take effect now, not at exit
  if (fullscreenFrozen) unfreezeFullscreenSize()
  if (view && lastStableCfi) captureAnchor()
  view?.renderer?.setStyles?.(getCSS())
  // chrome-font-pct (2026-09-27-16-55-53): header/position sizes as a
  // percentage of the content size. Position set inline on #pct-display
  // itself (beats the old 12px pin, which only inherited to the footer box).
  const topPct = Number(FLAGS.SWITCH_TOP_MENU_FONT_SIZE_IN_PERCENTAGE ?? 90)
  const botPct = Number(FLAGS.SWITCH_BOTTOM_POSITION_FONT_SIZE_IN_PERCENTAGE ?? 90)
  $('#page-header').style.fontSize = Math.round(settings.fontSize * topPct / 100) + 'px'
  $('#page-footer').style.fontSize = Math.round(settings.fontSize * botPct / 100) + 'px'
  $('#pct-display').style.fontSize = Math.round(settings.fontSize * botPct / 100) + 'px'
  // 2026-09-27-17-37-26: optional italic position line
  $('#pct-display').style.fontStyle = FLAGS.SWITCH_BOTTOM_POSITION_ITALIC === true ? 'italic' : ''
  if (view && lastStableCfi) scheduleRestore()
}

async function openBook(id) {
  const row = await idbGet('books', id)
  if (!row) return
  currentBookId = id
  furthestFraction = 0
  furthestCharIndex = null
  searchTextCache = []
  lastSearchLandedChar = null
  lastSearchQueryForStep = ''
  clearSearchMark()
  clearFirstRowFlash()
  clearSavedCharMark()
  showReader()
  hideCover()

  if (view) { view.close(); view.remove() }
  view = document.createElement('foliate-view')
  $('#viewer-host').appendChild(view)
  view.addEventListener('relocate', onRelocate)
  view.addEventListener('load', e => wireContentDoc(e.detail.doc))
  await view.open(row.file)

  view.renderer.setAttribute('flow', 'paginated')
  view.renderer.setAttribute('max-column-count', '1')
  view.renderer.setAttribute('gap', '0%')
  view.renderer.setAttribute('margin', '0px')
  applyStyles()
  applyTheme()

  const pos = await idbGet('positions', id)
  furthestFraction = pos?.furthestFraction || 0
  furthestCharIndex = pos?.furthestCharIndex ?? null
  const useCfiOpen = FLAGS.SWITCH_SAVE_LOCATION_AS_CFI === true
  // int-only with a stored integer: swallow init's own relocates so the
  // text-start position is never saved as stable (its 400ms saveTimer would
  // otherwise clobber the stored row after the restore below runs).
  const intOnlyOpen = !useCfiOpen && pos?.charIndex != null
  if (intOnlyOpen) { isResizing = true; clearTimeout(saveTimer) }
  // open-finally (2026-09-27-11-14-07, Terra review): the reset below is in a
  // finally so a rejecting init (or anything else in this span) can't strand
  // isResizing=true and silently stop all future position saving. True hangs
  // (never-settling awaits) need timeouts and stay out of scope.
  try {
  if (useCfiOpen && pos?.cfi) {
    await view.init({ lastLocation: pos.cfi })
  } else {
    await view.init({ showTextStart: true })
  }
  // compute char prefixes for precise top-left char restore (char-index only, no snippet search)
  try { await computeBookCharPrefixes() } catch {}
  lastStableCfi = view.lastLocation?.cfi || pos?.cfi || null
  lastStableFraction = view.lastLocation?.fraction ?? null
  if (lastStableFraction == null && pos?.fraction != null) lastStableFraction = pos.fraction
  try { lastStableSnippet = String(view.lastLocation?.range).slice(0, 30) } catch { lastStableSnippet = null }
  try { lastStableCharIndex = getCurrentCharIndex() } catch { lastStableCharIndex = null }
  // int-only: the stored integer wins over the live text-start read
  // unconditionally (live is text start here, not a real position).
  if (!useCfiOpen && pos?.charIndex != null && bookTotalChars) lastStableCharIndex = Math.min(Math.max(0, pos.charIndex | 0), Math.max(0, bookTotalChars - 1))
  else if (lastStableCharIndex == null && pos?.fraction != null && bookTotalChars) lastStableCharIndex = Math.round(pos.fraction * bookTotalChars)
  if (furthestCharIndex == null && pos?.fraction != null && bookTotalChars) furthestCharIndex = Math.round(Math.min(1, Math.max(0, pos.fraction)) * bookTotalChars)
  if (furthestCharIndex == null && lastStableCharIndex != null) furthestCharIndex = lastStableCharIndex
  // int-only open (flag false): jump to the stored integer after prefixes exist.
  // isResizing guards the goTo's own relocate so it isn't saved as drift;
  // the char anchor stays the stored value (never re-derived here, the live
  // read may still reflect the pre-jump position).
  if (FLAGS.SWITCH_SAVE_LOCATION_AS_CFI !== true && pos?.charIndex != null && bookTotalChars) {
    try {
      isResizing = true
      const target = await getRangeForCharIndex(lastStableCharIndex)
      if (target) await view.renderer.goTo(target).catch(() => {})
      lastStableCfi = view.lastLocation?.cfi || lastStableCfi
      lastStableFraction = view.lastLocation?.fraction ?? lastStableFraction
      try { lastStableSnippet = String(view.lastLocation?.range).slice(0, 30) } catch {}
    } catch {}
  }
  } finally { isResizing = false }
  // ensure percentage display reflects the restored location (was frozen during resize)
  if (FLAGS.SWITCH_SAVE_LOCATION_AS_CFI !== true && lastStableCharIndex != null && bookTotalChars) $('#pct-display').textContent = formatPct(lastStableCharIndex / bookTotalChars)
  else if (lastStableFraction != null) $('#pct-display').textContent = formatPct(lastStableFraction)
  // initial doc was already loaded before listener existed in old version – wire it explicitly
  try {
    for (const { doc } of view.renderer.getContents()) if (doc) wireContentDoc(doc)
  } catch {}

  const title = row.title
  $('#page-header .title').textContent = title
  document.title = title

  row.openedAt = Date.now()
  if (!row.coverDataUrl) {
    try {
      const blob = await view.book.getCover?.()
      if (blob) row.coverDataUrl = await blobToDataUrl(blob)
    } catch {}
  }
  await idbPut('books', row)

  buildGotoMenu()
  rememberWindowedSizesIfAtRest()
}

function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const r = new FileReader()
    r.onload = () => resolve(r.result)
    r.onerror = reject
    r.readAsDataURL(blob)
  })
}

function onRelocate(e) {
  const { fraction, cfi, reason } = e.detail
  // spacer-read-fix (2026-09-28-11-27-11): a relocate read while sitting on a
  // blank spacer page (container page 0 / last) is not a real position (it
  // resolved to the section prefix, e.g. 0.815 after 7.85). Ignore it; the
  // paginator's follow-up section jump / real page fires the real relocate.
  const onSpacer = isOnSpacerPage()
  if (debugOn()) {
    let ci = ''
    try { ci = getCurrentCharIndex() ?? '' } catch {}
    debugBeacon('relocate', { reason, frac: fraction, cfi, charIdx: ci, spacer: onSpacer, resizing: isResizing, ...debugGeom() })
  }
  if (onSpacer) return
  // blank-page-read (2026-09-28-20-12-00): a page with no readable node reads as
  // a collapsed range at body start (= the section start); not a position.
  // blank-page-save (2026-09-29-09-39-04): instead of ignoring it, save the
  // last char of the text before it (see getCharBeforeBlankPage()).
  if (isNoNodeRange(e.detail.range)) { saveBlankPageAsPreviousText(e); return }
  // restore-nav-guard: the running restore's own landing is not a user move.
  const restoreNavActive = restoreNavGen !== 0 && restoreNavGen === restoreGeneration
  // saved-char-mark: the mark lasts until the next page turn or real jump
  if (reason === 'page' || (reason === 'navigation' && !isResizing && !restoreNavActive)) clearSavedCharMark()
  // freeze percentage display while resizing to avoid showing intermediate drift (2.09→2.05→1.9)
  // pct-unified (2026-09-27-11-02-29): in int mode every footer source uses
  // the char anchor, so page-turns and restores can't disagree on one page.
  if (!isResizing && !restoreNavActive) {
    // live char first (lastStable* below still holds the previous page here)
    let showChar = null
    try { showChar = getCurrentCharIndex() } catch { showChar = null }
    if (showChar == null) showChar = lastStableCharIndex
    if (FLAGS.SWITCH_SAVE_LOCATION_AS_CFI !== true && bookTotalChars && showChar != null) $('#pct-display').textContent = formatPct(showChar / bookTotalChars)
    else $('#pct-display').textContent = formatPct(fraction)
  }
  if (fraction > furthestFraction) furthestFraction = fraction
  // while a resize is in progress, relocate events reflect the paginator's
  // own drift as it re-flows content at the new size — not a real reading
  // position — so don't treat them as "stable", and don't save them.
  if (isResizing || restoreNavActive) return
  // only an intentional position change is savable: an actual page turn
  // ('page', from #scrollPrev/#scrollNext) or a real jump ('navigation':
  // TOC, "Go to position", "Most recent page", "Furthest read", or the
  // restore mechanism's own goTo/goToFraction calls — those are only
  // reached while isResizing is still true, so they're already excluded
  // above). Every other reason (anchor/snap/scroll/selection) is the
  // paginator's own continuous re-pinning drift, never a new position.
  if (reason !== 'page' && reason !== 'navigation') return
  lastStableCfi = cfi
  lastStableFraction = fraction
  try { lastStableSnippet = String(e.detail.range).slice(0, 30) } catch { lastStableSnippet = null }
  try { lastStableCharIndex = getCurrentCharIndex() } catch { lastStableCharIndex = null }
  if (lastStableCharIndex != null && (furthestCharIndex == null || lastStableCharIndex > furthestCharIndex)) furthestCharIndex = lastStableCharIndex
  clearTimeout(saveTimer)
  saveTimer = setTimeout(savePositionNow, 400)
}

/* ---------------- page-turn click zones (inside rendered content) ---------------- */

function wireContentDoc(doc) {
  if (!doc || doc.__smReaderWired) return
  doc.__smReaderWired = true
  let downX = 0, downY = 0
  // 2026-09-27-17-56-08 (deselect-first): the browser natively collapses the
  // selection on tap-down, so tap-up sees an empty selection and would turn
  // the page. Remember tap-down state instead — a pre-existing selection
  // consumes the whole tap (remnant cleared), never a page turn.
  let downHadSelection = false

  doc.addEventListener('pointerdown', e => {
    downX = e.clientX; downY = e.clientY
    try { downHadSelection = !!(doc.getSelection && String(doc.getSelection()).length) } catch { downHadSelection = false }
  })
  doc.addEventListener('pointercancel', () => { downHadSelection = false })

  doc.addEventListener('pointerup', e => {
    if (downHadSelection) {
      downHadSelection = false
      try { doc.getSelection?.()?.removeAllRanges?.() } catch {}
      return
    }
    const dx = Math.abs(e.clientX - downX), dy = Math.abs(e.clientY - downY)
    if (dx > 6 || dy > 6) return // was a drag (selection), not a tap
    // unified-chrome (2026-09-27-16-35-36): selected text is cleared first
    // and the tap consumed — never a page turn on top of a selection
    const sel = doc.getSelection?.()
    if (sel && String(sel).length) { sel.removeAllRanges(); return }
    if (e.target.closest && e.target.closest('a')) return // let links work
    if (dismissChrome()) return // first tap just closes the open menu/dropdown
    // tap-coords-fix (2026-09-27-18-51-02): the book iframe is laid out at
    // full-book width, so iframe coords are book coords, not page coords.
    // Decide in visible coords: subtract the paginator's scroll offset and
    // compare against its visible size (both public). Fallback keeps the
    // old behavior when the renderer isn't ready.
    // tap-outer-coords (2026-09-28-09-29-09): the iframe sits one spacer page
    // inside the paginator container, so the old clientX - start always fell
    // in [-size, 0) (every tap = previous). Use outer coords like the
    // #viewer-host margin handler; old formula stays as the fallback.
    const frameEl = doc.defaultView.frameElement
    const hostEl = $('#viewer-host')
    if (frameEl && hostEl) {
      const hr = hostEl.getBoundingClientRect()
      turnAt(frameEl.getBoundingClientRect().left + e.clientX - hr.left, hr.width, 'iframe-tap rawX=' + Math.round(e.clientX))
      return
    }
    const renderer = view?.renderer
    const w = renderer?.size ?? doc.defaultView.innerWidth
    const vx = e.clientX - (renderer?.start ?? 0)
    turnAt(vx, w, 'iframe-tap-fallback')
  })

  let wheelLock = false
  doc.addEventListener('wheel', e => {
    if (wheelLock) return
    wheelLock = true
    setTimeout(() => { wheelLock = false }, 350)
    if (e.deltaY > 0) view?.goRight?.() ?? view?.renderer?.next()
    else if (e.deltaY < 0) view?.goLeft?.() ?? view?.renderer?.prev()
  }, { passive: true })

  // the book content renders in its own <iframe> document, so key
  // presses while it has focus never reach our outer document listener
  doc.addEventListener('keydown', handleKey)
}

function turnAt(clientX, width, src = '') {
  if (debugOn()) debugBeacon('turn', { src, x: Math.round(clientX), width: Math.round(width), dir: clientX < width / 2 ? 'prev' : 'next', ...debugGeom() })
  if (clientX < width / 2) view?.goLeft?.() ?? view?.renderer?.prev()
  else view?.goRight?.() ?? view?.renderer?.next()
}

function handleKey(e) {
  const typing = ['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName)
  // search-book-panel (2026-09-27-12-08-27): Ctrl/Cmd shortcuts first, so
  // Ctrl+F never reaches the plain-f fullscreen branch below. preventDefault
  // asks the browser not to open its own find UI (browsers may still win).
  const mod = e.ctrlKey || e.metaKey
  if (mod && (e.key === 'g' || e.key === 'G')) { e.preventDefault(); if (view) promptGoto(); return }
  if (mod && (e.key === 'f' || e.key === 'F')) { e.preventDefault(); if (view) { showReaderView(); showSearchPanel() } return }
  if (!typing && (e.key === 'f' || e.key === 'F')) { toggleFullscreen(); return }
  if (e.key === 'Escape' && !$('#search-panel')?.classList.contains('hidden')) { hideSearchPanel(); return }
  if (e.key === 'Escape' && document.fullscreenElement) { document.exitFullscreen(); return }
  // unified-chrome (2026-09-27-16-35-36): F9 toggles the book menu, F10 the
  // position line. Work with no book open; never while typing.
  if (!typing && e.key === 'F9') { e.preventDefault(); toggleBookMenu(); return }
  if (!typing && e.key === 'F10') { e.preventDefault(); togglePosition(); return }
  if (!view || typing) return
  if (e.key === 'ArrowLeft' || e.key === 'ArrowUp' || e.key === 'PageUp') { e.preventDefault(); view.goLeft?.() ?? view.renderer?.prev() }
  if (e.key === 'ArrowRight' || e.key === 'ArrowDown' || e.key === 'PageDown') { e.preventDefault(); view.goRight?.() ?? view.renderer?.next() }
}

/* ---------------- go to menu ---------------- */

function buildGotoMenu() {
  const menu = $('#goto-menu')
  menu.innerHTML = ''
  const addItem = (label, fn, disabled) => {
    const b = document.createElement('button')
    b.textContent = label
    if (disabled) b.disabled = true
    b.addEventListener('click', () => { menu.classList.remove('show'); if (!disabled) fn() })
    menu.appendChild(b)
  }
  const addSep = () => { const d = document.createElement('div'); d.className = 'separator'; menu.appendChild(d) }

  addItem('Book start', async () => { await view.goToTextStart(); showReaderView() })
  addItem('Furthest read', async () => {
    if (FLAGS.SWITCH_SAVE_LOCATION_AS_CFI !== true && furthestCharIndex != null && bookTotalChars) {
      try {
        const target = await getRangeForCharIndex(Math.min(Math.max(0, furthestCharIndex | 0), Math.max(0, bookTotalChars - 1)))
        if (target) { await view.renderer.goTo(target).catch(() => {}); showReaderView(); return }
      } catch {}
    }
    await view.goToFraction(furthestFraction); showReaderView()
  })
  addItem('Table of Contents', () => showTOC())
  addSep()
  addItem('Go to position…', () => { promptGoto(); showReaderView() })
  addItem('Search book', () => { showReaderView(); showSearchPanel() })
  addSep()
  addItem(document.fullscreenElement ? 'Exit full screen (F11)' : 'Full screen (F11)', () => toggleFullscreen())
  addItem(`${settings.showBookMenu !== false ? '✓ ' : ''}Top menu (F9)`, () => { toggleBookMenu(); })
  addItem(`${settings.showPosition !== false ? '✓ ' : ''}Bottom position (F10)`, () => { togglePosition(); })
  addSep()
  addItem('Library', () => showLibrary())
  addItem('Settings', () => showSettings())
}

function showTOC() {
  const toc = view?.book?.toc
  if (!toc) return
  const body = $('#library-body')
  $('#settings-view').classList.remove('show')
  setComponentTitle($('#library-header-title'), 'Contents')
  // Contents reuses the library view: hide the import row, Back returns
  const importRow = $('#import-row')
  if (importRow) importRow.style.display = 'none'
  body.innerHTML = ''
  const walk = (items, depth) => {
    for (const item of items) {
      const row = document.createElement('div')
      row.className = 'book-row'
      row.style.paddingLeft = (depth * 20) + 'px'
      row.innerHTML = `<div class="meta"><div class="title">${item.label}</div></div>`
      row.addEventListener('click', async () => { await view.goTo(item.href); showReaderView() })
      body.appendChild(row)
      if (item.subitems) walk(item.subitems, depth + 1)
    }
  }
  walk(toc, 0)
  $('#library-view').classList.add('show')
  applyBackButtons()
  hideCover()
}

function promptGoto() {
  const val = prompt('Go to position (percentage, e.g. 42.73, or character index, e.g. 110003):')
  if (val == null) return
  const trimmed = val.trim()
  if (!trimmed) return
  // goto-pct-char-unified (2026-09-27-11-49-15): a trailing % always means
  // percentage (checked BEFORE stripping, so "70%" can't fall into the
  // integer-char branch); otherwise a plain integer 0-100 is a percentage
  // and only integers >100 are char indexes. Percentage jumps in int mode
  // go via charIdx so footer display and goto share one denominator
  // (charIndex/bookTotalChars), never SectionProgress sizes.
  const hadPercent = /%\s*$/.test(trimmed)
  const raw = trimmed.replace(/%$/, '').trim()
  if (!raw) return
  const gotoFractionViaChar = frac => {
    const f = Math.min(1, Math.max(0, frac))
    if (FLAGS.SWITCH_SAVE_LOCATION_AS_CFI !== true && bookTotalChars) {
      const charIdx = Math.min(Math.max(0, Math.round(f * bookTotalChars)), Math.max(0, bookTotalChars - 1))
      getRangeForCharIndex(charIdx).then(target => {
        if (target) view.renderer.goTo(target).catch(() => {})
        else view.goToFraction(f).catch(() => {})
      }).catch(() => {})
    } else {
      view.goToFraction(f).catch(() => {})
    }
  }
  // whole digits (no . or ,): percentage when hadPercent or 0-100, else char index
  // (both . and , accepted as the decimal separator below, any precision kept)
  if (/^[+-]?\d+$/.test(raw)) {
    const idx = parseInt(raw, 10)
    if (isNaN(idx)) return
    if (hadPercent || (idx >= 0 && idx <= 100)) {
      gotoFractionViaChar(idx / 100)
      return
    }
    if (!bookTotalChars) return
    const clamped = Math.min(Math.max(0, idx), Math.max(0, bookTotalChars - 1))
    getRangeForCharIndex(clamped).then(target => {
      if (target) view.renderer.goTo(target).catch(() => {})
      else view.goToFraction(clamped / bookTotalChars).catch(() => {})
    }).catch(() => {})
    return
  }
  const num = parseFloat(raw.replace(',', '.'))
  if (!isNaN(num)) gotoFractionViaChar(num / 100)
}

/* ---------------- search book (2026-09-27-12-08-27) ---------------- */
// Whole book, all sections, from the current position in the given direction.
// Per-section visible text is built with the same filter as the char counters
// and cached till the next openBook. Code-unit/code-point conversion keeps
// indexOf (UTF-16) consistent with the char-index anchor walker (code points).
function showSearchPanel() {
  const panel = $('#search-panel')
  if (!panel) return
  panel.classList.remove('hidden')
  const input = $('#search-input')
  input.value = lastSearchQuery
  input.classList.remove('not-found')
  input.focus()
  input.select()
}
function hideSearchPanel() {
  $('#search-panel')?.classList.add('hidden')
  clearSearchMark()
}
// unwraps the transient mark without touching text (split text nodes are
// re-merged); background-only styling means wrap/unwrap never reflows layout
function clearSearchMark() {
  try {
    const m = searchMark
    searchMark = null
    const span = m?.span
    const parent = span?.parentNode
    if (!span || !parent) return
    while (span.firstChild) parent.insertBefore(span.firstChild, span)
    parent.removeChild(span)
    parent.normalize?.()
  } catch {}
}
// highlights the landed match inside one text node (where prose matches almost
// always sit); a cross-node match still marks to the node end at the exact
// landing spot rather than nothing
function markSearchMatch(target, query, charIdx) {
  clearSearchMark()
  // search-stable-goto (2026-09-27-13-39-03): the mark path was blind
  // (collapsed/bad-node/throw all silent) — report the outcome per jump.
  const report = extra => debugBeacon('search-mark', { charIdx, query: String(query).slice(0, 30), ...extra })
  try {
    const contents = view.renderer.getContents() ?? []
    const live = (contents.find(c => c.index === target.index) ?? contents[0])?.doc
    if (!live) { report({ outcome: 'no-live-doc' }); return }
    const range = target.anchor(live)
    const node = range?.startContainer
    if (!node || node.nodeType !== 3 || !node.nodeValue) { report({ outcome: 'bad-node', nodeType: node?.nodeType ?? null }); return }
    let qLenCu = 0
    for (const ch of query) qLenCu += ch.length
    const start = Math.min(range.startOffset, node.nodeValue.length)
    const end = Math.min(node.nodeValue.length, range.startOffset + qLenCu)
    if (end <= start) { report({ outcome: 'collapsed', nodeLen: node.nodeValue.length, startOffset: range.startOffset }); return }
    const r = live.createRange()
    r.setStart(node, start)
    r.setEnd(node, end)
    const span = live.createElement('span')
    span.setAttribute('data-sm-search-mark', '1')
    span.style.background = 'rgba(255, 235, 59, .65)'
    span.style.color = 'inherit'
    r.surroundContents(span)
    searchMark = { span }
    report({ outcome: 'marked', nodeLen: node.nodeValue.length })
  } catch (e) { report({ outcome: 'threw', reason: String(e?.message ?? e).slice(0, 80) }) }
}
// flash-first-row (2026-09-27-15-41-42): transient blue tint on the landed
// top row after a restore, so resize/fullscreen landings are eye-checkable.
// Separate var/timer from the yellow search mark (never clobbered; skipped
// while one is active). Background-only styling, no reflow. Single text
// node only (where prose top rows sit); cross-node rows simply don't flash.
let firstRowFlash = null
let firstRowFlashTimer = null
function clearFirstRowFlash() {
  try {
    clearTimeout(firstRowFlashTimer)
    firstRowFlashTimer = null
    const m = firstRowFlash
    firstRowFlash = null
    const span = m?.span
    const parent = span?.parentNode
    if (!span || !parent) return
    while (span.firstChild) parent.insertBefore(span.firstChild, span)
    parent.removeChild(span)
    parent.normalize?.()
  } catch {}
}
function flashFirstRowOnRestore() {
  clearFirstRowFlash()
  if (FLAGS.SWITCH_MARK_TEMPORARILY_FIRST_ROW_ON_PAGE_RESIZE !== true) return
  const ms = Number(FLAGS.SWITCH_MARK_TEMPORARILY_FIRST_ROW_ON_PAGE_RESIZE_MS ?? 3000)
  if (!(ms > 0)) return
  if (searchMark) return
  try {
    const landed = view?.lastLocation?.range
    if (!landed) return
    const doc = landed.startContainer?.ownerDocument
    if (!doc?.createRange) return
    const node = landed.startContainer
    if (!node || node.nodeType !== 3 || !node.nodeValue) return
    const len = node.nodeValue.length
    const offset = Math.min(Math.max(0, landed.startOffset ?? 0), len)
    if (offset >= len) return
    const r = doc.createRange()
    r.setStart(node, offset)
    r.collapse(true)
    let lineH = 0
    let end = offset
    while (end < len && end - offset < 200) {
      end++
      r.setEnd(node, end)
      let h = 0
      try { h = r.getBoundingClientRect().height } catch { break }
      if (h > 0 && !lineH) lineH = h
      if (lineH && h > lineH * 1.3) { end--; break }
    }
    if (end <= offset) return
    r.setEnd(node, end)
    const span = doc.createElement('span')
    span.setAttribute('data-sm-first-row-flash', '1')
    span.style.background = 'rgba(33, 150, 243, .35)'
    span.style.color = 'inherit'
    r.surroundContents(span)
    firstRowFlash = { span }
    firstRowFlashTimer = setTimeout(clearFirstRowFlash, Math.min(30000, ms))
  } catch {}
}
// saved-char-mark (2026-09-29-08-27-26): tints the saved char (through the end
// of its word, at most 12 code units) after a restore, until the next page
// turn or jump. CSS Custom Highlight API: registry entry on the book iframe's
// window, no DOM change, so no reflow and no split text nodes. The rule
// `::highlight(sm-saved-char)` lives in getCSS().
const SAVED_MARK_NAME = 'sm-saved-char'
let savedCharMark = null // { win }
function clearSavedCharMark() {
  try {
    const m = savedCharMark
    savedCharMark = null
    m?.win?.CSS?.highlights?.delete(SAVED_MARK_NAME)
  } catch {}
}
// mark-at-node-end (2026-09-29-09-18-31): first non-blank text node after
// `node` in document order (skips script/style), or null.
function nextNonBlankTextNode(doc, node) {
  const walker = doc.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT)
  walker.currentNode = node
  for (let n = walker.nextNode(); n; n = walker.nextNode()) {
    const pn = n.parentElement?.localName?.toLowerCase()
    if (pn === 'script' || pn === 'style') continue
    if (n.nodeValue?.trim()) return n
  }
  return null
}
async function markSavedCharAfterRestore(charIdx, gen) {
  clearSavedCharMark()
  if (FLAGS.SWITCH_MARK_SAVED_CHAR_UNTIL_NEXT_PAGE_TURN !== true) return
  if (charIdx == null || !view) return
  const report = extra => debugBeacon('saved-mark', { charIdx, ...extra })
  try {
    const target = await getRangeForCharIndex(charIdx)
    if (!target || gen !== restoreGeneration) return
    const contents = view.renderer.getContents() ?? []
    const live = (contents.find(c => c.index === target.index) ?? contents[0])?.doc
    const win = live?.defaultView
    if (!win?.CSS?.highlights || typeof win.Highlight !== 'function') { report({ outcome: 'no-highlight-api' }); return }
    const r = target.anchor(live)
    const node = r?.startContainer
    if (!node) { report({ outcome: 'no-range' }); return }
    let via = 'node'
    if (node.nodeType === 3) {
      let tNode = node
      let str = node.nodeValue ?? ''
      let from = Math.min(r.startOffset, str.length)
      // mark-skip-blank (2026-09-29-09-39-04): start on the first non-blank
      // char (\s also covers nbsp), so a leading nbsp/space is not the mark
      if (from < str.length && /\s/.test(str[from])) {
        while (from < str.length && /\s/.test(str[from])) from++
        if (from < str.length) r.setStart(node, from)
      }
      if (from >= str.length) {
        // saved char sits at the very end of its text node (restore target at
        // a node end): mark the first word of the next non-blank text node
        const nxt = nextNonBlankTextNode(live, node)
        if (!nxt) { report({ outcome: 'empty', via: 'no-next-node' }); return }
        tNode = nxt
        str = nxt.nodeValue ?? ''
        from = Math.max(0, str.search(/\S/))
        r.setStart(tNode, from)
        via = 'next-node'
      }
      let end = from
      const max = Math.min(str.length, from + 12)
      while (end < max && !/\s/.test(str[end])) end++
      if (end === from) end = Math.min(str.length, from + 1)
      if (end <= from) { report({ outcome: 'empty', via }); return }
      r.setEnd(tNode, end)
    } else if (r.collapsed) { report({ outcome: 'collapsed-element' }); return }
    win.CSS.highlights.set(SAVED_MARK_NAME, new win.Highlight(r))
    savedCharMark = { win }
    report({ outcome: 'marked', via })
  } catch (e) { report({ outcome: 'threw', reason: String(e?.message ?? e).slice(0, 80) }) }
}
// search-stable-goto (2026-09-27-13-39-03): search jumps go through the same
// settle path as restores. Fresh-open layout (fonts/images reflowing) used to
// shift columns between rect measurement and scroll, stranding viewport and
// mark; and an in-flight scheduleRestore could fire after the search goTo and
// yank the viewport back. Bumping restoreGeneration retires pending restores;
// the size poll waits out reflow. isResizing is cleared so the search landing
// (reason 'navigation') saves as a real position instead of being filtered.
async function stableSearchGoTo(target, query, charIdx) {
  const myGeneration = ++restoreGeneration
  clearTimeout(resizeSettleTimer)
  clearTimeout(isResizingOffTimer)
  const qLower = query.toLowerCase()
  // search-confirm-retry (2026-09-27-13-54-33): fresh-load font/column reflow
  // can strand the first goTo a page off the match (rects measured pre-swap).
  // Go, re-settle, confirm the landed window actually contains the query,
  // retry once with final rects, and only then mark. At most two loadings; a
  // superseded jump (newer generation) owns nothing and bails out.
  let current = target
  let attempts = 0
  let confirmed = false
  while (attempts < 2) {
    attempts++
    await waitForPaginatorSizeStable(myGeneration)
    if (myGeneration !== restoreGeneration) return false
    isResizing = false
    try {
      await view.renderer.goTo(current).catch(() => {})
    } catch {}
    await waitForPaginatorSizeStable(myGeneration)
    if (myGeneration !== restoreGeneration) return false
    let visible = ''
    try { visible = String(view.lastLocation?.range ?? '') } catch {}
    if (visible.toLowerCase().includes(qLower)) { confirmed = true; break }
    // re-resolve in the now-settled doc and try once more
    try {
      const fresh = await getRangeForCharIndex(charIdx)
      if (fresh) current = fresh
      else break
    } catch { break }
  }
  markSearchMatch(current, query, charIdx)
  debugBeacon('search-confirm', { charIdx, query: String(query).slice(0, 30), confirmed, attempts })
  return true
}
async function getSectionSearchText(i) {
  if (searchTextCache[i]) return searchTextCache[i]
  try {
    const doc = await view.book.sections[i].createDocument()
    if (!doc?.body) return null
    // image-chars: one placeholder (U+FFFC, 1 code unit) per media element keeps
    // hit offsets aligned with the global char numbers
    const walker = doc.createTreeWalker(doc.body, CHAR_WALK_SHOW, { acceptNode: charAcceptNode })
    let text = ''
    for (let n = walker.nextNode(); n; n = walker.nextNode()) text += (n.nodeType === 1 ? '\uFFFC' : (n.nodeValue ?? ''))
    const entry = { text, lower: text.toLowerCase() }
    searchTextCache[i] = entry
    return entry
  } catch { return null }
}
const cuToCp = (s, cuIdx) => [...s.slice(0, Math.max(0, cuIdx))].length
const cpToCu = (s, cpIdx) => {
  let cu = 0
  let counted = 0
  for (const ch of s) {
    if (counted >= cpIdx) break
    cu += ch.length
    counted++
  }
  return cu
}
function secOfChar(charIdx) {
  let sec = 0
  for (let i = 0; i < bookCharPrefixes.length; i++) {
    const start = bookCharPrefixes[i]
    const end = i + 1 < bookCharPrefixes.length ? bookCharPrefixes[i + 1] : bookTotalChars
    if (charIdx >= start && charIdx < end) { sec = i; break }
    if (charIdx >= end) sec = i + 1
  }
  return Math.min(sec, (view?.book?.sections.length ?? 1) - 1)
}
async function doSearchBook(dir) {
  const input = $('#search-input')
  const status = $('#search-status')
  const query = input?.value ?? ''
  if (!view?.book || !query || !bookTotalChars) return
  lastSearchQuery = query
  clearSearchMark() // a new attempt retires the previous transient mark
  const qLower = query.toLowerCase()
  const qLenCp = [...query].length
  let cur = null
  try { cur = getCurrentCharIndex() } catch { cur = null }
  if (cur == null) cur = lastStableCharIndex ?? 0
  // repeated stepping with the same query continues past the landed match
  // instead of re-finding it (the footer reads the page start, which sits
  // before a mid-page match, so cur alone would loop on one result)
  let base
  if (lastSearchLandedChar != null && lastSearchQueryForStep === query) {
    base = dir > 0 ? lastSearchLandedChar + qLenCp : lastSearchLandedChar - 1
  } else {
    base = dir > 0 ? cur + 1 : cur - 1
  }
  const wrap = $('#search-wrap')?.checked === true
  const n = view.book.sections.length
  const startSec = secOfChar(Math.min(Math.max(0, base), Math.max(0, bookTotalChars - 1)))
  const order = []
  if (dir > 0) { for (let i = startSec; i < n; i++) order.push(i); if (wrap) for (let i = 0; i < startSec; i++) order.push(i) }
  else { for (let i = startSec; i >= 0; i--) order.push(i); if (wrap) for (let i = n - 1; i > startSec; i--) order.push(i) }
  let first = true
  for (const i of order) {
    const entry = await getSectionSearchText(i)
    if (!entry) { first = false; continue }
    const prefix = bookCharPrefixes[i] ?? 0
    let idx = -1
    if (first) {
      const localCp = Math.min(Math.max(0, base - prefix), cuToCp(entry.text, entry.text.length))
      const localCu = cpToCu(entry.text, localCp)
      if (dir > 0) idx = entry.lower.indexOf(qLower, localCu)
      else {
        // matches starting at/after base don't count — step back past them
        idx = entry.lower.lastIndexOf(qLower, localCu)
        if (idx >= localCu) idx = entry.lower.lastIndexOf(qLower, localCu - 1)
      }
      first = false
    } else {
      idx = dir > 0 ? entry.lower.indexOf(qLower) : entry.lower.lastIndexOf(qLower)
    }
    if (idx >= 0) {
      const globalCp = prefix + cuToCp(entry.text, idx)
      const clamped = Math.min(Math.max(0, globalCp), Math.max(0, bookTotalChars - 1))
      try {
        const target = await getRangeForCharIndex(clamped)
        // search-stable-goto: waits out reflow and retires pending restores;
        // records only when still current (a superseded jump owns nothing)
        if (target && await stableSearchGoTo(target, query, clamped)) {
          lastSearchLandedChar = clamped
          lastSearchQueryForStep = query
          input.classList.remove('not-found')
          if (status) status.textContent = bookTotalChars ? formatPct(clamped / bookTotalChars) : ''
        }
        return
      } catch {}
    }
  }
  // the wrapped-around remainder of the start section is not in the order
  // list above (the start section is never revisited), so check its far
  // side explicitly here when wrap is on
  if (wrap) {
    const entry = await getSectionSearchText(startSec)
    if (entry) {
      const prefix = bookCharPrefixes[startSec] ?? 0
      const localCp = Math.min(Math.max(0, base - prefix), cuToCp(entry.text, entry.text.length))
      const localCu = cpToCu(entry.text, localCp)
      let idx = -1
      if (dir > 0) {
        // far side of the start section: matches strictly before base
        // (at/after base was already covered in the first pass above)
        const firstAtZero = entry.lower.indexOf(qLower)
        if (firstAtZero >= 0 && firstAtZero < localCu) idx = firstAtZero
      } else {
        // far side: last match overall counts only if it starts after base
        // (at/before base was already covered in the first pass above)
        idx = entry.lower.lastIndexOf(qLower)
        if (idx < localCu) idx = -1
      }
      if (idx >= 0) {
        const globalCp = prefix + cuToCp(entry.text, idx)
        const clamped = Math.min(Math.max(0, globalCp), Math.max(0, bookTotalChars - 1))
        try {
          const target = await getRangeForCharIndex(clamped)
          if (target && await stableSearchGoTo(target, query, clamped)) {
            lastSearchLandedChar = clamped
            lastSearchQueryForStep = query
            input.classList.remove('not-found')
            if (status) status.textContent = bookTotalChars ? formatPct(clamped / bookTotalChars) : ''
          }
          return
        } catch {}
      }
    }
  }
  input.classList.add('not-found')
  if (status) status.textContent = 'Not found'
}

function showCover() {
  showReaderView()
  Promise.resolve(view?.book?.getCover?.()).then(blob => {
    if (!blob) { alert("No cover image found in this book."); return }
    $('#cover-img').src = URL.createObjectURL(blob)
    $('#cover-overlay').classList.add('show')
  })
}
function hideCover() { $('#cover-overlay').classList.remove('show') }

/* ---------------- view switching ---------------- */

function showReader() {
  $('#library-view').classList.remove('show')
  $('#settings-view').classList.remove('show')
  setComponentTitle($('#library-header-title'), 'Library')
}
function showReaderView() { showReader(); hideCover() }
// Back-button + title visibility for Library/Settings/Contents
// (2026-09-27-16-35-36, unified-chrome). Back always returns to the last
// reading position (same as Return did). Location switch read live.
function setComponentTitle(el, text) {
  if (!el) return
  el.textContent = FLAGS.SWITCH_SHOW_COMPONENTS_TITLE_IN_APP === true ? text : ''
}
function applyBackButtons() {
  const loc = FLAGS.SWITCH_BACK_BUTTON_LOCATION_IN_APP ?? 'top'
  const showTop = loc === 'top'
  const showBottom = loc === 'bottom'
  for (const id of ['#library-back-top', '#settings-back-top']) {
    const el = $(id)
    if (el) el.style.display = showTop ? '' : 'none'
  }
  for (const id of ['#library-back-bottom', '#settings-back-bottom']) {
    const el = $(id)
    if (el) el.style.display = showBottom ? '' : 'none'
  }
}
function showLibrary() {
  $('#settings-view').classList.remove('show')
  setComponentTitle($('#library-header-title'), 'Library')
  $('#import-row')?.style.removeProperty('display')
  refreshLibrary()
  $('#library-view').classList.add('show')
  applyBackButtons()
  hideCover()
}
function showSettings() {
  $('#library-view').classList.remove('show')
  setComponentTitle($('#settings-header-title'), 'Settings')
  renderSettings()
  $('#settings-view').classList.add('show')
  applyBackButtons()
  hideCover()
}

/* ---------------- sidebar / fullscreen / chrome visibility ---------------- */

function collapseSidebar() {
  if (view && lastStableCfi) captureAnchor()
  $('#sidebar').classList.add('collapsed')
  updateChromeVisibility()
  if (view && lastStableCfi) scheduleRestore()
}
function expandSidebar() {
  if (view && lastStableCfi) captureAnchor()
  $('#sidebar').classList.remove('collapsed')
  updateChromeVisibility()
  if (view && lastStableCfi) scheduleRestore()
}
function toggleSidebar() {
  if ($('#sidebar').classList.contains('collapsed')) expandSidebar()
  else collapseSidebar()
}

// Dismiss whatever chrome is showing, in priority order. Returns true if it
// dismissed something — the caller should treat that as the whole click and
// not also navigate, so the *next* click is the one that turns the page.
function dismissChrome() {
  const menu = $('#goto-menu')
  if (menu.classList.contains('show')) { menu.classList.remove('show'); return true }
  // first-click-fix (2026-09-29-08-27-26): the sidebar has no `collapsed` class at
  // start, but with SHOW_LEFT_RED_MENUBAR=false it is display:none (inline).
  // Treating that hidden bar as "open chrome" swallowed the first tap after
  // opening a book (and ran a needless captureAnchor + restore).
  const bar = $('#sidebar')
  if (bar && bar.style.display !== 'none' && !bar.classList.contains('collapsed')) { collapseSidebar(); return true }
  return false
}

function updateChromeVisibility() {
  // remember top-left before header/footer visibility changes reflow
  if (view && !isResizing && view.lastLocation?.cfi) lastStableCfi = view.lastLocation.cfi
  if (view && lastStableCfi) { captureAnchor() }
  applyChromeVisibility()
  if (view && lastStableCfi) scheduleRestore()
}
// pure applicator (2026-09-27-16-35-36, unified-chrome): no capture, no
// restore — safe to call from hover handlers. visibility (not display) so
// the page keeps its box/padding, except symmetric-margins mode below.
// overlay-chrome (2026-09-27-17-52-01): title/position are absolutely
// overlaid (zero layout impact), so toggles use display:none — fully
// invisible and reflow-free. Mode-specific props are reset on every call
// so live flag flips can't strand a mix.
function applyChromeVisibility() {
  const overlay = FLAGS.SWITCH_PUT_TOP_MENU_AND_POSITION_TO_HALF_SPACE_VERTICALLY_AND_USE_SAME_HORIZONTAL_AND_VERTICAL_MARGINS === true
  $('#book-page').classList.toggle('overlay-chrome', overlay)
  const showMenu = settings.showBookMenu !== false
  const showPos = settings.showPosition !== false
  const header = $('#page-header')
  const pct = $('#pct-display')
  if (overlay) {
    header.style.display = showMenu ? '' : 'none'
    header.style.visibility = ''
    header.style.pointerEvents = showMenu ? '' : 'none'
    pct.style.display = showPos ? '' : 'none'
    pct.style.visibility = ''
    pct.style.pointerEvents = showPos ? '' : 'none'
  } else {
    header.style.display = ''
    pct.style.display = ''
    header.style.visibility = showMenu ? '' : 'hidden'
    header.style.pointerEvents = showMenu ? '' : 'none'
    pct.style.visibility = showPos ? '' : 'hidden'
    pct.style.pointerEvents = showPos ? '' : 'none'
  }

  // when the top menu AND the position line are both fully hidden,
  // optionally reclaim their space so the page's top/bottom margin
  // matches its left/right margin instead of staying header/footer-sized
  const symmetric = FLAGS.SWITCH_HIDE_TOP_BOOK_MENU_AND_POSITION_AT_BOTTOM_MAKES_TOP_AND_BOTTOM_MARGINS_SAME_SIZE_AS_LEFT_AND_RIGHT_MARGINS
    && !showMenu && !showPos
  $('#book-page').classList.toggle('symmetric-margins', symmetric)
}
function toggleBookMenu() {
  settings.showBookMenu = !(settings.showBookMenu !== false)
  // chrome-round2: full path (capture + restore) — hiding/showing reflows,
  // and the pure applicator alone would leave the drift uncorrected
  saveSettings(); updateChromeVisibility()
}
function togglePosition() {
  settings.showPosition = !(settings.showPosition !== false)
  saveSettings(); updateChromeVisibility()
}
// position-settings (2026-09-27-18-32-22): clear the furthest-read mark for
// the current book (menu jumps to the start until reading advances again).
function resetCurrentFurthest() {
  furthestFraction = 0
  furthestCharIndex = null
  savePositionNow()
}
// sidebar visibility (2026-09-27-16-35-36): false hides it with no way back
// (hot-corner intentionally dead); the merged menu opens from the header.
function applySidebarVisibility() {
  const bar = $('#sidebar')
  if (!bar) return
  bar.style.display = FLAGS.SHOW_LEFT_RED_MENUBAR === true ? '' : 'none'
}
// a click with selected book text clears the selection first and is
// consumed — never a page turn. Returns true when it cleared something.
function clearBookSelection() {
  let cleared = false
  try {
    for (const { doc } of view?.renderer?.getContents?.() ?? []) {
      const sel = doc.getSelection?.()
      if (sel && String(sel).length) { sel.removeAllRanges(); cleared = true }
    }
  } catch {}
  return cleared
}

function requestFullscreen() {
  // freeze-fullscreen-size: pin BEFORE the viewport changes (it is still
  // windowed here); the capture/schedule below then no-op via the guard.
  // Unfreeze if the request itself fails, or sizes stay pinned forever.
  freezeFullscreenSize()
  // fixed-page-size (2026-09-28-23-12-51): no capture/restore; page size does
  // not depend on fullscreen.
  document.documentElement.requestFullscreen().catch(() => { unfreezeFullscreenSize() })
}
function exitFullscreenIfActive() {
  if (document.fullscreenElement) document.exitFullscreen()
}
function toggleFullscreen() {
  if (document.fullscreenElement) exitFullscreenIfActive()
  else requestFullscreen()
}
// 2026-09-27-15-10-46 (freeze-fullscreen-size): while frozen, #book-page
// and #viewer-host hold their pre-fullscreen pixel sizes, so the paginator
// container never changes size and no reflow/restore is needed. All restore
// callers stay untouched: scheduleRestore() bails while frozen (resetting
// isResizing, so a pre-freeze captureAnchor can't strand it true).
let fullscreenFrozen = false
// last pixel sizes seen while windowed (2026-09-27-15-22-16): the physical
// F11 key gives no before-event (no DOM fullscreenchange), so on entering
// browser-chrome fullscreen we pin these instead of the live (grown) sizes.
let windowedPageW = 0, windowedPageH = 0, windowedHostW = 0, windowedHostH = 0
let displayModeMql = null
function rememberWindowedSizes() {
  try {
    const page = $('#book-page')
    const host = $('#viewer-host')
    if (!page || !host) return
    // fractional rects (2026-09-27-15-32-22): offset/clientWidth round to
    // integers, pinning a sub-pixel-different size and causing a microscopic
    // reflow (few-char read-back drift, changed bottom line)
    windowedPageW = page.getBoundingClientRect().width
    windowedPageH = page.getBoundingClientRect().height
    windowedHostW = host.getBoundingClientRect().width
    windowedHostH = host.getBoundingClientRect().height
  } catch {}
}
// windowed-snapshot-at-rest (2026-09-28-08-58-34): refresh the windowed
// snapshot whenever the layout is at rest, not only from window 'resize'
// (which never fires before the first F11, and can fire after the grown
// size is already live). Skipped while any fullscreen is active/pinned or
// while the page has no size (hidden), so it can never store a grown or
// zero snapshot. rememberWindowedSizes() itself is unchanged: the freeze
// path calls it directly, deliberately while fullscreen.
function rememberWindowedSizesIfAtRest() {
  try {
    if (document.fullscreenElement || displayModeMql?.matches || fullscreenFrozen) return
    const r = $('#book-page')?.getBoundingClientRect()
    if (!r || !r.width || !r.height) return
    rememberWindowedSizes()
  } catch {}
}
function freezeFullscreenSize() {
  if (!FLAGS.SWITCH_KEEP_CONTAINER_AND_PAGE_SIZE_SAME_ON_FULLSCREEN_CHANGE) return
  if (fullscreenFrozen) return
  try {
    const page = $('#book-page')
    const host = $('#viewer-host')
    if (!page || !host) return
    const pageRect = page.getBoundingClientRect()
    const hostRect = host.getBoundingClientRect()
    page.style.width = pageRect.width + 'px'
    page.style.height = pageRect.height + 'px'
    host.style.width = hostRect.width + 'px'
    host.style.height = hostRect.height + 'px'
    // this live measurement is itself a good windowed snapshot
    rememberWindowedSizes()
    fullscreenFrozen = true
  } catch {}
}
// F11 path: pin the remembered windowed sizes (live ones already grew).
function freezeFullscreenSizeFromSnapshot() {
  if (!FLAGS.SWITCH_KEEP_CONTAINER_AND_PAGE_SIZE_SAME_ON_FULLSCREEN_CHANGE) return
  if (fullscreenFrozen) return
  if (!windowedPageW || !windowedPageH || !windowedHostW || !windowedHostH) return
  try {
    const page = $('#book-page')
    const host = $('#viewer-host')
    if (!page || !host) return
    page.style.width = windowedPageW + 'px'
    page.style.height = windowedPageH + 'px'
    host.style.width = windowedHostW + 'px'
    host.style.height = windowedHostH + 'px'
    fullscreenFrozen = true
  } catch {}
}
function unfreezeFullscreenSize() {
  if (!fullscreenFrozen) return
  try {
    $('#book-page')?.style.removeProperty('width')
    $('#book-page')?.style.removeProperty('height')
    $('#viewer-host')?.style.removeProperty('width')
    $('#viewer-host')?.style.removeProperty('height')
  } catch {}
  fullscreenFrozen = false
}

/* Any layout change (window resize, fullscreen toggle, sidebar show/hide,
   hiding header/footer, page/frame sliders) re-paginates the book, which
   otherwise silently drifts the reading position. Top-left character is
   remembered before the change and restored after layout settles.

   The naive fix — read view.lastLocation.cfi when the resize is first
   noticed — loses the race: by the time ResizeObserver runs, the paginator
   has usually already re-flowed and fired its own drifted 'relocate', so
   "the position right now" is already the wrong one. Instead we keep
   lastStableCfi updated by onRelocate only on an intentional position
   change (reason 'page', an actual page turn, or 'navigation', a real
   jump such as TOC/"Go to position") and never mid-resize, and also
   capture it synchronously *before* any mutation that will change layout
   (sidebar, header/footer, sliders, fullscreen, window resize) so the
   anchor is the true top-left before reflow.

   2026-09-27 addition (Problem A): a fixed wait alone wasn't enough to
   know the layout had actually finished resizing - a fullscreen transition
   can keep changing the paginator's `size` for far longer than any one
   fixed guess. scheduleRestore() now polls view.renderer.size (see
   waitForPaginatorSizeStable()) after the burst-coalescing wait below, and
   only does the actual restore once size has stopped moving. */
let resizeSettleTimer = null
let isResizingOffTimer = null
// bumped on every scheduleRestore() call; lets a still-in-flight size poll
// from an earlier call detect it's been superseded by a newer one (e.g.
// another resize/toggle arriving while the poll is still waiting) and bail
// out cleanly instead of racing the newer restore.
let restoreGeneration = 0
// restore-nav-guard (2026-09-28-20-12-00): generation of the restore whose own
// goTo relocates are in flight (0 = none). A freeze (F11 pressed again) resets
// isResizing without bumping restoreGeneration, so that restore's landing used
// to be saved as a real move (2303 -> 2211). onRelocate ignores relocates while
// restoreNavGen === restoreGeneration; a newer jump (search etc.) bumps the
// generation, so it is still saved.
let restoreNavGen = 0
// Problem A fix (2026-09-27): poll the paginator's own `size` getter
// (already public - view.renderer.size, see paginator.js `get size()`)
// until it's read the same value STABLE_CHECKS_REQUIRED times in a row,
// instead of trusting a fixed timer to know a resize/fullscreen transition
// has finished. Resolves true once settled (or once MAX_WAIT_MS elapses,
// as a safety cap), or resolves false if superseded by a newer
// scheduleRestore() call in the meantime (checked via the generation
// counter above).
function waitForPaginatorSizeStable(generation) {
  return new Promise(resolve => {
    const intervalMs = FLAGS.SWITCH_POLL_PAGINATOR_SIZE_BEFORE_RESTORE_INTERVAL_MS
    const neededStableChecks = FLAGS.SWITCH_POLL_PAGINATOR_SIZE_STABLE_CHECKS_REQUIRED
    const maxWaitMs = FLAGS.SWITCH_POLL_PAGINATOR_SIZE_MAX_WAIT_MS
    const startedAt = Date.now()
    let lastSize = null
    let stableCount = 0
    const check = () => {
      if (generation !== restoreGeneration) { resolve(false); return }
      let size = null
      try { size = view?.renderer?.size ?? null } catch { size = null }
      if (size != null && size === lastSize) stableCount++
      else stableCount = 1
      lastSize = size
      if (stableCount >= neededStableChecks) { resolve(true); return }
      if (Date.now() - startedAt >= maxWaitMs) {
        resolve(true) // give up waiting, proceed anyway rather than hang the restore
        return
      }
      setTimeout(check, intervalMs)
    }
    check()
  })
}
function captureAnchor() {
  if (!view) return
  const cur = view.lastLocation?.cfi
  const frac = view.lastLocation?.fraction
  let snippet = null
  try { snippet = String(view.lastLocation?.range).slice(0, 30) } catch {}
  let charIdx = null
  try { charIdx = getCurrentCharIndex() } catch {}
  // lastStable* is now only ever updated by onRelocate()'s reason-filtered
  // save ('page' or 'navigation'). Re-deriving it here from the live view
  // position used to run whenever !isResizing, which included exactly the
  // post-resize drift window onRelocate() is designed to reject — bypassing
  // that filter. Only fall back to the live position if there is no saved
  // anchor at all yet (e.g. the very first geometry-changing action before
  // any relocate has fired).
  if (cur && !lastStableCfi) { lastStableCfi = cur; if (frac != null && lastStableFraction == null) lastStableFraction = frac; if (snippet && !lastStableSnippet) lastStableSnippet = snippet; if (charIdx != null && lastStableCharIndex == null) lastStableCharIndex = charIdx }
  isResizing = true
  clearTimeout(resizeSettleTimer)
  clearTimeout(isResizingOffTimer)
}
function scheduleRestore() {
  if (!view) { isResizing = false; return }
  // freeze-fullscreen-size: nothing reflowed while frozen, so there is no
  // drift to correct; reset the flag a pre-freeze captureAnchor may have set
  // and bail before arming any timers or generation bumps.
  if (fullscreenFrozen) { isResizing = false; return }
  const myGeneration = ++restoreGeneration
  clearTimeout(resizeSettleTimer)
  resizeSettleTimer = setTimeout(async () => {
    const cfi = lastStableCfi
    const frac = lastStableFraction
    const charIdx = lastStableCharIndex
    debugBeacon('restore-start', { target: charIdx ?? '', gen: myGeneration, ...debugGeom() })
    // same guard at fire time: a restore scheduled just before the freeze
    // (e.g. requestFullscreen's own call) must not goTo once frozen.
    if (fullscreenFrozen) { isResizing = false; return }
    await waitForPaginatorSizeStable(myGeneration)
    if (myGeneration !== restoreGeneration) {
      // superseded by a newer resize/toggle while we were polling - that
      // newer call owns finishing the restore and turning isResizing back
      // off; bail out here without touching either.
      return
    }
    const waitRelocate = () => new Promise(resolve => {
      let done = false
      const h = e => {
        if (done) return
        // ignore drift relocates from the paginator's own internal resize /
        // font-load settling (reason 'anchor', from render()/onExpand); only
        // a real goTo/goToFraction (reason 'navigation') confirms our restore.
        if (e.detail?.reason !== 'navigation') return
        done = true; view.removeEventListener('relocate', h); resolve(e.detail)
      }
      view.addEventListener('relocate', h)
      setTimeout(() => { if (!done) { view.removeEventListener('relocate', h); resolve(null) } }, 700)
    })
    // persist-int-only: when SWITCH_SAVE_LOCATION_AS_CFI is not true, only
    // the integer char path below runs; the CFI/fraction branches are skipped.
    const useCfiRestore = FLAGS.SWITCH_SAVE_LOCATION_AS_CFI === true
    restoreNavGen = myGeneration
    try {
      if (charIdx != null && bookTotalChars) {
        const target = await getRangeForCharIndex(charIdx)
        // start listening BEFORE calling goTo/goToFraction: the confirming
        // relocate can be dispatched synchronously inside goTo's own await
        // chain, so attaching the listener only after `await goTo(...)`
        // returns can miss it entirely.
        const pending = waitRelocate()
        if (target) await view.renderer.goTo(target).catch(() => {})
        else {
          const charFrac = charIdx / bookTotalChars
          await view.goToFraction(charFrac).catch(() => {})
        }
        const detail = await pending
        // restore-diag-retry (2026-09-28-12-02-23): landed earlier than the
        // target (e.g. one page early after F11)? settle, then goTo once more.
        if (FLAGS.SWITCH_RETRY_RESTORE_ONCE_IF_LANDED_EARLY === true && target && myGeneration === restoreGeneration && !fullscreenFrozen) {
          let landed = null
          try { landed = getCurrentCharIndex() } catch { landed = null }
          const gap = landed == null ? 0 : charIdx - landed
          if (gap > 0 && gap <= (FLAGS.SWITCH_RESTORE_RETRY_MAX_CHAR_GAP ?? 2000)) {
            debugBeacon('restore-retry', { target: charIdx, landed, gap, ...debugGeom() })
            await new Promise(r => setTimeout(r, 150))
            if (myGeneration === restoreGeneration && !fullscreenFrozen) {
              const t2 = await getRangeForCharIndex(charIdx)
              const pending2 = waitRelocate()
              if (t2) await view.renderer.goTo(t2).catch(() => {})
              await pending2
              let landed2 = null
              try { landed2 = getCurrentCharIndex() } catch { landed2 = null }
              debugBeacon('restore-retry-done', { target: charIdx, landed: landed ?? '', landed2: landed2 ?? '', ...debugGeom() })
            }
          }
        }
        let curSnippet = ''
        try { curSnippet = String(detail?.range ?? view.lastLocation?.range).slice(0, 30) } catch {}
        const snippetMismatch = lastStableSnippet && curSnippet && curSnippet !== lastStableSnippet
        if (snippetMismatch && useCfiRestore && cfi) {
          const pendingFallback = waitRelocate()
          await view.goTo(cfi).catch(() => {})
          await pendingFallback
        }
      } else if (useCfiRestore && cfi) {
        const pending = waitRelocate()
        await view.goTo(cfi).catch(() => {})
        const detail = await pending
        const curFrac = detail?.fraction ?? view.lastLocation?.fraction
        let curSnippet = ''
        try { curSnippet = String(detail?.range ?? view.lastLocation?.range).slice(0, 30) } catch {}
        const snippetMismatch = lastStableSnippet && curSnippet && curSnippet !== lastStableSnippet
        if ((frac != null && curFrac != null && Math.abs(curFrac - frac) > 0.0005) || snippetMismatch) {
          const pendingFallback = waitRelocate()
          await view.goToFraction(frac).catch(() => {})
          await pendingFallback
        }
      }
    } catch {} finally { if (restoreNavGen === myGeneration) restoreNavGen = 0 }
    // pct-from-char (2026-09-27-10-49-44): in int mode show where the restore
    // landed (live read), not the pre-resize frac.
    if (FLAGS.SWITCH_SAVE_LOCATION_AS_CFI !== true && bookTotalChars) {
      let li = null
      try { li = getCurrentCharIndex() } catch { li = null }
      if (li == null) li = charIdx
      if (li != null) $('#pct-display').textContent = formatPct(li / bookTotalChars)
      else if (frac != null) $('#pct-display').textContent = formatPct(frac)
    }
    else if (frac != null) $('#pct-display').textContent = formatPct(frac)
    else if (charIdx != null && bookTotalChars) $('#pct-display').textContent = formatPct(charIdx / bookTotalChars)
    try { flashFirstRowOnRestore() } catch {}
    markSavedCharAfterRestore(charIdx, myGeneration).catch(() => {})
    if (debugOn()) { let landed = ''; try { landed = getCurrentCharIndex() ?? '' } catch {} ; debugBeacon('restore-done', { target: charIdx ?? '', landed, ...debugGeom() }) }
    rememberWindowedSizesIfAtRest()
    clearTimeout(isResizingOffTimer)
    isResizingOffTimer = setTimeout(() => { isResizing = false }, FLAGS.SWITCH_POST_RESTORE_GRACE_IGNORE_TRAILING_RELOCATE_EVENTS_IN_MS)
  }, FLAGS.SWITCH_WAIT_TILL_MOST_OF_PAGE_RESIZING_BURST_SETTLES_BEFORE_SYNCING_TOP_LEFT_CHAR_IN_MS)
}
// page-size-no-vh (2026-09-28-23-34-29): ignore sub-pixel changes (Firefox layout
// units are 1/60 px; F11 flipped the host between 482.3833 and 482.3999 px and
// scheduled a restore each time). Compared with the last accepted size, so
// small changes cannot accumulate unnoticed.
let roLastW = null, roLastH = null
const RO_MIN_CHANGE_PX = 0.5
const resizeObserver = new ResizeObserver(entries => {
  if (!view) return
  const r = entries?.[entries.length - 1]?.contentRect
  if (r && roLastW != null) {
    if (Math.abs(r.width - roLastW) < RO_MIN_CHANGE_PX && Math.abs(r.height - roLastH) < RO_MIN_CHANGE_PX) return
  }
  if (r) { roLastW = r.width; roLastH = r.height }
  // observer fires after layout – capture should already have happened synchronously
  scheduleRestore()
})
let lastWindowResizeLogAt = 0
let pageRefSettleTimer = null // fixed-page-size (2026-09-28-23-12-51)
// settle-guard (2026-09-29-08-27-26): time of the last fullscreenchange /
// display-mode event. On leaving fullscreen the display-mode event arrives
// before innerHeight has shrunk, so a settle timer firing in that gap refitted
// the page to 88% of the still-big height (page grew, then shrank: drift).
// The timer now waits until FS_EVENT_QUIET_MS after the last such event.
let lastFsEventAt = 0
const FS_EVENT_QUIET_MS = 1500
const PAGE_REF_SETTLE_MS = 600
function runPageRefSettle() {
  if (document.fullscreenElement || displayModeMql?.matches) return
  if (Date.now() - lastFsEventAt < FS_EVENT_QUIET_MS) {
    clearTimeout(pageRefSettleTimer)
    pageRefSettleTimer = setTimeout(runPageRefSettle, PAGE_REF_SETTLE_MS)
    return
  }
  const cur = document.documentElement.style.getPropertyValue('--page-h-px')
  const px = Math.round((settings.pageSizeVh / 100) * window.innerHeight * 100) / 100 + 'px'
  if (cur === px) return
  if (view && lastStableCfi) captureAnchor()
  setPageRefHeight()
  if (view && lastStableCfi) scheduleRestore()
}
window.addEventListener('resize', () => {
  // throttled (2026-09-28-12-02-23): F11 fires ~50 resize events per press
  const nowMs = Date.now()
  if (nowMs - lastWindowResizeLogAt > 400) { lastWindowResizeLogAt = nowMs; debugBeacon('window-resize', { w: window.innerWidth, h: window.innerHeight, ...debugGeom() }) }
  // keep the windowed snapshot fresh (skipped while any fullscreen is active)
  if (!document.fullscreenElement && !(displayModeMql?.matches)) rememberWindowedSizes()
  // fixed-page-size (2026-09-28-23-12-51): no capture/restore per resize event.
  // After the resize burst settles, and only when not in any fullscreen, refit
  // the reference page height; a real size change goes through the usual
  // capture + restore. Fullscreen/F11 leaves the page untouched.
  clearTimeout(pageRefSettleTimer)
  pageRefSettleTimer = setTimeout(runPageRefSettle, PAGE_REF_SETTLE_MS)
})

/* ---------------- export / import (backup) ---------------- */

// fresh-app-button (2026-09-27-18-51-02): escape a stale service worker
// (the mobile trap) — update check, drop all our caches, unregister, then
// hard reload. Next boot registers a fresh worker from network code.
async function loadFreshApp() {
  try {
    if ('serviceWorker' in navigator && navigator.serviceWorker.getRegistrations) {
      const regs = await navigator.serviceWorker.getRegistrations().catch(() => [])
      await Promise.all(regs.map(r => { try { return r.update() } catch { return null } })).catch(() => {})
      try {
        const keys = await caches.keys()
        await Promise.all(keys.map(k => caches.delete(k).catch(() => false)))
      } catch {}
      await Promise.all(regs.map(r => { try { return r.unregister() } catch { return null } })).catch(() => {})
    }
  } catch {}
  location.reload()
}

async function exportData(includeBooks) {
  const [booksRaw, positions, settingsRow, fontRow] = await Promise.all([
    idbGetAll('books'), idbGetAll('positions'), idbGet('settings', 'reader'), idbGet('fonts', 'user-uploaded'),
  ])
  const books = []
  for (const b of booksRaw) {
    const entry = { id: b.id, title: b.title, openedAt: b.openedAt, coverDataUrl: b.coverDataUrl }
    if (includeBooks && b.file) {
      try { entry.fileDataUrl = await blobToDataUrl(b.file) } catch {}
    }
    books.push(entry)
  }
  const payload = {
    app: 'sm_reader', version: 1, exportedAt: Date.now(),
    settings: settingsRow?.value || null, positions, books, uploadedFont: fontRow || null,
  }
  const blob = new Blob([JSON.stringify(payload)], { type: 'application/json' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `sm-reader-backup-${new Date().toISOString().slice(0, 10)}.json`
  document.body.appendChild(a)
  a.click()
  a.remove()
  setTimeout(() => URL.revokeObjectURL(url), 4000)
}

async function importDataFile(file) {
  let payload
  try { payload = JSON.parse(await file.text()) }
  catch { alert('That file could not be read as an SM Reader backup.'); return }

  if (payload.settings) await idbPut('settings', { key: 'reader', value: payload.settings })
  for (const p of payload.positions || []) await idbPut('positions', p)
  for (const b of payload.books || []) {
    const existing = await idbGet('books', b.id)
    let fileObj = existing?.file || null
    if (b.fileDataUrl) {
      try {
        const res = await fetch(b.fileDataUrl)
        const blob = await res.blob()
        fileObj = new File([blob], (b.title || 'book') + '.epub', { type: 'application/epub+zip' })
      } catch {}
    }
    await idbPut('books', { id: b.id, title: b.title, openedAt: b.openedAt, coverDataUrl: b.coverDataUrl, file: fileObj })
  }
  if (payload.uploadedFont) await idbPut('fonts', payload.uploadedFont)

  await loadSettings()
  await loadUploadedFont()
  await refreshLibrary()
  renderSettings()
  alert('Import complete.')
}

/* ---------------- settings UI ---------------- */

function renderSettings() {
  const sizeRow = $('#size-chips')
  sizeRow.innerHTML = ''
  for (const s of SIZE_STEPS) {
    const b = document.createElement('button')
    b.className = 'size-chip' + (settings.fontSize === s ? ' active' : '')
    b.textContent = s
    b.addEventListener('click', () => { settings.fontSize = s; saveSettings(); applyStyles(); renderSettings() })
    sizeRow.appendChild(b)
  }
  $('#custom-size').value = settings.fontSize

  const fontRow = $('#font-chips')
  fontRow.innerHTML = ''
  for (const f of BUNDLED_FONTS) {
    const b = document.createElement('button')
    b.className = 'font-chip' + (!settings.customFontName && !settings.uploadedFontName && settings.fontId === f.id ? ' active' : '')
    b.textContent = f.label
    b.style.fontFamily = f.family
    b.addEventListener('click', () => {
      settings.fontId = f.id; settings.customFontName = ''; settings.uploadedFontName = ''
      saveSettings(); applyStyles(); renderSettings()
    })
    fontRow.appendChild(b)
  }
  $('#custom-font-name').value = settings.customFontName

  $$('.theme-swatch').forEach(el => el.classList.toggle('active', el.dataset.theme === settings.theme))

  $('#line-spacing').value = settings.lineSpacing
  $('#line-spacing-val').textContent = settings.lineSpacing

  $('#page-size').value = settings.pageSizeVh
  $('#page-size-val').textContent = settings.pageSizeVh + '%'
  $('#frame-size').value = settings.frameSizePct
  $('#frame-size-val').textContent = settings.frameSizePct + '%'
  $('#page-ratio').value = ['reader', 'a4', 'letter'].includes(settings.pageRatio) ? settings.pageRatio : 'reader'

  $('#pct-decimals').value = String(settings.pctDecimals ?? 2)
  $('#start-fullscreen').checked = settings.startFullscreen === true
  $('#click-position-goto').checked = settings.clickPositionForGoto === true
}

function wireSettings() {
  $('#custom-size').addEventListener('change', e => {
    const v = parseFloat(e.target.value)
    if (v > 0) { settings.fontSize = v; saveSettings(); applyStyles(); renderSettings() }
  })
  $('#custom-font-name').addEventListener('change', e => {
    settings.customFontName = e.target.value.trim()
    settings.uploadedFontName = ''
    saveSettings(); applyStyles(); renderSettings()
  })
  $('#font-upload').addEventListener('change', async e => {
    const file = e.target.files[0]
    if (!file) return
    const dataUrl = await blobToDataUrl(file)
    await idbPut('fonts', { name: 'user-uploaded', originalName: file.name, dataUrl })
    document.querySelectorAll('style[data-userfont]').forEach(s => s.remove())
    const style = document.createElement('style')
    style.dataset.userfont = '1'
    style.textContent = `@font-face { font-family: 'UserFont'; src: url(${JSON.stringify(dataUrl)}); }`
    document.head.appendChild(style)
    settings.uploadedFontName = file.name
    settings.customFontName = ''
    saveSettings(); applyStyles(); renderSettings()
  })
  $$('.theme-swatch').forEach(el => {
    el.addEventListener('click', () => {
      settings.theme = el.dataset.theme
      saveSettings(); applyTheme(); renderSettings()
    })
  })
  $('#line-spacing').addEventListener('input', e => {
    settings.lineSpacing = parseFloat(e.target.value)
    $('#line-spacing-val').textContent = settings.lineSpacing
    applyStyles()
  })
  $('#line-spacing').addEventListener('change', saveSettings)

  $('#page-size').addEventListener('input', e => {
    settings.pageSizeVh = parseFloat(e.target.value)
    $('#page-size-val').textContent = settings.pageSizeVh + '%'
    applyGeometry()
  })
  $('#page-size').addEventListener('change', saveSettings)
  $('#frame-size').addEventListener('input', e => {
    settings.frameSizePct = parseFloat(e.target.value)
    $('#frame-size-val').textContent = settings.frameSizePct + '%'
    applyGeometry()
  })
  $('#frame-size').addEventListener('change', saveSettings)

  $('#page-ratio').addEventListener('change', e => { settings.pageRatio = e.target.value; saveSettings(); applyGeometry(); renderSettings() })

  $('#pct-decimals').addEventListener('change', e => { settings.pctDecimals = Math.min(7, Math.max(0, parseInt(e.target.value, 10) || 0)); saveSettings(); refreshPctDisplay(); renderSettings() })
  $('#start-fullscreen').addEventListener('change', e => { settings.startFullscreen = e.target.checked; saveSettings() })
  $('#click-position-goto').addEventListener('change', e => { settings.clickPositionForGoto = e.target.checked; saveSettings() })
  $('#reset-furthest-btn').addEventListener('click', () => { resetCurrentFurthest() })

  $('#export-btn').addEventListener('click', () => exportData(false))
  $('#fresh-app-btn').addEventListener('click', () => loadFreshApp())
  $('#import-btn-settings').addEventListener('click', () => $('#import-file-input').click())
  $('#import-file-input').addEventListener('change', e => {
    const file = e.target.files[0]
    if (file) importDataFile(file)
  })
}

/* ---------------- boot ---------------- */

async function main() {
  await loadSettings()
  await loadUploadedFont()
  wireSettings()

  // sidebar / dropdown / page-turn priority on the dark surround:
  //  1. selected book text (if any) is cleared first
  //  2. otherwise an open "top book menu" dropdown closes first
  //  3. otherwise, an open sidebar hides first
  //  4. otherwise (nothing else to dismiss) turn the page, if that flag is on
  $('#main').addEventListener('click', e => {
    if (e.target.id !== 'main') return
    if (view && clearBookSelection()) return
    if (dismissChrome()) return
    if (FLAGS.SWITCH_CLICK_LEFT_OR_RIGHT_ON_BLACK_SCREEN_WHEN_NO_RED_MENU_PRESENT_GOES_TO_PREV_NEXT_PAGE && view) {
      turnAt(e.clientX, window.innerWidth, 'window-tap')
    }
  })

  // a small hot corner (top-left) always brings the side menu back,
  // even when the surround is turning pages instead of toggling it
  // unified-chrome: dead while the red menubar is hidden (no way back by order)
  $('#hot-corner').addEventListener('click', e => {
    e.stopPropagation()
    if (FLAGS.SHOW_LEFT_RED_MENUBAR !== true) return
    expandSidebar()
  })

  $('#goto-btn').addEventListener('click', e => {
    buildGotoMenu()
    // chrome-round2: anchored below the trigger, left-aligned (the ▾ sits at
    // the trigger's left edge); transform reset kills the old centering
    const menu = $('#goto-menu')
    const r = e.target.getBoundingClientRect()
    menu.style.left = r.left + 'px'
    menu.style.top = (r.bottom + 6) + 'px'
    menu.style.transform = 'none'
    menu.classList.toggle('show')
  })
  $('#page-header').addEventListener('click', e => {
    if (!view) return
    buildGotoMenu()
    const menu = $('#goto-menu')
    const r = e.currentTarget.getBoundingClientRect()
    menu.style.left = r.left + 'px'
    menu.style.top = (r.bottom + 6) + 'px'
    menu.style.transform = 'none'
    menu.classList.toggle('show')
  })
  document.addEventListener('click', e => {
    if (!e.target.closest('#goto-btn') && !e.target.closest('#goto-menu') && !e.target.closest('#page-header')) {
      $('#goto-menu').classList.remove('show')
    }
  })

  for (const id of ['#library-back-top', '#library-back-bottom', '#settings-back-top', '#settings-back-bottom']) {
    $(id)?.addEventListener('click', showReaderView)
  }

  $('#import-btn').addEventListener('click', () => $('#file-input').click())
  $('#file-input').addEventListener('change', e => importFiles(e.target.files))
  document.addEventListener('dragover', e => e.preventDefault())
  document.addEventListener('drop', e => {
    e.preventDefault()
    if (e.dataTransfer.files.length) importFiles(e.dataTransfer.files)
  })

  $('#cover-overlay').addEventListener('click', hideCover)

  // search-book-panel (2026-09-27-12-08-27): footer % opens goto; panel buttons step
  // position-settings (2026-09-27-18-32-22): or toggles position on/off
  // instead of the dialog (mobile). Header click keeps the dialog.
  $('#pct-display').addEventListener('click', () => {
    if (!view) return
    if (settings.clickPositionForGoto === true) promptGoto()
    else togglePosition()
  })
  $('#search-prev').addEventListener('click', () => doSearchBook(-1))
  $('#search-next').addEventListener('click', () => doSearchBook(1))
  $('#search-close').addEventListener('click', hideSearchPanel)
  $('#search-input').addEventListener('keydown', e => {
    if (e.ctrlKey || e.metaKey) return // let global Ctrl+G/Ctrl+F through
    if (e.key === 'Enter') { e.preventDefault(); doSearchBook(e.shiftKey ? -1 : 1) }
    else if (e.key === 'Escape') hideSearchPanel()
    e.stopPropagation() // keep global handleKey (arrows/page-turn) off the input
  })
  $('#search-input').addEventListener('input', e => e.target.classList.remove('not-found'))

  // clicking the page padding (outside the rendered text, still on the page)
  $('#viewer-host').addEventListener('click', e => {
    if (e.target.id !== 'viewer-host' || !view) return
    if (clearBookSelection()) return
    if (dismissChrome()) return
    // tap-coords-fix: clientX is viewport-based, so subtract the host's own
    // left edge before comparing against its width
    const r = e.currentTarget.getBoundingClientRect()
    turnAt(e.clientX - r.left, r.width, 'host-tap')
  })

  // zoned hover reveal (chrome-round2): cursor in the top/bottom ~20% of
  // the page reveals the header/position when toggled off; zones are page
  // areas (not the elements, which may be display:none) so both-hidden
  // works too. Overlay mode is reflow-free (absolute); classic visibility
  // mode keeps its box. Leave hides.
  let chromeHoverState = ''
  const overlayMode = () => FLAGS.SWITCH_PUT_TOP_MENU_AND_POSITION_TO_HALF_SPACE_VERTICALLY_AND_USE_SAME_HORIZONTAL_AND_VERTICAL_MARGINS === true
  const showChromeEl = el => {
    if (overlayMode()) el.style.display = ''
    else el.style.visibility = 'visible'
    el.style.pointerEvents = ''
  }
  const hideChromeEl = el => {
    if (overlayMode()) el.style.display = 'none'
    else el.style.visibility = 'hidden'
    el.style.pointerEvents = 'none'
  }
  $('#book-page').addEventListener('mousemove', e => {
    const r = e.currentTarget.getBoundingClientRect()
    const y = (e.clientY - r.top) / Math.max(1, r.height)
    const wantHeader = settings.showBookMenu === false && y < 0.2
    const wantPos = settings.showPosition === false && y > 0.8
    const state = (wantHeader ? 'h' : '') + (wantPos ? 'p' : '')
    if (state === chromeHoverState) return
    chromeHoverState = state
    const header = $('#page-header')
    if (wantHeader) showChromeEl(header)
    else if (settings.showBookMenu === false) hideChromeEl(header)
    const pct = $('#pct-display')
    if (wantPos) showChromeEl(pct)
    else if (settings.showPosition === false) hideChromeEl(pct)
  })
  $('#book-page').addEventListener('mouseleave', () => { chromeHoverState = ''; applyChromeVisibility() })

  document.addEventListener('keydown', handleKey)

  // scroll-to-turn, for the outer document (page padding, black surround,
  // header/footer area) — the book text itself is a separate <iframe>
  // document and is wired independently in wireContentDoc()
  let outerWheelLock = false
  document.addEventListener('wheel', e => {
    if (!view || outerWheelLock) return
    outerWheelLock = true
    setTimeout(() => { outerWheelLock = false }, 350)
    if (e.deltaY > 0) view.goRight?.() ?? view.renderer?.next()
    else if (e.deltaY < 0) view.goLeft?.() ?? view.renderer?.prev()
  }, { passive: true })

  document.addEventListener('fullscreenchange', () => {
    lastFsEventAt = Date.now() // settle-guard
    debugBeacon('fullscreenchange', { fsEl: !!document.fullscreenElement, ...debugGeom() })
    // freeze-fullscreen-size: pin (or release) pixel sizes before any
    // capture/schedule below; while frozen those calls become no-ops via
    // the scheduleRestore() guard. requestFullscreen() already pinned
    // pre-change; this covers the remaining DOM-fullscreen entries.
    // (Physical F11 fires no DOM event — see display-mode listener below.)
    if (document.fullscreenElement) freezeFullscreenSize()
    else unfreezeFullscreenSize()
    document.getElementById('app').classList.toggle('fullscreen', !!document.fullscreenElement)
    updateChromeVisibility()
    // fixed-page-size (2026-09-28-23-12-51): no capture/restore here; the page
    // size does not depend on fullscreen. A real host size change (clamp case)
    // is still caught by resizeObserver below.
  })

  // watch the actual page content area for size changes, from any cause
  // (window resize, fullscreen, sidebar show/hide) and correct drift
  resizeObserver.observe($('#viewer-host'))

  // physical F11 (browser-chrome fullscreen): no DOM fullscreenchange fires,
  // but display-mode flips where the browser supports it — pin the
  // remembered windowed sizes so the page snaps back instead of reflowing.
  // Best-effort and idempotent with the DOM path above (frozen guard).
  try {
    displayModeMql = window.matchMedia?.('(display-mode: fullscreen)') ?? null
    displayModeMql?.addEventListener?.('change', e => {
      lastFsEventAt = Date.now() // settle-guard
      debugBeacon('display-mode', { matches: e.matches, ...debugGeom() })
      // fixed-page-size (2026-09-28-23-12-51): freeze helpers are no-ops with the
      // flag off; no restore here (resizeObserver covers real size changes).
      if (e.matches && !document.fullscreenElement) freezeFullscreenSizeFromSnapshot()
      else if (!e.matches && !document.fullscreenElement) unfreezeFullscreenSize()
    })
  } catch {}

  updateChromeVisibility()
  applySidebarVisibility()

  await refreshLibrary()

  // unified-chrome: open the last viewed book when the switch is on and a
  // book was opened before; fresh installs (or switch off) land on Library
  let openedLastBook = false
  if (FLAGS.SWITCH_OPEN_LAST_VIEWED_BOOK_ON_START === true) {
    try {
      const books = await idbGetAll('books')
      books.sort((a, b) => (b.openedAt || 0) - (a.openedAt || 0))
      const last = books.find(b => b.openedAt)
      if (last) { await openBook(last.id); openedLastBook = true }
    } catch {}
  }
  if (!openedLastBook) showLibrary()

  if (settings.startFullscreen === true) {
    try { requestFullscreen() } catch {}
  }

  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('./sw.js').catch(() => {})
    // unregister on exit so localhost:8000 is not kept registered after closing
    const unregisterSW = () => {
      navigator.serviceWorker.getRegistrations?.().then(rs => rs.forEach(r => r.unregister())).catch(() => {})
    }
    window.addEventListener('pagehide', unregisterSW)
    window.addEventListener('beforeunload', unregisterSW)
    document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') unregisterSW() })
  }
}

main()
