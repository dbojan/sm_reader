// SM Reader - sw.js
// last modified (utc): 2026-09-29-09-39-04
// instructions: on modify, update string.
const CACHE = '2026-09-29-09-39-04'
const ASSETS = [
  './',
  './index.html',
  './css/style.css',
  './js/app.js',
  './js/foliate-js/view.js',
  './js/foliate-js/epub.js',
  './js/foliate-js/epubcfi.js',
  './js/foliate-js/progress.js',
  './js/foliate-js/overlayer.js',
  './js/foliate-js/text-walker.js',
  './js/foliate-js/paginator.js',
  './js/foliate-js/vendor/zip.js',
  './js/foliate-js/vendor/fflate.js',
  './fonts/Jost.ttf',
  './manifest.json',
]

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)))
  self.skipWaiting()
})

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
  )
  self.clients.claim()
})

self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return
  e.respondWith(
    caches.match(e.request).then(cached => cached || fetch(e.request).then(res => {
      const copy = res.clone()
      caches.open(CACHE).then(c => c.put(e.request, copy))
      return res
    }).catch(() => cached))
  )
})
